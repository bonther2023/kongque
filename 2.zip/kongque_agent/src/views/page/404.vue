<template>
    <div class="panel-content">
        <div class="panel-body panel-home"  style="text-align: center;font-size: 30px;margin-top: 25%">
            <p>404</p>
            <p>抱歉，你要访问的地址去火星了</p>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {

            }
        },
        created(){
            this.$store.dispatch('setActive', '/main');
        },
        methods: {

        }
    }
</script>

<style scoped>

</style>
