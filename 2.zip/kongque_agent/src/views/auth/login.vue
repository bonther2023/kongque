<template>
    <div>
<!--        <vue-canvas-nest style="z-index: 1" :config="config"></vue-canvas-nest>-->
        <div class="login-form">
            <div class="login-title">代理后台</div>
            <el-form :model="form" status-icon ref="form">
                <el-form-item :rules="[{ required: true, message: '请填写代理账号', trigger: 'blur'}]" prop="username">
                    <el-input prefix-icon="fa fa-user-o" type="text" placeholder="请填写代理账号" v-model="form.username" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item :rules="[{ required: true, message: '请填写代理密码', trigger: 'blur'}]" prop="password">
                    <el-input prefix-icon="fa fa-unlock-alt" type="password" v-model="form.password" placeholder="请填写代理密码" auto-complete="off"></el-input>
                </el-form-item>
                <el-form-item :rules="[{ required: true, message: '请填写验证码', trigger: 'blur'}]" prop="captcha">
                    <el-input prefix-icon="fa fa-image" v-model.number="form.captcha" placeholder="请填写验证码" style="width: 230px"></el-input>
                    <img @click="getCaptcha" class="login-captcha" :src="captchaLink">
                </el-form-item>
                <div>
                    <el-input type="hidden" v-model.number="form.print_id"></el-input>
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                               :disabled="formDisabled" @click="submitForm">{{buttonTitle}}</el-button>
                </div>
                <div style="text-align: center;color: #8c939d;margin-top: 35px;font-size: 12px">
                    Copyright © Powered By Agent System 2022
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>
    import vueCanvasNest from 'vue-canvas-nest';
    import {Captcha,UserLogin} from '@/utils/request';
    export default {
        components: { vueCanvasNest },
        data(){
            return {
                config : {color: '184,255,237', opacity: 1, zIndex: 55, count: 250},
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '登 录',
                captchaLink: '',
                form: {username: '', password: '', captcha: '', captchaKey:'',print_id:''},
            }
        },
        created(){
            this.form = {username: '', password: '', captcha: '', captchaKey:'',print_id:''};
            this.getCaptcha();
            this.keyupSubmit();
        },
        methods:{
            keyupSubmit(){
                document.onkeydown=(event)=>{
                    if(event.keyCode === 13){
                        this.submitForm();
                    }
                }
            },
            getCaptcha(){
                let that = this;
                Captcha().then((res)=>{
                    let detail = this.$crypto.decrypt(res.data);
                    that.captchaLink = detail.captcha;
                    that.form.captchaKey = detail.captchaKey;
                });
            },
            submitForm() {
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '登录中...';
                        UserLogin({params:this.$crypto.encrypt(this.form)}).then((res) =>{
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            if(res.code){
                                this.buttonTitle = '登 录';
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                let detail = this.$crypto.decrypt(res.data);
                                this.$store.dispatch('userLogin',detail).then(()=>{
                                    this.$notify({
                                        title: '成功',
                                        message: res.msg,
                                        type: 'success',
                                        duration: '1000',
                                        onClose:() =>{
                                            this.$router.push({name:'main'});
                                        }
                                    });
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
        }
    }
</script>
<style scoped>
    .login-form{
        box-shadow: -15px 15px 15px rgba(6, 17, 47, 0.7);
        opacity: 1;
        -webkit-transition-timing-function: cubic-bezier(0.68, -0.25, 0.265, 0.85);
        -webkit-transition-property: -webkit-transform,opacity,box-shadow,top,left;
        transition-property: transform,opacity,box-shadow,top,left;
        -webkit-transition-duration: .5s;
        transition-duration: .5s;
        -webkit-transform-origin: 161px 100%;
        -ms-transform-origin: 161px 100%;
        transform-origin: 161px 100%;
        -webkit-transform: rotateX(0deg);
        transform: rotateX(0deg);
        width: 450px;
        /* border-top: 2px solid #D8312A; */
        height: 450px;
        position: absolute;
        left: 0;
        right: 0;
        margin: auto;
        top: 0;
        bottom: 0;
        padding: 40px 40px;
        background: #35394a;
        background: -webkit-gradient(linear, left bottom, right top, color-stop(0%, #35394a), color-stop(100%, rgb(0, 0, 0)));
        background: -webkit-linear-gradient(230deg, rgba(53, 57, 74, 0) 0%, rgb(0, 0, 0) 100%);
        background: linear-gradient(230deg, rgba(53, 57, 74, 0) 0%, rgb(0, 0, 0) 100%);
    }
    .login-form .login-title{
        color: #fff;line-height: 35px;margin-bottom: 35px;font-size: 35px;
    }
    .login-form .login-title span{
        font-size: 16px;
        font-weight: 700;margin-right: 10px;
    }
    .login-form .login-note,.login-form .refresh-captcha{
        color: #A3A3A3;margin-bottom: 15px;
    }
    .login-form .refresh-captcha{
        text-align: right;
    }
    .login-form .login-captcha{
        height: 40px;float: right;cursor: pointer;border-radius: 3px;
    }
    .login-form .login-btn{
        width: 100%;font-size: 16px;
    }
</style>
