<template>
    <div class="footer">
        Copyright © Powered By Agent System 2022
    </div>
</template>
