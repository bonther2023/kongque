<template>
    <header  class="header">
        <div class="header-logo" style="box-shadow: 0 1px 1px rgba(0,0,0,.1);padding-left: 15px">
            <span><img src="../../assets/img/logo.png" alt=""></span>
        </div>
<!--        <div class="menu">-->
<!--            <el-menu-->
<!--                :default-active="active"-->
<!--                background-color="#00bcd4"-->
<!--                text-color="#fff" mode="horizontal"-->
<!--                :router="true"-->
<!--                :collapse-transition="false"-->
<!--                active-text-color="#0a03ff">-->
<!--                <el-menu-item index="/">-->
<!--                    <i class="fa fa-home" style="margin-right: 8px"></i>-->
<!--                    <span slot="title">我的首页</span>-->
<!--                </el-menu-item>-->
<!--                <el-menu-item index="/canal">-->
<!--                    <i class="fa fa-user-o" style="margin-right: 8px"></i>-->
<!--                    <span slot="title">渠道管理</span>-->
<!--                </el-menu-item>-->
<!--                <el-menu-item index="/flow">-->
<!--                    <i class="fa fa-bar-chart" style="margin-right: 8px"></i>-->
<!--                    <span slot="title">效果报表</span>-->
<!--                </el-menu-item>-->
<!--                <el-menu-item index="/info">-->
<!--                    <i class="fa fa-gears" style="margin-right: 8px"></i>-->
<!--                    <span slot="title">基本设置</span>-->
<!--                </el-menu-item>-->
<!--                <el-menu-item index="/trade">-->
<!--                    <i class="fa fa-bitcoin" style="margin-right: 8px"></i>-->
<!--                    <span slot="title">结算信息</span>-->
<!--                </el-menu-item>-->
<!--            </el-menu>-->
<!--        </div>-->
        <div class="header-user">
            <div style="float: left;padding-left: 30px">
                <i class="fa fa-user-o"></i> 昵称：{{ username }}
                <span style="color: #b9c1cc;padding-left: 5px;margin-right: 10px"> | </span>
                <span style=""><i class="fa fa-yen"></i> 余额：{{ balance }}</span>
                <span v-if="rebate" style="color: #56ff2f;padding-left: 5px;"> ( 佣金比：{{ rebate }}% )</span>
            </div>
            <div style="float: right">
                <span style="cursor: pointer" @click="logout"><i class="fa fa-sign-out"></i> 退出</span>
            </div>
        </div>
    </header>
</template>
<script>
    import {mapGetters} from 'vuex';
    export default {
        computed: {
            ...mapGetters(['active','routers','rebate','username','balance']),
        },
        data: function() {
            return {

            }
        },
        created(){

        },
        methods:{
            logout() {
                this.$notify({
                    title: '成功',
                    message: '稍等，即将退出......',
                    type: 'success',
                    duration: '2000',
                    onClose:() =>{
                        this.$store.dispatch('userLogout').then(()=>{
                            this.$router.push({name:'login'});
                        });
                    }
                });
            }
        }
    }
</script>
<style scoped>

</style>
