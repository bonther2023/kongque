<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
                <div class="panel-header">
                    <div class="panel-title">
                        基本信息
                    </div>
                </div>
                <div class="panel-main">
                    <el-form :model="form_base" class="form" ref="form_base" label-width="100px">
                        <el-form-item label="UUID：" prop="id">
                            <el-input readonly v-model="form_base.id"></el-input>
                        </el-form-item>
                        <el-form-item label="名称：" prop="username">
                            <el-input readonly v-model="form_base.username"></el-input>
                        </el-form-item>
                        <el-form-item :rules="[{ required: true, message: '请填写昵称', trigger: 'blur'}]" label="昵称："
                                      prop="nickname">
                            <el-input v-model="form_base.nickname" placeholder="请填写昵称"></el-input>
                        </el-form-item>
                        <el-form-item label="qq：" prop="qq">
                            <el-input v-model="form_base.qq" placeholder="请填写qq号码"></el-input>
                        </el-form-item>
                    </el-form>
                </div>
                <div class="panel-header">
                    <div class="panel-title">
                        财务信息
                    </div>
                </div>
                <div class="panel-main">
                    <el-form :model="form_base" class="form" ref="form_base" label-width="100px">
                        <el-form-item label="联系人：" :rules="[{ required: true, message: '请填写联系人', trigger: 'blur'}]" prop="name">
                            <el-input v-model="form_base.name"  placeholder="请填写联系人"></el-input>
                        </el-form-item>
                        <el-form-item label="银行名称：" :rules="[{ required: true, message: '请填写银行名称', trigger: 'blur'}]" prop="bank">
                            <el-input v-model="form_base.bank"  placeholder="请填写银行名称"></el-input>
                        </el-form-item>
                        <el-form-item label="银行卡号：" :rules="[{ required: true, message: '请填写银行卡号', trigger: 'blur'}]" prop="card">
                            <el-input v-model="form_base.card"  placeholder="请填写银行卡号"></el-input>
                        </el-form-item>
                        <el-form-item style="margin-top: 50px">
                            <el-button type="primary"  :loading="buttonLoading"
                                       :disabled="formDisabled" @click="update()">{{buttonTitle}}</el-button>
                        </el-form-item>
                    </el-form>
                </div>
        </div>
    </div>
</template>

<script>
    import {UserUpdate,UserInfo,Password} from '@/utils/request';
    export default {
        data() {
            return {
                form_base: {
                    id: 0,
                    username: '',
                    nickname: '',
                    qq: '',
                    name: '',
                    bank: '',
                    card: '',
                },
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                activeName: 'first'
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/info');
            this.$store.dispatch('setUsername', this.$cookie.get('username'));
            this.$store.dispatch('setRebate', this.$storage.get('user_rebate'));
            this.user();
        },
        methods: {
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.form_base = {
                            id: detail.id,
                            username: detail.username,
                            nickname: detail.nickname,
                            qq: detail.qq,
                            name: detail.name,
                            bank: detail.bank,
                            card: detail.card,
                        };
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
            //更新
            update(){
                this.$refs['form_base'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        UserUpdate({params:this.$crypto.encrypt(this.form_base)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$cookie.set('username', this.form_base.nickname, { expires: '7d' });
                                this.$store.dispatch('setUsername', this.form_base.nickname);
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                });
                            }
                        });
                    }
                });
            },
        }
    }
</script>

<style scoped>
    .panel-info .panel-main {
        padding: 20px 25px 0 0;
    }
</style>
