<template>
    <div class="panel-content">
        <div class="panel-body panel-home">
            <div class="panel-header">
                <div class="panel-title">
                    重要提醒
                </div>
            </div>
            <el-alert :closable="false" class="notice">
                <template slot="title">
                    <p style="font-size: 16px;font-weight: 700;color: red">！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！</p>
                </template>
                <template>
                    <p style="color: red;font-size: 14px">1、为避免不生成结算数据，新账户首次登录请务必在 <em style="font-weight: 700;color:red">我的资料</em> 中添加银行卡信息</p>
                    <p style="color: red;font-size: 14px">2、代理资金自动结算为 <em style="font-weight: 700;color:red">100</em>  元起结，每天晚上凌晨12点整自动生成结算数据</p>
                    <p style="color: red;font-size: 14px">3、由于凌晨银行风控较严，为保障结算安全，结算佣金会在 8:00 - 15:00 下发至您的账户，请注意查收</p>
                    <p style="font-size: 16px;font-weight: 700;color: red">！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！</p>
                </template>
            </el-alert>
        </div>
    </div>
</template>

<script>
    import {UserInfo,UserReport} from '@/utils/request';
    export default {
        data() {
            return {
                userInfo: null,
                reportData: null
            }
        },
        created(){

        },
        activated(){
            let username = this.$cookie.get('username');
            this.$store.dispatch('setActive', '/');
            this.$store.dispatch('setUsername', username);
            this.user();
        },
        methods: {
            report(){
                UserReport().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.reportData = detail;
                    }
                });
            },
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.userInfo = detail;
                        this.$storage.set('user_rebate', detail.rebate);
                        this.$store.dispatch('setRebate', detail.rebate);
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
        }
    }
</script>

<style scoped>
    .box-message{
        margin: 15px 0;
    }
    .input{
        border: 2px solid #00bcd4;
        color: #000;
        height: 35px;
        line-height: 35px;
        padding-left: 15px;
        width: 700px;background: #fff
    }
    .btn-copy{
        background: #00bcd4;cursor: pointer;color: #fff;border-color: #00bcd4 !important;
    }
    .copy-span{
        line-height: 35px;
        width: 90px;
        text-align: right;
    }
    input.input{
        outline: -webkit-focus-ring-color auto 0 !important;
        outline:none !important;
    }
    button.btn-copy{
        outline: -webkit-focus-ring-color auto 0 !important;
        outline:none !important;border: none !important;
        width: 70px !important;height: 35px !important;padding: 0 !important;
    }
    button.btn-copy:hover,button.btn-copy:focus{
        background: #00bcd4;cursor: pointer;color: #fff;
        border: none !important;
    }
    .box-message .el-button {
        border-radius: 0;
    }
    .notice{
        color: #f56c6c;margin-bottom: 15px;
        border: 1px solid #fde2e2;
        background-color: #fef0f0;
    }
    .panel-title .el-button{
        float: right
    }

</style>
