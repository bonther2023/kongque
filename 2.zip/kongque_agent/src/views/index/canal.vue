<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    效果报表
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="primary" icon="fa fa-undo" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()" size="medium" v-model="params.kwd" clearable placeholder="请输入渠道ID或者名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="数据加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="UID" width="100"></el-table-column>
                    <el-table-column align="center" prop="username" label="用户名" width="100"></el-table-column>
                    <el-table-column align="center" prop="balance" label="余额" width="150"></el-table-column>
                    <el-table-column align="center" prop="canal_rebate" label="分成" width="100">
                        <template slot-scope="scope">
                            {{ scope.row.canal_rebate }}%
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="100">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="login_at" label="最近登录" width="165"></el-table-column>
                    <el-table-column label="操作" >
                        <template slot-scope="scope">
                            <el-button @click="password(scope.row)" icon="fa fa-edit" type="success" size="mini" plain> 密码</el-button>
                            <el-button @click="login(scope.row)" icon="fa fa-sign-in" type="primary" size="mini" plain> 授权</el-button>
                            <el-button v-if="scope.row.status == 1" @click="lock(scope.row.id)" icon="fa fa-lock"
                                       type="danger" size="mini" plain> 锁定
                            </el-button>
                            <el-button v-if="scope.row.status == 2" @click="active(scope.row.id)"
                                       icon="fa fa-unlock-alt" size="mini" plain> 启用
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="<<"
                                   next-text=">>"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog
                :title="dialog.title" top="20vh"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form"  label-width="120px">
                    <el-form-item label="用户名：" prop="username">
                        <el-input readonly v-model="form.username"  placeholder="用户名"></el-input>
                    </el-form-item>
                    <el-form-item label="昵称：" prop="nickname">
                        <el-input readonly v-model="form.nickname"  placeholder="昵称"></el-input>
                    </el-form-item>
                    <el-form-item label="新密码：" :rules="[{ required: true, message: '请填写新密码', trigger: 'blur'}]" prop="new_password">
                        <el-input type="password" v-model="form.new_password"  placeholder="请填写新密码"></el-input>
                    </el-form-item>
                    <el-form-item label="确认密码：" :rules="[{ required: true, message: '请再次填写密码', trigger: 'blur'}]" prop="check_password">
                        <el-input type="password" v-model="form.check_password"  placeholder="请再次填写密码"></el-input>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                               :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {CanalList,CanalUpdate,CanalLock,CanalActive,Configs,UserInfo} from '@/utils/request';
    export default {
        data() {
            return {
                listData: [],//列表数据
                params: {page: 1, kwd: ''},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    username: '',
                    nickname: '',
                    new_password: '',
                    check_password: '',
                },
                dialog: {
                    title: '',
                    show: false,
                },
                canal_link: ''
            }
        },
        created(){

        },
        activated(){
            this.user();
            this.rebate = this.$storage.get('user_rebate');
            this.$store.dispatch('setActive', '/canal');
            this.$store.dispatch('setUsername', this.$cookie.get('username'));
            this.$store.dispatch('setRebate', this.$storage.get('user_rebate'));
            this.canalLink();
            this.list();
        },
        methods: {
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
            login(info){
                let params = this.$crypto.encrypt({cid:info.id, aid: info.agent_id});
                let target = this.canal_link + "/authorize?params=" + encodeURIComponent(params);
                window.open(target, '_blank');
            },
            canalLink(){
                Configs().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.canal_link = detail;
                    }
                });
            },
            password(info){
                this.form = {
                    id: info.id,
                    username: info.username,
                    nickname: info.nickname,
                    new_password: '',
                    check_password: '',
                };
                this.dialog.title = '修改密码';
                this.dialog.show = true;
            },
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        CanalUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    duration: '2000',
                                    message: res.msg
                                });
                            }else {
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose: () => {
                                        this.dialog.show = false;
                                    }
                                });
                            }
                        });
                    }
                });
            },
            //锁定
            lock(id){
                CanalLock({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            duration: '2000',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //激活
            active(id){
                CanalActive({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            duration: '2000',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                CanalList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            duration: '2000',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
        }
    }
</script>

<style scoped>

</style>
