<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    修改密码
                </div>
            </div>
            <div class="panel-main">
                <el-form :model="form_pass" class="form" ref="form_pass" label-width="130px">
                    <el-form-item label="旧密码：" :rules="[{ required: true, message: '请填写旧密码', trigger: 'blur'}]" prop="old_password">
                        <el-input type="password" v-model="form_pass.old_password"  placeholder="请填写旧密码"></el-input>
                    </el-form-item>
                    <el-form-item label="新密码：" :rules="[{ required: true, message: '请填写新密码', trigger: 'blur'}]" prop="new_password">
                        <el-input type="password" v-model="form_pass.new_password"  placeholder="请填写新密码"></el-input>
                    </el-form-item>
                    <el-form-item label="确认密码：" :rules="[{ required: true, message: '请再次填写密码', trigger: 'blur'}]" prop="check_password">
                        <el-input type="password" v-model="form_pass.check_password"  placeholder="请再次填写密码"></el-input>
                    </el-form-item>
                    <el-form-item style="margin-top: 50px">
                        <el-button type="primary"  :loading="buttonLoading"
                                   :disabled="formDisabled" @click="password()">{{buttonTitle}}</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
    import {UserUpdate,UserInfo,Password} from '@/utils/request';
    export default {
        data() {
            return {
                form_pass: {
                    old_password: '',
                    new_password: '',
                    check_password: '',
                },
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                activeName: 'first'
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/password');
            this.$store.dispatch('setUsername', this.$cookie.get('username'));
            this.$store.dispatch('setRebate', this.$storage.get('user_rebate'));
            this.user();
        },
        methods: {
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
            password(){
                this.$refs['form_pass'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        Password({params:this.$crypto.encrypt(this.form_pass)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.form_pass.old_password = '';
                                this.form_pass.new_password = '';
                                this.form_pass.check_password = '';
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                });
                            }
                        });
                    }
                });
            },
        }
    }
</script>

<style scoped>
    .panel-info .panel-main {
        padding: 20px 25px 0 0;
    }
</style>
