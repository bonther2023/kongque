// vue.config.js
module.exports = {
    devServer: {
        proxy: {
            '/agent': {
                target: 'http://api.baigtl.com',//http://www.aftersale.bh
                changeOrigin: true,
                ws: true,
                pathRewrite: {
                    // '^/api': ''
                }
            },
        }
    }
}
