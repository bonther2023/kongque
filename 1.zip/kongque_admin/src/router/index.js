import Vue from 'vue';
import Router from 'vue-router';

// 按需（懒）加载（vue实现）      @ is an alias to /src
const Layout = () => import('@/views/layouts/layout.vue');// 布局组件
const Login = () => import('@/views/auth/login.vue');// 登录
const Main = () => import('@/views/index/main.vue');// 首页
const Manager = () => import('@/views/user/manager.vue');// 管理人员
const Agent = () => import('@/views/user/agent.vue');// 代理
const Canal = () => import('@/views/user/canal.vue');// 渠道
const Pay = () => import('@/views/setting/pay.vue');// 支付
const Handle = () => import('@/views/setting/handle.vue');// 批量操作
const Config = () => import('@/views/setting/config.vue');// 配置
const Custom = () => import('@/views/setting/custom.vue');// 客服
const Ad = () => import('@/views/setting/ad.vue');// 广告
const Category = () => import('@/views/content/category.vue');// 视频类目
const Tag = () => import('@/views/content/tag.vue');// 视频标签
const Photo = () => import('@/views/content/photo.vue');// 图片
const Harlot = () => import('@/views/content/harlot.vue');// 楼凤
const Novel = () => import('@/views/content/novel.vue');// 小说
const Video = () => import('@/views/content/video.vue');// 视频
const VideoUpate = () => import('@/views/content/update.vue');// 视频编辑
const Flow = () => import('@/views/finance/flow.vue');// 流量趋势
const Order = () => import('@/views/finance/order.vue');// 订单
const Monitor = () => import('@/views/finance/monitor.vue');// 监控
const Report = () => import('@/views/finance/report.vue');// 报表
const Trade = () => import('@/views/finance/trade.vue');// 结算
const Count = () => import('@/views/finance/count.vue');// 统计
const User = () => import('@/views/user/user.vue');// 用户
const Error = () => import('@/views/page/404.vue');//404

Vue.use(Router);

const originalPush = Router.prototype.push;
Router.prototype.push = function (location) {
    return originalPush.call(this, location).catch(err => err);
};

//设置不需要权限的公共页面
export const constantRouterMap = [
    {path: '', name: 'login', component: Login, meta: {title: '登录'}},
    {
        path: '/main', component: Layout,
        children: [
            {path: '/main', name: 'main', component: Main, meta: {title: '首页'}},
            {path: '/error/404', name: 'error', component: Error, meta: {title: '404'}},
        ],
    },
];

//实例化vue的时候只挂载constantRouter
export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: constantRouterMap
});


//异步挂载的路由
//动态需要根据权限加载的路由表
//show：菜单是否展示，title:页面title
export const asyncRouterMap = [
    {
        path: '/config',
        component: Layout,
        title: '系统管理',
        icon: 'fa fa-gears',
        children: [
            {
                path: '/config',
                name: 'config',
                component: Config,
                meta: {title: '系统设置', show: true}
            },
            {
                path: '/monitor',
                name: 'monitor',
                component: Monitor,
                meta: {title: '监控中心', show: true}
            },
            {
                path: '/pay',
                name: 'pay',
                component: Pay,
                meta: {title: '支付管理', show: true}
            },
            {
                path: '/custom',
                name: 'custom',
                component: Custom,
                meta: {title: '客服消息', show: true}
            },
            {
                path: '/ad',
                name: 'ad',
                component: Ad,
                meta: {title: '广告管理', show: true}
            },
            {
                path: '/handle',
                name: 'handle',
                component: Handle,
                meta: {title: '批量操作', show: true}
            },
        ],
    },
    {
        path: '/order',
        component: Layout,
        title: '财务管理',
        icon: 'fa fa-yen',
        children: [
            {
                path: '/order',
                name: 'order',
                component: Order,
                meta: {title: '订单管理', show: true}
            },
            {
                path: '/flow',
                name: 'flow',
                component: Flow,
                meta: {title: '流量趋势', show: true}
            },
            {
                path: '/report',
                name: 'report',
                component: Report,
                meta: {title: '报表统计', show: true}
            },
            {
                path: '/count',
                name: 'count',
                component: Count,
                meta: {title: '数据统计', show: true}
            },
            {
                path: '/trade',
                name: 'trade',
                component: Trade,
                meta: {title: '结算管理', show: true}
            },
        ],
    },
    {
        path: '/manager',
        component: Layout,
        title: '用户管理',
        icon: 'fa fa-user-o',
        children: [
            {
                path: '/canal',
                name: 'canal',
                component: Canal,
                meta: {title: '渠道管理', show: true}
            },
            {
                path: '/agent',
                name: 'agent',
                component: Agent,
                meta: {title: '代理管理', show: true}
            },
            {
                path: '/manager',
                name: 'manager',
                component: Manager,
                meta: {title: '管理人员', show: true}
            },
            {
                path: '/user',
                name: 'user',
                component: User,
                meta: {title: '会员管理', show: true}
            },
        ],
    },
    {
        path: '/video',
        component: Layout,
        title: '内容管理',
        icon: 'fa fa-file-video-o',
        children: [
            {
                path: '/video',
                name: 'video',
                component: Video,
                meta: {title: '视频管理', show: true}
            },
            {
                path: '/harlot',
                name: 'harlot',
                component: Harlot,
                meta: {title: '楼凤管理', show: true}
            },
            {
                path: '/novel',
                name: 'novel',
                component: Novel,
                meta: {title: '小说管理', show: true}
            },
            {
                path: '/photo',
                name: 'photo',
                component: Photo,
                meta: {title: '图片管理', show: true}
            },
            {
                path: '/video/update',
                name: 'video_update',
                component: VideoUpate,
                meta: {title: '视频编辑', show: false}
            },
            {
                path: '/tag',
                name: 'tag',
                component: Tag,
                meta: {title: '标签管理', show: true}
            },
            {
                path: '/category',
                name: 'category',
                component: Category,
                meta: {title: '类目管理', show: true}
            },
        ],
    },
    {
        path: '*',
        redirect: '/error/404'
    }
];


