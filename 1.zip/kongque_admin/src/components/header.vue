<template>
    <transition
        name="slide-down">
        <header class="app-header-wrapper" :style="{'height': headerHeight+'px','line-height': headerHeight+'px','background': headerBackColor}" v-show="show">
            <div class="app-header-left">
                <span class="left-btn" @click="handleClick('back')" v-if="showBack">
                    <van-icon name="arrow-left" color="#888"/>
                </span>
            </div>
            <div class="app-header-middle" :style="{'font-size': titleFontSize+'px','color':titleColor}" v-cloak>
                <slot name="title">
                    {{ title }}
                </slot>
            </div>
            <div class="app-header-right">
                <slot name="actions"
                      v-for="(action, actionIdx) in actions"
                      :icon="action.icon"
                      :route="action.route">
                    <van-btn
                        icon="icon"
                        @click.native="handleClick('action', {actionIdx, route: action.route})">
                        <van-icon color="white" v-if="action.icon" class="app-header-icon">{{ action.icon }}</van-icon>
                    </van-btn>
                </slot>
            </div>
        </header>
    </transition>
</template>

<script>
    import {mapState} from 'vuex';
    import EventBus from '@/core/event-bus';

    export default {
        computed: {
            ...mapState('appShell/appHeader', [
                'show',
                'showMenu',
                'showBack',
                'showLogo',
                'logoIcon',
                'title',
                'titleFontSize',
                'headerHeight',
                'headerBackColor',
                'titleColor',
                'actions'
            ]),
            ...mapState('appShell/common', [
                'isPageSwitching'
            ])
        },
        created (){

        },
        methods: {

            /**
             * 处理按钮点击事件
             *
             * @param {string} source 点击事件源名称 menu/logo/action
             * @param {Object} data 随点击事件附带的数据对象
             */
            handleClick(source, {actionIdx, route} = {}) {
                // 页面正在切换中，不允许操作，防止滑动效果进行中切换
                if (this.isPageSwitching) {
                    return;
                }
                let eventData = {};

                // 点击右侧动作按钮，事件对象中附加序号
                if (source === 'action') {
                    eventData.actionIdx = actionIdx;
                }

                // 发送给父组件，内部处理
                this.$emit(`click-${source}`, eventData);

                // 发送全局事件，便于非父子关系的路由组件监听
                EventBus.$emit(`app-header:click-${source}`, eventData);

                // 如果传递了路由对象，进入路由
                if (route) {
                    this.$router.push(route);
                }
            }
        }
    };
</script>

<style scoped>
    .app-header-wrapper{
        display: flex;
        transition:transform 0.3s ease-out;padding:0;
        background: #131a3c;color: #e8e8e8;
        justify-content:space-between;position: fixed;z-index: 1000;width: 100%;
    }
    .app-header-left .left-btn{
        margin-left: 10px;
    }
    .app-header-middle{
        text-align:center;
        white-space:nowrap;
        text-overflow:ellipsis;
        overflow: hidden;
    }
    .app-header-left,.app-header-right{
        width: 52px;line-height: 55px;
    }

</style>
