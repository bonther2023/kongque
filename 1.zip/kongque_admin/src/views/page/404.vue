<template>
    
</template>

<script>
    export default {
        data() {
            return {

            }
        },
        created(){
            this.$store.dispatch('setActive', '/main');
        },
        methods: {

        }
    }
</script>

<style scoped>

</style>
