<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    广告管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column label="广告位置" width="250">
                        <template slot-scope="scope">
                            <span v-for="(pos,pi) in position" v-if="pi == scope.row.position"> {{ pos }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="height" label="广告高度" width="120"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>
                                修改
                            </el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">
                    <el-form-item :rules="[{ required: true, message: '请选择广告位置', trigger: 'blur'}]" label="广告位置："
                                  prop="position">
                        <el-select v-model="form.position" placeholder="请选择广告位置">
                            <el-option
                                v-for="(pos,index) in position"
                                :key="index"
                                :label="pos"
                                :value="index">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请填写广告宽度', trigger: 'blur'}]" label="广告宽度："
                                  prop="width">
                        <el-input clearable v-model="form.width" placeholder="请填写广告宽度"></el-input>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请填写广告高度', trigger: 'blur'}]" label="广告高度："
                                  prop="height">
                        <el-input clearable v-model="form.height" placeholder="请填写广告高度"></el-input>
                    </el-form-item>
                    <el-form-item required label="广告物料：">
                        <el-button type="primary" icon="fa fa-plus" @click="add()" size="mini"> 添加</el-button>
                    </el-form-item>
                    <el-form-item v-if="form.thumb.length > 0" v-for="(g,gi) in form.thumb">
                        <el-input style="width: 150px;;margin-right: 10px" v-model="g.title" placeholder="标题"></el-input>
                        <el-input style="width: 300px;margin-right: 10px" v-model="g.img" placeholder="图片地址"></el-input>
                        <el-input style="width: 300px" v-model="g.link" placeholder="跳转地址"></el-input>
                        <el-button icon="fa fa-trash" v-if="gi > 0" style="margin-left: 15px" type="info" size="mini" @click="del(gi)"> 删除</el-button>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {AdList,AdUpdate,AdDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    thumb: [{title: '', img: '', link: ''}],
                    width: 360,
                    height: '',
                    position: '',
                },
                dialog: {
                    title: '',
                    show: false,
                },
                position: {
                    'banner': '首页轮播',
                    'fen': '首页分割',
                    'show': '视频详情',
                    'channel': '频道专题',
                    'welfare': '福利轮播'
                },
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/ad');
            this.list();
        },
        methods: {
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        AdUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                AdList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form =  {
                    id: 0,
                    thumb: [{title: '', img: '', link: ''}],
                    width: 360,
                    height: '',
                    position: '',
                };
                this.dialog.title = '新增广告';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    thumb: item.thumb,
                    width: item.width,
                    height: item.height,
                    position: item.position,
                };
                this.dialog.title = '编辑广告';
                this.dialog.show = true;
            },
            del(i){
                this.form.thumb.splice(i,1);
            },
            add() {
                this.form.thumb.push({title: '', img: '', link: ''});
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该广告信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    AdDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
