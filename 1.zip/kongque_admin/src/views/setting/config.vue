<template>
    <div class="panel-content">
        <div class="panel-body panel-info" >
            <el-form v-if="form" :model="form" class="form" ref="form" label-width="130px">
                <el-tabs v-model="activeName">
                    <el-tab-pane label="基本设置" name="first">
                        <div class="panel-main">
                            <el-form-item label="登录限制："  prop="login_limit">
                                <el-radio-group v-model="form.login_limit" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="渠道域名：" prop="canal_admin">
                                <el-input  v-model="form.canal_admin" placeholder="渠道域名"></el-input>
                            </el-form-item>
                            <el-form-item label="代理域名：" prop="agent_admin">
                                <el-input  v-model="form.agent_admin" placeholder="代理域名"></el-input>
                            </el-form-item>
                            <el-form-item label="通信地址：" prop="socket_link">
                                <el-input  v-model="form.socket_link" placeholder="通信地址"></el-input>
                            </el-form-item>
                            <el-form-item label="IOS预警：" prop="warning_ios">
                                <el-radio-group v-model="form.warning_ios" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="安卓预警：" prop="warning_android">
                                <el-radio-group v-model="form.warning_android" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="在线统计：" prop="online_time">
                                <el-input  v-model="form.online_time" placeholder="*分钟内的在线人数统计"><template slot="append">分钟</template></el-input>
                            </el-form-item>
                            <el-form-item label="订单预警：" prop="warning_order">
                                <el-input  v-model="form.warning_order" placeholder="订单预警数"><template slot="append">个</template></el-input>
                            </el-form-item>
                            <el-form-item label="订单限制：" prop="limit_order">
                                <el-input  v-model="form.limit_order" placeholder="10分钟允许订单提交的单数"><template slot="append">分钟</template></el-input>
                            </el-form-item>
                            <el-form-item label="结算金额：" prop="trade_money">
                                <el-input  v-model="form.trade_money" placeholder="结算金额"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="话费比列：" prop="wa_bi">
                                <el-input  v-model="form.wa_bi" placeholder="结算金额"><template slot="append">%</template></el-input>
                            </el-form-item>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="APP设置" name="second">
                        <div class="panel-main">
                            <el-form-item  label="视频源站：" prop="video_resource">
                                <el-radio-group v-model="form.video_resource" size="medium">
                                    <el-radio-button v-for="(platform,pi) in platforms" :key="pi"  :label="platform.name">{{ platform.title }}</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="默认价格：" prop="payment_price">
                                <el-radio-group v-model="form.payment_price" size="medium">
                                    <el-radio-button label="0">一日</el-radio-button>
                                    <el-radio-button label="1">一月</el-radio-button>
                                    <el-radio-button label="2">半年</el-radio-button>
                                    <el-radio-button label="3">一年</el-radio-button>
                                    <el-radio-button label="4">永久</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="默认支付：" prop="payment_default">
                                <el-radio-group v-model="form.payment_default" size="medium">
                                    <el-radio-button label="1">微信</el-radio-button>
                                    <el-radio-button label="2">支付宝</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="APP版本号：" prop=" app_version">
                                <el-input  v-model="form.app_version" placeholder="APP版本号,APP内部版本号如此不同则提示更新"></el-input>
                            </el-form-item>
                            <el-form-item label="APK域名：" prop="apk_link">
                                <el-input  v-model="form.apk_link" placeholder="APK域名"></el-input>
                            </el-form-item>
                            <el-form-item label="客服域名：" prop="kefu_link">
                                <el-input  v-model="form.kefu_link" placeholder="客服域名"></el-input>
                            </el-form-item>
                            <el-form-item label="赠送时间：" prop="free_vip_time">
                                <el-input  v-model="form.free_vip_time" placeholder="赠送VIP时间"></el-input>
                            </el-form-item>
<!--                            <el-form-item  label="APP通知：" prop="app_msg_content">-->
<!--                                <el-input  v-model="form.app_msg_content" placeholder="APP通知"></el-input>-->
<!--                            </el-form-item>-->
                            <el-form-item label="跳转域名：" prop="web_link">
                                <el-input  v-model="form.web_link" placeholder="跳转到落地页的域名"></el-input>
                            </el-form-item>
                            <el-form-item label="回调域名：" prop="notify_url">
                                <el-input  v-model="form.notify_url" placeholder="回调域名"></el-input>
                            </el-form-item>
                            <el-form-item label="更新域名：" prop="update_page">
                                <el-input  v-model="form.update_page" placeholder="APP更新跳转的域名"></el-input>
                            </el-form-item>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="普通设置" name="third">
                        <div class="panel-main">
                            <el-form-item label="日卡价格：" prop="day_vip">
                                <el-input  v-model="form.day_vip" placeholder="请填写日卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="月卡价格：" prop="month_vip">
                                <el-input  v-model="form.month_vip" placeholder="请填写月卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="半年价格：" prop="quarter_vip">
                                <el-input  v-model="form.quarter_vip" placeholder="请填写半年卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="年卡价格：" prop="year_vip">
                                <el-input  v-model="form.year_vip" placeholder="请填写年卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="终生价格：" prop="forever_vip">
                                <el-input  v-model="form.forever_vip" placeholder="请填写终生卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="微信支付："  prop="payment_wechat">
                                <el-radio-group v-model="form.payment_wechat" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.payment_wechat == 1" label="微信渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(we,windex) in wePay" @close="closeTag('wet','del',windex)">
                                    {{ we }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.payment_wechat == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 1 || pay.channel == 3) && (pay.type == 1 || pay.type == 3)"
                                        @click="selectTag(pay.title,pay.name,'wet','del')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                            <el-form-item label="支付宝支付："  prop="payment_alipay">
                                <el-radio-group v-model="form.payment_alipay" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.payment_alipay == 1" label="支付宝渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(ali,aindex) in aliPay" @close="closeTag('ali','del',aindex)">
                                    {{ ali }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.payment_alipay == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 1 || pay.channel == 3) && (pay.type == 2 || pay.type == 3)"
                                        @click="selectTag(pay.title,pay.name,'ali','del')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                            <el-form-item label="扫码支付："  prop="payment_code">
                                <el-radio-group v-model="form.payment_code" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.payment_code == 1" label="扫码渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(dcode,dcindex) in codePay" @close="closeTag('code','del',dcindex)">
                                    {{ dcode }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.payment_code == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 1 || pay.channel == 3) && pay.is_code == 1"
                                        @click="selectTag(pay.title,pay.name,'code','del')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                        </div>
                    </el-tab-pane>
                    <el-tab-pane label="话费设置" name="fourth">
                        <div class="panel-main">
                            <el-form-item label="日卡价格：" prop="tel_day_vip">
                                <el-input  v-model="form.tel_day_vip" placeholder="请填写日卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="月卡价格：" prop="tel_month_vip">
                                <el-input  v-model="form.tel_month_vip" placeholder="请填写月卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="半年价格：" prop="tel_quarter_vip">
                                <el-input  v-model="form.tel_quarter_vip" placeholder="请填写半年卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="年卡价格：" prop="tel_year_vip">
                                <el-input  v-model="form.tel_year_vip" placeholder="请填写年卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="终生价格：" prop="tel_forever_vip">
                                <el-input  v-model="form.tel_forever_vip" placeholder="请填写终生卡价格"><template slot="append">元</template></el-input>
                            </el-form-item>
                            <el-form-item label="微信支付："  prop="tel_payment_wechat">
                                <el-radio-group v-model="form.tel_payment_wechat" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.tel_payment_wechat == 1" label="微信渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(we,windex) in telWePay" @close="closeTag('wet','tel',windex)">
                                    {{ we }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.tel_payment_wechat == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 2 || pay.channel == 3) && (pay.type == 1 || pay.type == 3)"
                                        @click="selectTag(pay.title,pay.name,'wet','tel')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                            <el-form-item label="支付宝支付："  prop="tel_payment_alipay">
                                <el-radio-group v-model="form.tel_payment_alipay" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.tel_payment_alipay == 1" label="支付宝渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(ali,aindex) in telAliPay" @close="closeTag('ali','tel',aindex)">
                                    {{ ali }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.tel_payment_alipay == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 2 || pay.channel == 3) && (pay.type == 2 || pay.type == 3)"
                                        @click="selectTag(pay.title,pay.name,'ali','tel')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                            <el-form-item label="扫码支付："  prop="tel_payment_code">
                                <el-radio-group v-model="form.tel_payment_code" size="medium">
                                    <el-radio-button class="guan" label="0">关</el-radio-button>
                                    <el-radio-button label="1">开</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.tel_payment_code == 1" label="扫码渠道：">
                                <el-tag class="select-tag" type="danger" closable v-for="(tcode,tcindex) in telCodePay" @close="closeTag('code','tel',tcindex)">
                                    {{ tcode }}
                                </el-tag>
                            </el-form-item>
                            <div class="tags-pool" v-if="form.tel_payment_code == 1">
                                <el-tag class="art-pool-tag" v-for="pay in pays"
                                        v-if="(pay.channel == 2 || pay.channel == 3) && pay.is_code == 1"
                                        @click="selectTag(pay.title,pay.name,'code','tel')">
                                    {{ pay.title }}
                                </el-tag>
                            </div>
                        </div>
                    </el-tab-pane>
                </el-tabs>
                <el-form-item>
                    <el-button type="primary"  :loading="buttonLoading"
                               :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
    import {Configs,ConfigUpdate,ConfigPlatform} from '@/utils/request';
    export default {
        data() {
            return {
                form: null,
                pays: [],
                aliPay: [],
                wePay: [],
                codePay: [],
                aliPayName: [],
                wePayName: [],
                codePayName: [],
                telAliPay: [],
                telCodePay: [],
                telWePay: [],
                telAliPayName: [],
                telWePayName: [],
                telCodePayName: [],
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                activeName: 'first',
                platforms: [],
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/config');
            this.platform();
            this.getConfig();
        },
        methods: {
            platform(){
                ConfigPlatform().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.platforms = detail;
                });
            },
            //更新
            update(){
                this.buttonLoading = true;
                this.formDisabled = true;
                this.buttonTitle = '保存中...';
                ConfigUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                    this.buttonLoading = false;
                    this.formDisabled = false;
                    this.buttonTitle = '保 存';
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.$cookie.set('video_select', this.form.video_resource, { expires: '30d' });
                        this.$notify({
                            title: '成功',
                            message: res.msg,
                            type: 'success',
                            duration: '1000'
                        });
                    }
                });
            },
            getConfig(){
                this.aliPay = [];
                this.wePay = [];
                this.codePay = [];
                this.aliPayName = [];
                this.wePayName = [];
                this.codePayName = [];
                this.telAliPay = [];
                this.telWePay = [];
                this.telCodePay = [];
                this.telAliPayName = [];
                this.telWePayName = [];
                this.telCodePayName = [];
                Configs().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.form = detail.configs;
                    this.$cookie.set('video_select', detail.configs.video_resource, { expires: '30d' });
                    this.pays = detail.pays;
                    this.aliPayName = this.form.payment_type_alipay ? this.form.payment_type_alipay.split("-") : this.aliPayName;
                    this.wePayName = this.form.payment_type_wechat ? this.form.payment_type_wechat.split("-") : this.wePayName;
                    this.codePayName = this.form.payment_type_code ? this.form.payment_type_code.split("-") : this.codePayName;
                    this.wePayName.filter((wi)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 1 || item.channel == 3) && (item.type == 1 || item.type == 3) && item.name == wi) this.wePay.push(item.title);
                        });
                    });
                    this.aliPayName.filter((ai)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 1 || item.channel == 3) && (item.type == 2 || item.type == 3) && item.name == ai) this.aliPay.push(item.title);
                        });
                    });
                    this.codePayName.filter((ci)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 1 || item.channel == 3) && item.is_code == 1 && item.name == ci) this.codePay.push(item.title);
                        });
                    });
                    this.telAliPayName = this.form.tel_payment_type_alipay ? this.form.tel_payment_type_alipay.split("-") : this.telAliPayName;
                    this.telWePayName = this.form.tel_payment_type_wechat ? this.form.tel_payment_type_wechat.split("-") : this.telWePayName;
                    this.telCodePayName = this.form.tel_payment_type_code ? this.form.tel_payment_type_code.split("-") : this.telCodePayName;
                    this.telWePayName.filter((wi)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 2 || item.channel == 3) && (item.type == 1 || item.type == 3) && item.name == wi) this.telWePay.push(item.title);
                        });
                    });
                    this.telAliPayName.filter((ai)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 2 || item.channel == 3) && (item.type == 2 || item.type == 3) && item.name == ai) this.telAliPay.push(item.title);
                        });
                    });
                    this.telCodePayName.filter((ci)=>{
                        this.pays.filter((item)=>{
                            if((item.channel == 2 || item.channel == 3) && item.is_code == 1 && item.name == ci) this.telCodePay.push(item.title);
                        });
                    });
                });
            },
            closeTag(payment,type,index){
                if(type == 'del'){
                    //普通
                    if(payment == 'wet'){
                        //微信
                        this.wePay.splice(index,1);
                        this.wePayName.splice(index,1);
                        this.form.payment_type_wechat = this.wePayName.join('-');
                    }
                    if(payment == 'ali'){
                        //支付宝
                        this.aliPay.splice(index,1);
                        this.aliPayName.splice(index,1);
                        this.form.payment_type_alipay = this.aliPayName.join('-');
                    }
                    if(payment == 'code'){
                        //支付宝
                        this.codePay.splice(index,1);
                        this.codePayName.splice(index,1);
                        this.form.payment_type_code = this.codePayName.join('-');
                    }
                }
                if(type == 'tel'){
                    //话费
                    if(payment == 'wet'){
                        //微信
                        this.telWePay.splice(index,1);
                        this.telWePayName.splice(index,1);
                        this.form.tel_payment_type_wechat = this.telWePayName.join('-');
                    }
                    if(payment == 'ali'){
                        //支付宝
                        this.telAliPay.splice(index,1);
                        this.telAliPayName.splice(index,1);
                        this.form.tel_payment_type_alipay = this.telAliPayName.join('-');
                    }
                    if(payment == 'code'){
                        //支付宝
                        this.telCodePay.splice(index,1);
                        this.telCodePayName.splice(index,1);
                        this.form.tel_payment_type_code = this.telCodePayName.join('-');
                    }
                }
            },
            selectTag(title,name,payment,type){
                if(type == 'del'){
                    //普通
                    if(payment == 'wet'){
                        //微信
                        this.wePay.push(title);
                        this.wePayName.push(name);
                        this.form.payment_type_wechat = this.wePayName.join('-');
                    }
                    if(payment == 'ali'){
                        //支付宝
                        this.aliPay.push(title);
                        this.aliPayName.push(name);
                        this.form.payment_type_alipay = this.aliPayName.join('-');
                    }
                    if(payment == 'code'){
                        //支付宝
                        this.codePay.push(title);
                        this.codePayName.push(name);
                        this.form.payment_type_code = this.codePayName.join('-');
                    }
                }
                if(type == 'tel'){
                    //话费
                    if(payment == 'wet'){
                        //微信
                        this.telWePay.push(title);
                        this.telWePayName.push(name);
                        this.form.tel_payment_type_wechat = this.telWePayName.join('-');
                    }
                    if(payment == 'ali'){
                        //支付宝
                        this.telAliPay.push(title);
                        this.telAliPayName.push(name);
                        this.form.tel_payment_type_alipay = this.telAliPayName.join('-');
                    }
                    if(payment == 'code'){
                        //支付宝
                        this.telCodePay.push(title);
                        this.telCodePayName.push(name);
                        this.form.tel_payment_type_code = this.telCodePayName.join('-');
                    }
                }

                // if((item.type == 2 || item.type == 3 ) && code == 2){
                //     this.aliPay.push(item.title);
                //     this.aliPayName.push(item.name);
                //     this.form.payment_type_alipay = this.aliPayName.join('-');
                // }
            },
        }
    }
</script>

<style scoped>
    .panel-info .panel-main {
         padding: 20px 25px 0 0;
    }
    .tags-pool{
        padding: 15px;background-color: #fbfdff;margin-left: 35px;margin-bottom: 25px;
        border: 1px solid #dfeffd;white-space: normal;font-size: 14px;
        color: #2f9de2;min-height: 50px;overflow-x: hidden;overflow-y: auto
    }
    .art-pool-tag{
        margin: 0 15px 15px 0;cursor: pointer
    }
    .select-tag{
        margin: 0 15px 15px 0;
    }
</style>
