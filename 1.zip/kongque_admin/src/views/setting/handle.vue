<template>
    <div class="panel-content">
        <div class="panel-body panel-info">
            <el-form :model="formTarget" ref="formTarget" class="form">
                <div class="panel-header">
                    <div class="panel-title">
                        视频链接  <el-select style="margin-left: 35px" size="medium" @change="search()" v-model="formTarget.source">
                                    <el-option v-for="(platform,pi) in platforms" :key="pi" :label="platform.title" :value="platform.name"></el-option>
                                </el-select>
                    </div>
                </div>
                <div class="panel-main" style="padding-left: 15px">
                    <el-form-item>
                        <el-input style="width: 400px" v-model="formTarget.url_old" placeholder="请填写旧的url地址"></el-input>
                        <el-input style="width: 400px;margin-left: 25px" v-model="formTarget.url_new" placeholder="请填写新的url地址"></el-input>
                        <el-button style="margin-left: 25px" type="primary" size="medium" @click="updateTarget()">替 换</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-form :model="formThumb" ref="formThumb" class="form">
                <div class="panel-header">
                    <div class="panel-title">
                        视频封面  <el-select style="margin-left: 35px" size="medium" @change="search()" v-model="formThumb.source">
                                    <el-option v-for="(platform,pi) in platforms" :key="pi" :label="platform.title" :value="platform.name"></el-option>
                                </el-select>
                    </div>
                </div>
                <div class="panel-main" style="padding-left: 15px">
                    <el-form-item>
                        <el-input style="width: 400px" v-model="formThumb.url_old" placeholder="请填写旧的url地址"></el-input>
                        <el-input style="width: 400px;margin-left: 25px" v-model="formThumb.url_new" placeholder="请填写新的url地址"></el-input>
                        <el-button style="margin-left: 25px" type="primary" size="medium" @click="updateThumb()">确 定</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-form :model="formImage" ref="formImage" class="form">
                <div class="panel-header">
                    <div class="panel-title">
                        图片链接
                    </div>
                </div>
                <div class="panel-main" style="padding-left: 15px">
                    <el-form-item>
                        <el-input  style="width: 400px" v-model="formImage.url_old" placeholder="请填写旧的url地址,不要填写http或者https"></el-input>
                        <el-input  style="width: 400px;margin-left: 25px" v-model="formImage.url_new" placeholder="请填写新的url地址,不要填写http或者https"></el-input>
                        <el-button style="margin-left: 25px" type="primary" size="medium" @click="updateImage()">替 换</el-button>
                    </el-form-item>
                </div>
            </el-form>
            <el-form :model="formOos" ref="formOos" class="form" label-width="100px">
                <div class="panel-header">
                    <div class="panel-title">
                        生成URL加密地址（OOS）
                    </div>
                </div>
                <div class="panel-main"  style="padding-left: 15px">
                    <el-form-item label="加密地址：">
                        <el-input readonly v-model="formOos.value"></el-input>
                    </el-form-item>
                    <el-form-item label="链接地址：">
                        <el-input v-model="formOos.key" placeholder="http或者https，链接后面不带/" style="width: 300px"></el-input>
                        <el-button type="primary" size="medium" style="margin-left: 15px" @click="updateOos()">生 成</el-button>
                    </el-form-item>
                </div>
            </el-form>
        </div>
    </div>
</template>

<script>
    import {ConfigPlatform,HandleTarget,HandleThumb,HandleImage} from '@/utils/request';
    export default {
        data() {
            return {
                formTarget: {
                    url_old: '',
                    url_new: '',
                    source: ''
                },
                formThumb: {
                    url_old: '',
                    url_new: '',
                    source: ''
                },
                formImage: {
                    url_old: '',
                    url_new: '',
                },
                formOos: {
                    key: '',
                    value: '',
                },
                platforms: [],
            }
        },
        created(){
            this.platform();
        },
        activated(){
            this.$store.dispatch('setActive', '/handle');
        },
        methods: {
            platform(){
                ConfigPlatform().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.platforms = detail;
                });
            },
            updateOos(){
                if(this.formOos.key){
                    this.formOos.value = this.compile(this.formOos.key);
                }
            },
            compile(code) {
                var c=String.fromCharCode(code.charCodeAt(0)+code.length);
                for(var i=1;i<code.length;i++){
                    c+=String.fromCharCode(code.charCodeAt(i)+code.charCodeAt(i-1));
                }
                return(escape(c));
            },
            //更新
            updateThumb() {
                //HandleTarget,HandleThumb,HandleImage
                if(!this.formThumb.source){
                    this.$notify.error({
                        title: '错误',
                        message: '请选择视频源站'
                    });
                    return false;
                }
                if(!this.formThumb.url_old){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写旧的url地址'
                    });
                    return false;
                }
                if(!this.formThumb.url_new){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写新的url地址'
                    });
                    return false;
                }
                HandleThumb({params:this.$crypto.encrypt(this.formThumb)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.$notify({
                            title: '成功',
                            message: res.msg,
                            type: 'success',
                            duration: '1000'
                        });
                    }
                });
            },
            //更新
            updateTarget() {
                let that = this;
                if(!this.formTarget.source){
                    this.$notify.error({
                        title: '错误',
                        message: '请选择视频源站'
                    });
                    return false;
                }
                if(!this.formTarget.url_old){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写旧的url地址'
                    });
                    return false;
                }
                if(!this.formTarget.url_new){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写新的url地址'
                    });
                    return false;
                }
                HandleTarget({params:this.$crypto.encrypt(this.formTarget)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.$notify({
                            title: '成功',
                            message: res.msg,
                            type: 'success',
                            duration: '1000'
                        });
                    }
                });
            },
            //更新
            updateImage() {
                let that = this;
                if(!this.formImage.url_old){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写旧的url地址'
                    });
                    return false;
                }
                if(!this.formImage.url_new){
                    this.$notify.error({
                        title: '错误',
                        message: '请填写新的url地址'
                    });
                    return false;
                }
                HandleImage({params:this.$crypto.encrypt(this.formImage)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.$notify({
                            title: '成功',
                            message: res.msg,
                            type: 'success',
                            duration: '1000'
                        });
                    }
                });
            },
        }
    }
</script>

<style scoped>
    .panel-info .form {
        padding-bottom: 15px;
    }
</style>
