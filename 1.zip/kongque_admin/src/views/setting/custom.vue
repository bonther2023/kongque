<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-main-header" v-if="customOnline">
                <div class="chat-header">状态：{{ title }}</div>
                <el-button style="float: right;position: relative;top:-36px;right: 15px" @click="clogout()" type="info" size="mini"><i class="fa fa-close"></i> 关闭</el-button>
            </div>
            <div class="panel-main" style="border-top: 1px solid #e8e8e8;" v-if="customOnline">
                <div class="cmenu sidebar-menu">
                    <aside class="main-sidebar">
                        <section class="sidebar" id="menu">
                            <ul id="demo-list">
                                <li v-if="userList.length"  v-for="(user,ui) in userList" :key="ui"
                                    :class=" ui==userActive ? 'active' : ''"
                                    @click="selectUser(ui,user)">
                                    <a href="javascript:void(0)">
                                        <img class="user-avatar" src="../../assets/img/user_avatar.png" alt="">
                                        <span>{{ user.username }}</span>
                                    </a>
                                    <el-badge v-if="user.unread" :value="user.unread" class="item"></el-badge>
                                </li>
                            </ul>
                        </section>
                    </aside>
                </div>
                <div class="panel-body-chat">
                    <div style="position: absolute;top:0;left:0">
                        <el-dialog title="图片预览" :visible.sync="imageShow" width="50%">
                            <img style="max-width: 100%;margin: 0 auto" :src="imageLink" alt="">
                        </el-dialog>
                    </div>
                    <div ref="chatPool" class="chat-pool">
                        <div class="msg-item" v-for="(item,i) in chatList" :key="i">
                            <div class="msg-item-1" v-if="item.type == 1">
                                <div class="msg-item-img">
                                    <img class="user-avatar" src="../../assets/img/user_avatar.png"/>
                                </div>
                                <div class="msg-item-content msg-item-content1">
                                    <div class="chat-title">@{{ item.username }} <span style="margin-left: 10px">@{{ item.created_at }}</span></div>
                                    <div class="message message1" v-html="item.content"></div>
                                </div>
                            </div>
                            <div class="msg-item-2" v-if="item.type == 2">
                                <div class="msg-item-content msg-item-content2">
                                    <div class="chat-title"><span style="margin-right: 10px">@{{ item.created_at }}</span> @{{ item.custom_name }}</div>
                                    <div class="message message2" v-html="item.content"></div>
                                </div>
                                <div class="msg-item-img">
                                    <img class="user-avatar" src="../../assets/img/custom_online.png"/>
                                </div>
                            </div>
                        </div>
                        <div style="height: 10px"></div>
                    </div>
                    <div class="chat-text">
                        <div class="emotion-box" v-if="emotionShow">
                            <ul class="emotion-box-line" v-for="(line, i) in emotionList" :key="i" >
                                <li @click="selectEmoticon(i)" class="emotion-item"><img :src="'https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/' + i + '.gif'"></li>
                            </ul>
                        </div>
                        <div style="display: flex">
                            <el-button @click="openEmotion" class="chat-icon" icon="fa fa-smile-o" type="text"></el-button>
                            <el-upload
                                class="avatar-uploader"
                                :action="upload"
                                :show-file-list="false"
                                name="image"
                                :on-error="handleError"
                                :accept="'image/*'"
                                :on-success="handleSuccess"
                                :before-upload="beforeUpload">
                                <el-button class="chat-icon" :disabled="disabled" icon="fa fa-image" type="text"></el-button>
                            </el-upload>
                        </div>
                        <div ref="contentBox" id="contentBox" autofocus contenteditable="true"  v-html="content" class="html-input"
                             placeholder="请输入内容"
                             @keyup="changeInput"
                             @blur="overInput" ></div>
                        <el-button style="float: right;margin-top: 25px" icon="el-icon-s-promotion" size="medium" @click="say()" type="primary">发送</el-button>
                        <div style="line-height: 10px;color: #a4abb5;margin-top: 35px;">
                            <p>注：enter键快捷发送 </p>
                            <p>截屏图片直接粘贴发送</p>
                            <p>F5刷新后没声音，点击一次页面即可</p>
                        </div>
                    </div>
                </div>
                <div class="panel-body-ip">
                    <el-tabs v-model="tabActive">
                        <el-tab-pane label="访客信息" name="visitor">
                            <div v-if="userActiveInfo">
                                <el-button @click="goorder(userActiveInfo.user_id)" type="primary" size="small"><i class="fa fa-first-order"></i> 订单</el-button>
                                <el-button @click="govip(userActiveInfo.user_id)" type="primary" size="small"><i class="fa fa-ra"></i> 补会员</el-button>
                                <el-input class="visitor" style="margin-top: 10px" placeholder="访客编号" readonly v-model="userActiveInfo.user_id">
                                    <template slot="prepend"><div class="visitor-input">访客编号：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="访客名称" readonly v-model="userActiveInfo.username">
                                    <template slot="prepend"><div class="visitor-input">访客名称：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="注册时间" readonly v-model="userActiveInfo.created_at">
                                    <template slot="prepend"><div class="visitor-input">注册时间：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="绑定手机" readonly v-model="userActiveInfo.mobile">
                                    <template slot="prepend"><div class="visitor-input">绑定手机：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="VIP类型" readonly v-model="userActiveInfo.vip">
                                    <template slot="prepend"><div class="visitor-input">VIP类型：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="过期时间" readonly v-model="userActiveInfo.vip_at">
                                    <template slot="prepend"><div class="visitor-input">过期时间：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="系统名称" readonly v-model="userActiveInfo.app_system">
                                    <template slot="prepend"><div class="visitor-input">系统名称：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="设备型号" readonly v-model="userActiveInfo.app_model">
                                    <template slot="prepend"><div class="visitor-input">设备型号：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="系统版本" readonly v-model="userActiveInfo.app_release">
                                    <template slot="prepend"><div class="visitor-input">系统版本：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="所用网络" readonly v-model="userActiveInfo.app_network">
                                    <template slot="prepend"><div class="visitor-input">所用网络：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="访客IP" readonly v-model="userActiveInfo.ip">
                                    <template slot="prepend"><div class="visitor-input">访客IP：</div></template>
                                </el-input>
                                <el-input class="visitor" placeholder="IP地区" readonly v-model="userActiveInfo.ip_address">
                                    <template slot="prepend"><div class="visitor-input">IP地区：</div></template>
                                </el-input>
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="常用语" name="words">
                            <ul class="words-li">
                                <li v-for="(word,wi) in words" :key="wi">
                                    <span>{{ wi+1 }}、{{ word }}</span>
                                    <el-link @click="wordMessage(word,wi)" class="yingyong" type="primary">应用</el-link>
                                </li>
                            </ul>
                        </el-tab-pane>
                    </el-tabs>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {Custom,CustomUser,CustomLogout} from '@/utils/request';
    export default {
        data: function() {
            return {
                words: [
                    '发送下载地址',
                    '如果到账失败，可能是掉单了，请把微信或支付宝的付款记录详情页，截图发来，这边立即处理',
                    '长按复制分享地址：https://www.96que.com',
                    '这边先为你开通了临时VIP权限，你可以先用着，处理完成后，会自动为你加上VIP时长',
                    '请及时绑定手机，在用户中心自行找回VIP信息',
                    '您可以使用其他支付方式或者支付的时候多等会儿',
                    '如遇视频加载失败，可能是CDN延迟所致，请重启APP或者观看其他视频',
                    'VIP没及时到账，可能受支付或者网络延迟的影响，请稍等几分钟',
                    '30元只是一天的VIP，你的VIP信息已过期',
                    '你的订单超时支付，所以无法到账，会在三个工作日原路退回',
                    '请稍后，正在处理',
                    '请切换下网络或者重启APP',
                    '请发下支付详情',
                ],
                admin: null,
                userActive: 0,
                upload: '',
                userList: [],
                imageShow: false,
                imageLink: '',
                chatList: [],
                custom_ws: '',
                emotionShow: false,
                readonly: true,
                disabled: true,
                websocket: null,
                ping: null,
                audio: null,
                isLock: true,
                system: null,
                title: '',
                order: null,
                visitorData: null,
                orderList: null,
                tabActive: 'visitor',
                userActiveInfo: null,
                content: '',
                autoplay: false,
                emotionList: ['微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭',
                    '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱',
                    '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘',
                    '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼',
                    '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜'],
                customOnline: 0
            }
        },
        created(){
            this.lockInput();
            this.title = '正在连接...';
            this.customOnline = this.$cookie.get('custom_online');
            this.upload = this.$cookie.get('custom_upload');
            this.custom_ws = this.$cookie.get('custom_ws');
            if(this.customOnline){
                this.login();
            }
        },
        activated(){
            this.$store.dispatch('setActive', '/custom');
            this.customOnline = this.$cookie.get('custom_online');
            this.upload = this.$cookie.get('custom_upload');
            this.custom_ws = this.$cookie.get('custom_ws');
            setTimeout(()=>{
                this.$nextTick(()=>{
                    if(this.$refs['chatPool']){
                        this.$refs['chatPool'].scrollTop = this.$refs['chatPool'].scrollHeight
                    }
                });
            },200);
            if(!this.customOnline){
                this.getCustom();
            }
        },
        mounted() {
            this.keyupSubmit();
            // this.keyPaste();
            document.addEventListener('click', ()=>{
                this.autoplay = true;
            });
        },
        methods: {
            //粘贴事件
            keyPaste(){
                let that = this;
                this.$refs.contentBox.addEventListener('paste',function(e){
                    if ( !(e.clipboardData && e.clipboardData.items) ) {
                        return;
                    }
                    for (let i = 0, len = e.clipboardData.items.length; i < len; i++) {
                        let item = e.clipboardData.items[i];
                        if (item.kind === "file" && item.type.split("/")[0] == "image") {
                            let img = item.getAsFile();
                            that.getBase64(img).then(function(ret){
                                that.request(that.upload, {"img":ret}, 'POST').then((result) => {
                                    that.content += '<img class="up-img" style="max-width: 250px;height: auto" src="'+ result +'" />';
                                    that.say();
                                }).catch(()=>{});
                                // document.execCommand("insertImage",false,ret);
                            }).catch(function(ret){});
                        }
                    }
                })
            },
            getBase64(img) {
                return new Promise(function(resolve,reject){
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>{resolve(reader.result)});
                    reader.readAsDataURL(img);
                })

            },
            keyupSubmit(){
                document.onkeydown=(event)=>{
                    if(event.keyCode === 13){
                        event.preventDefault();//禁止回车的默认换行
                    }
                }
            },
            getCustom(){
                Custom().then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.admin = detail;
                        if(this.admin.socket_id && this.admin.online == 2){
                            this.$confirm('当前已有客服人员在线，确认继续连接？', '提示', {
                                confirmButtonText: '连接',
                                cancelButtonText: '取消',
                                type: 'warning'
                            }).then(() => {
                                this.$cookie.set('custom_online', 1, { expires: '7d' });
                                this.customOnline = 1;
                                this.login();
                            }).catch(() => {
                                this.$cookie.delete('custom_online');
                                this.customOnline = 0;
                            });
                        }else{
                            this.$confirm('确认连接进入客服系统？', '提示', {
                                confirmButtonText: '连接',
                                cancelButtonText: '取消',
                                type: 'warning'
                            }).then(() => {
                                this.$cookie.set('custom_online', 1, { expires: '7d' });
                                this.customOnline = 1;
                                this.login();
                            }).catch(() => {
                                this.$cookie.delete('custom_online');
                                this.customOnline = 0;
                            });
                        }
                    }
                });
            },
            login(){
                CustomUser().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.userList = detail.userList;
                        this.upload = detail.kefu + '/api/upload/image';
                        this.$cookie.set('custom_upload', this.upload, { expires: '7d' });
                        this.connect();
                    }
                });
            },
            connect(){
                let wsServer = this.$cookie.get('custom_ws');
                this.websocket = new WebSocket(wsServer);
                let that = this;
                this.websocket.onopen = function (evt) {
                    that.title = '连接成功';
                    //前端循环心跳,停留不断线
                    that.ping = setInterval(()=>{
                        if(!that.$cookie.get('custom_online')){
                            clearInterval(that.ping);
                        }else{
                            that.websocket.send('PING');
                        }
                    }, 10000);
                    // 解锁
                    that.unlockInput();
                    //设置默认信息
                    if(that.userList.length){
                        that.userActiveInfo = that.userList[0];
                        let message = {
                            class: "Service",
                            action: 'login',
                            content: {userList:that.userList}
                        };
                        that.websocket.send(JSON.stringify(message));//通知在线
                        //获取第一个用户的相关数据
                        let message2 = {
                            class: "Service",
                            action: 'chatlog',
                            content: {user_id:that.userActiveInfo.user_id}
                        };
                        that.websocket.send(JSON.stringify(message2));
                    }
                };
                this.websocket.onclose = function (evt) {
                    that.title = '断开连接';
                    if(!that.$cookie.get('custom_online')){
                        clearInterval(that.ping);
                    }else{
                        that.websocket.send('PING');
                    }
                };
                this.websocket.onmessage = function (evt) {
                    let result = JSON.parse(evt.data);
                    switch (result.type) {
                        case 'chat'://客服发送消息给用户
                            that.chatList.push(result.data);
                            setTimeout(()=>{
                                that.$nextTick(()=>{
                                    that.$refs['chatPool'].scrollTop = that.$refs['chatPool'].scrollHeight
                                });
                            },200);
                            break;
                        case 'replay'://客服接受用户发送的消息
                            let chat = result.data.chat;
                            let userInfo = result.data.user_info;
                            if(that.userList.length){
                                if(userInfo.user_id == that.userActiveInfo.user_id){
                                    //当前聊天窗口就是该用户的窗口
                                    that.chatList.push(chat);
                                }else{
                                    //如果用户存在于列表，增加未读消息提示,
                                    //如果用户不存在，则插入第一行
                                    let newUserIn = false;//是否在列表中
                                    that.userList.forEach((item,index)=>{
                                        if(item.user_id == userInfo.user_id){
                                            newUserIn = true;
                                            that.userList[index].unread ++;
                                        }
                                    });
                                    if(newUserIn == false){
                                        //首次消息未读为1
                                        userInfo['unread'] = 1;
                                        that.userList.unshift(userInfo);
                                        that.userActive ++;
                                    }
                                }
                            }else{
                                that.userList.unshift(userInfo);
                                that.chatList.push(chat);
                                that.userActiveInfo = userInfo;
                            }
                            setTimeout(()=>{
                                that.$nextTick(()=>{
                                    that.$refs['chatPool'].scrollTop = that.$refs['chatPool'].scrollHeight
                                });
                            },200);
                            that.aplayAudio();
                            break;
                        case 'chatlog':
                            setTimeout(()=>{
                                //更新当前用户未读消息为0
                                that.userList[that.userActive].unread = 0;
                                that.chatList = result.data.chat;
                                that.$nextTick(()=>{
                                    that.$refs['chatPool'].scrollTop = that.$refs['chatPool'].scrollHeight
                                });
                            },200);
                            break;
                        case 'closeline':
                            that.$cookie.delete('custom_online');
                            that.customOnline = 0;
                            let message = {
                                class: "Service",
                                action: 'offline',
                                content: {'userList' : that.userList}
                            };
                            that.lockInput();
                            //登录
                            that.websocket.send(JSON.stringify(message));
                            that.websocket.close();
                            that.$confirm('您已退出客服连接', '提示', {
                                confirmButtonText: '确认',
                                cancelButtonText: '取消',
                                type: 'warning'
                            }).then(() => {}).catch(() => {});
                            break;
                        default:
                            break;
                    }
                };
                this.websocket.onerror = function (evt, e) {
                    console.log('Error occured: ' + evt.data);
                };
            },
            // 语音播放
            aplayAudio () {
                if(this.autoplay){
                    if(this.audio != null){
                        this.audio = null;
                    }
                    this.audio = new Audio();
                    this.audio.src = require('../../assets/img/tip.mp3');
                    this.audio.play();
                }
            },
            //用户切换
            selectUser(ui,user){
                if(this.userActive != ui){
                    this.userActive = ui;
                    this.userActiveInfo = user;
                    this.orderList = null;
                    this.visitorData = null,
                        this.tabActive = 'visitor';
                    //获取聊天记录
                    let message = {
                        class: "Service",
                        action: 'chatlog',
                        content: {platform:user.platform,user_id:user.user_id}
                    };
                    this.websocket.send(JSON.stringify(message));
                }
            },
            //发送消息
            say() {
                if(!this.userList.length){
                    return false;
                }
                if(!this.content){
                    return false;
                }
                //选中的用户信息
                let message = {
                    class: "Service",
                    action: 'message',
                    content: {content:this.content,user:this.userActiveInfo,custom:this.login}
                };
                this.content = '';
                this.websocket.send(JSON.stringify(message));
            },
            wordMessage(word,i){
                if(!this.userList.length){
                    return false;
                }
                if(i == 0){
                    word = '<a class="download" style="color:#ff542a"  href="javascript:void(0)">点我下载孔雀视频</a>';
                }
                //选中的用户信息
                let message = {
                    class: "Service",
                    action: 'message',
                    content: {content:word,user:this.userActiveInfo}
                };
                this.websocket.send(JSON.stringify(message));
            },
            // 锁住输入框和禁用发送按钮
            lockInput(){
                this.readonly = true;
                this.disabled = true;
            },
            // 解锁输入框和发送按钮
            unlockInput(){
                this.readonly = false;
                this.disabled = false;
            },
            //ajax请求数据
            request(target,params,method){
                method = method ? method : 'GET';
                return new Promise((resolve, reject)=>{
                    $.ajax({
                        type: method,
                        url: target,
                        ContentType: "application/x-www-form-urlencoded",
                        data: params,
                        dataType: "json",
                        success:(result)=>{if(result.code){reject(false)}else{resolve(result.data)}},
                        error: (e)=>{reject(false)}
                    });
                });
            },
            openEmotion(){
                if(this.emotionShow){
                    this.emotionShow = false;
                }else{
                    this.emotionShow = true;
                }
            },
            changeInput(event){
                //防止中文输入的时候出现光标问题
                if(event.keyCode == 13){
                    this.content = event.target.innerHTML;
                    event.target.innerHTML = '';
                    this.say();
                }
            },
            overInput(event){
                this.content = event.target.innerHTML;
            },
            selectEmoticon(i){
                let imgHTML = `<img src="https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/${i}.gif">`;
                this.content  += imgHTML;
                this.emotionShow = false;
            },
            handleSuccess(res, file) {
                this.content += '<img class="up-img" style="max-width: 250px;height: auto" src="'+ res.data +'">';
                this.say();
            },
            handleError(res, file){
                console.log(JSON.stringify(res)); console.log(JSON.stringify(file));
            },
            beforeUpload(file) {
                if(this.disabled){
                    return false;
                }
                const isLt10M = file.size / 1024 / 1024 < 10;
                if (!isLt10M) {
                    this.$message.error('图片不能大于10M');
                }
                return isLt10M;
            },
            showImg(img){
                this.imageLink = img;
                this.imageShow = true;
            },
            goorder(uid){
                let target = window.location.protocol + "//" + window.location.host + "/order?kwd=" + uid;
                window.open(target, '_blank');
            },
            govip(uid){
                let target = window.location.protocol + "//" + window.location.host + "/user?id=" + uid;
                window.open(target, '_blank');
            },
            clogout(){
                let that = this;
                CustomLogout().then((res) => {
                    if(res.code == 0){
                        that.$cookie.delete('custom_online');
                        that.customOnline = 0;
                        let message = {
                            class: "Service",
                            action: 'offline',
                            content: {'userList' : that.userList}
                        };
                        that.lockInput();
                        //登录
                        that.websocket.send(JSON.stringify(message));
                        that.websocket.close();
                    }
                });
            },
        }
    }
</script>

<style scoped>
    .user-avatar{
        width: 50px;
        height: 50px;
        border-radius: 100%;margin-right: 10px;
    }
    .chat-header{
        width: 100%;line-height:45px;display: inline-block;padding-left: 15px;height:45px
    }
    .cmenu {
        width: 200px;min-width:200px;height: calc(100vh - 176px);overflow-x: hidden;overflow-y: auto;display: inline-block;
        border-right: 1px solid #e8e8e8;
    }
    .panel-body-ip{
        overflow: hidden;padding:0 15px;height: calc(100vh - 176px);overflow-y: auto;width: calc(45vw) ;
    }
    .panel-body-chat{
        width: calc(45vw) ;border-right: 1px solid #e8e8e8;height: calc(100vh - 176px);overflow: hidden;
    }
    .cmenu ul{
        padding-inline-start: 0;
        margin-block-start: 0;
        margin-block-end: 0;
    }
    .cmenu ul li{
        position: relative;height: 60px;list-style: none;padding-left:  15px;line-height: 35px;
    }
    .cmenu ul li.active{
        border-bottom: 1px solid #00a2d4;
    }
    .cmenu ul li a {
        display: flex;
    }
    .cmenu ul li a span{
        width: 120px;
        display: inline-block;
        word-break: keep-all;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;color: #333;
        position: relative;top:22px
    }
    .cmenu ul li.active a span{
        color: #00a2d4;
    }
    .main .content .panel-content {
        padding: 0;
    }
    .panel-main{
        display: flex;
    }
    .panel-body-chat .chat-pool{
        height: calc(50vh);overflow-x: hidden;overflow-y: auto;padding:15px 10px 0;
    }
    .panel-body-chat .chat-pool::-webkit-scrollbar{
        display: none;
    }
    .user-avatar{
        width: 40px;
        height: 40px;border-radius: 50%;margin-top: 10px;
    }

    .msg-item{
        margin-bottom: 20px;width: 100%;
    }
    .msg-item-1{
        display: flex;
    }
    .msg-item-2{
        display: flex;
    }
    .msg-item-content{
        vertical-align: top;width: 100%;
    }
    .msg-item-content1{
        text-align: left;padding-left: 8px;
    }
    .msg-item-content2{
        padding-right: 8px;text-align: left;
    }
    .message{
        background: #E5E5E5;display: inline-block;line-height: 20px;padding:8px 15px;border-radius: 5px;
        position: relative;margin-top: 15px;
    }
    .message1:after{
        content: '';
        position: absolute;
        left: -10px;
        top: 10px;
        width: 0;
        height: 0;
        border-style: dashed;
        border-color: transparent;
        overflow: hidden;
        border-width: 10px;
        border-top-style: solid;
        border-top-color: #E5E5E5;
    }
    .message2{
        float: right;background-color: #12B7F5;color: #FFF;line-height: 22px;
    }
    .message2:before{
        content: '';
        position: absolute;
        right: -10px;
        top: 10px;
        width: 0;
        height: 0;
        border-style: dashed;
        border-color: transparent;
        overflow: hidden;
        border-width: 10px;
        border-top-style: solid;
        border-top-color: #12B7F5;
    }
    .msg-item-img{
        min-width: 40px;max-width: 40px;
    }
    .chat-title{
        font-size: 12px;color: #999;
    }
    .msg-item-1 .chat-title{
        position: relative;top:5px
    }
    .msg-item-2 .chat-title{
        position: relative;top:5px;text-align: right;
    }
    .chat-time{
        text-align: center;font-size: 12px;color:#fff;display: inline-block;width: 100%;margin-bottom: 10px;
    }
    .chat-time span{
        background: #cccfd2;padding: 5px 8px;border-radius: 3px;
    }


    .panel-body-chat .chat-text{
        border-top: 1px solid #e8e8e8;padding: 0 15px 15px;position: relative;
    }
    .panel-body-chat .chat-text .chat-icon{
        font-size: 26px;margin-right: 15px;
    }
    .panel-body-chat .chat-text .chat-icon .fa-image{
        font-size: 24px;
    }
    .el-textarea__inner {
        border: none !important;
        padding: 0 !important;
    }
    .el-badge {
        position: absolute;
        top: 5px !important;
        right: 16px !important;
    }
    .chat-avatar .user-avatar{
        width: 40px;
        height: 40px;
    }
    .emotion-box{
        position: absolute;    top: -200px;
        left: 10px;
        width: 352px;
        background: #fff; box-shadow: 0 0 20px rgba(0,0,0,.2);
        border: 1px solid #D9D9D9;border-radius: 5px;padding-bottom: 12px;
    }
    .emotion-box ul {
        padding-inline-start:15px;
    }
    .emotion-box .emotion-item{
        list-style: none;float: left;
        padding: 2px;cursor: pointer;
        border: 1px solid #D9D9D9;margin: -1px 0 0 -1px;
    }
    .emotion-box .emotion-item:hover{
        background: #ffb2b0;
    }
    .html-input{
        height: 150px;overflow-x: hidden;word-break: break-all;
        user-select: text;
        white-space: pre-wrap;
        -webkit-user-select: text;
        text-align: left;
    }
    .html-input::-webkit-scrollbar{
        display: none;
    }
    .html-input:focus{
        border: none;
        outline: none;
    }
    .el-dialog__body {
        padding: 10px 20px 30px !important;
    }
    .visitor{
        margin-bottom: 10px;
    }
    .visitor-input{
        width: 85px;background: #F5F7FA;height: 40px;line-height: 40px;border: 1px solid #DCDFE6;text-align: center;
        vertical-align: middle;border-right: 0;
    }
    .words-li{
        list-style: none;padding-inline-start:0;line-height: 45px;
    }
    .words-li li{
        border-bottom: 1px solid #e9e9e9;cursor: pointer;position: relative;font-size: 12px;
    }
    .words-li li .yingyong{
        font-size: 14px;position: absolute;right:0;bottom: 2px;
    }
</style>
