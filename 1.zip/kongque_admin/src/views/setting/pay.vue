<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    支付管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="正 常" name="1"></el-tab-pane>
                    <el-tab-pane label="锁 定" name="2"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()" size="medium" v-model="params.kwd"  placeholder="请输入支付名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column prop="title" label="名称"  width="150"></el-table-column>
                    <el-table-column prop="name" label="标识" width="120"></el-table-column>
                    <el-table-column align="center" prop="type_text" label="支付方式" width="80">
                        <template slot-scope="scope">
                            <span v-html="scope.row.type_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="channel_text" label="通道" width="80">
                        <template slot-scope="scope">
                            <span v-html="scope.row.channel_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="75">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>
                                修改
                            </el-button>
                            <el-button v-if="scope.row.status == 1" @click="lock(scope.row.id)" icon="fa fa-lock"
                                       type="danger" size="mini" plain> 锁定
                            </el-button>
                            <el-button v-if="scope.row.status == 2" @click="active(scope.row.id)"
                                       icon="fa fa-unlock-alt" type="success" size="mini" plain> 启用
                            </el-button>
                            <el-button @click="copy(scope.row)" icon="fa fa-copy" type="primary" size="mini" plain>
                                复制
                            </el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">

                    <div style="display: flex">
                        <div style="width: 50%">
                            <el-form-item :rules="[{ required: true, message: '请选择支付类型', trigger: 'blur'}]" label="支付类型：" required prop="type">
                                <el-radio-group v-model="form.type">
                                    <el-radio :label="1" border>微信</el-radio>
                                    <el-radio :label="2" border>支付宝</el-radio>
                                    <el-radio :label="3" border>双端</el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请选择支付通道', trigger: 'blur'}]" label="支付通道：" required prop="channel">
                                <el-radio-group v-model="form.channel">
                                    <el-radio :label="1" border>普通</el-radio>
                                    <el-radio :label="2" border>话费</el-radio>
                                    <el-radio :label="3" border>双通道</el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="扫码通道：" required prop="is_code">
                                <el-radio-group v-model="form.is_code" size="medium">
                                    <el-radio-button label="0">否</el-radio-button>
                                    <el-radio-button label="1">是</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写支付名称', trigger: 'blur'}]" label="支付名称："
                                          prop="title">
                                <el-input  v-model="form.title" placeholder="请填写支付名称"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写支付标识', trigger: 'blur'}]" label="支付标识："
                                          prop="name">
                                <el-input  v-model="form.name" placeholder="请填写支付标识"></el-input>
                            </el-form-item>
                            <el-form-item label="支付状态：" required prop="status">
                                <el-radio-group v-model="form.status">
                                    <el-radio :label="1" border>正常</el-radio>
                                    <el-radio :label="2" border>锁定</el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写商户号', trigger: 'blur'}]" label="商户号："
                                          prop="pay_number">
                                <el-input  v-model="form.pay_number" placeholder="请填写商户号"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写商务秘钥', trigger: 'blur'}]" label="商务秘钥："
                                          prop="pay_secret">
                                <el-input  v-model="form.pay_secret" placeholder="请填写商务秘钥"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写通道地址', trigger: 'blur'}]" label="通道地址："
                                          prop="pay_target">
                                <el-input  v-model="form.pay_target" placeholder="请填写通道地址"></el-input>
                            </el-form-item>
                            <el-form-item v-if="form.type == 1 || form.type == 3"  label="通道编码(W)：" prop="payment_w">
                                <el-input  v-model="form.payment_w" placeholder="请填写微信通道编码"></el-input>
                            </el-form-item>
                            <el-form-item v-if="form.type == 2 || form.type == 3"  label="通道编码(A)：" prop="payment_a">
                                <el-input  v-model="form.payment_a" placeholder="请填写支付宝通道编码"></el-input>
                            </el-form-item>
                        </div>
                        <div style="width: 50%">

                            <el-form-item :rules="[{ required: true, message: '请选择请求类型', trigger: 'blur'}]" label="请求类型：" required prop="pay_method">
                                <el-radio-group v-model="form.pay_method">
                                    <el-radio :label="1" border>POST</el-radio>
                                    <el-radio :label="2" border>GET</el-radio>
                                    <el-radio :label="3" border>PJSON</el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请选择请求方式', trigger: 'blur'}]" label="请求方式：" required prop="pay_format">
                                <el-radio-group v-model="form.pay_format">
                                    <el-radio :label="1" border>JSON</el-radio>
                                    <el-radio :label="2" border>FORM</el-radio>
                                    <el-radio :label="3" border>CURL</el-radio>
                                </el-radio-group>
                            </el-form-item>

                            <el-form-item :rules="[{ required: true, message: '请填写支付网址', trigger: 'blur'}]" label="支付网址："
                                          prop="pay_url">
                                <el-input  v-model="form.pay_url" placeholder="请填写支付网址"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写支付账户', trigger: 'blur'}]" label="支付账户："
                                          prop="pay_account">
                                <el-input  v-model="form.pay_account" placeholder="请填写支付账户"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写支付密码', trigger: 'blur'}]" label="支付密码："
                                          prop="pay_password">
                                <el-input  v-model="form.pay_password" placeholder="请填写支付密码"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写回调地址', trigger: 'blur'}]" label="回调地址："
                                          prop="return_notify">
                                <el-input  class="notify-app" v-model="form.return_notify" placeholder="回调地址">
                                    <template slot="prepend">{{ notify }}app/notify/</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写回调输出字符串', trigger: 'blur'}]" label="回调输出："
                                          prop="return_msg">
                                <el-input  v-model="form.return_msg" placeholder="请填写回调输出字符串"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写回调订单号字段名称', trigger: 'blur'}]" label="订单号字段："
                                          prop="return_order">
                                <el-input  v-model="form.return_order" placeholder="请填写回调订单号字段名称"></el-input>
                            </el-form-item>
                            <el-form-item label="成功字段："
                                          prop="return_ok_field">
                                <el-input  v-model="form.return_ok_field" placeholder="请填写回调成功的字段名称"></el-input>
                            </el-form-item>
                            <el-form-item label="成功标识："
                                          prop="return_ok_msg">
                                <el-input  v-model="form.return_ok_msg" placeholder="请填写回调成功的标识"></el-input>
                            </el-form-item>
                        </div>
                    </div>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {PayList,PayUpdate,PayLock,PayActive,PayDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, kwd: '', status: 0},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    title: '',
                    pay_account: '',
                    pay_password: '',
                    pay_url: '',
                    name: '',
                    is_code: 0,
                    type: 3,
                    status: 1,
                    channel: 3,
                    pay_target: '',
                    pay_number: '',
                    pay_secret: '',
                    pay_method: 1,
                    pay_format: 1,
                    return_notify: '',
                    payment_a: '',
                    payment_w: '',
                    return_msg: '',
                    return_order: '',
                    return_ok_field: '',
                    return_ok_msg: '',
                },
                dialog: {
                    title: '',
                    show: false,
                },
                notify: '',
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/pay');
            this.list();
        },
        methods: {
            canal(id){
                this.$router.push({name:'canal',query:{Pay_id: id}});
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        PayUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                PayList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail.lists;
                        this.notify = detail.notify;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form =  {
                    id: 0,
                    title: '',
                    pay_account: '',
                    is_code: 0,
                    pay_password: '',
                    pay_url: '',
                    name: '',
                    type: 3,
                    status: 1,
                    channel: 3,
                    pay_target: '',
                    pay_number: '',
                    pay_secret: '',
                    pay_method: 1,
                    pay_format: 1,
                    return_notify: '',
                    payment_a: '',
                    payment_w: '',
                    return_msg: '',
                    return_order: '',
                    return_ok_field: '',
                    return_ok_msg: '',
                };
                this.dialog.title = '新增支付';
                this.dialog.show = true;
            },
            copy(item){
                this.form =  {
                    id: 0,
                    title: item.title,
                    pay_account: item.pay_account,
                    pay_password: item.pay_password,
                    pay_url: item.pay_url,
                    name: item.name,
                    type: item.type,
                    status: item.status,
                    channel: item.channel,
                    pay_target: item.pay_target,
                    pay_number: item.pay_number,
                    pay_secret: item.pay_secret,
                    pay_method: item.pay_method,
                    pay_format: item.pay_format,
                    return_notify: item.return_notify,
                    payment_a: item.payment_a,
                    payment_w: item.payment_w,
                    return_msg: item.return_msg,
                    return_order: item.return_order,
                    return_ok_field: item.return_ok_field,
                    return_ok_msg: item.return_ok_msg,
                };
                this.dialog.title = '新增支付';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    title: item.title,
                    pay_account: item.pay_account,
                    pay_password: item.pay_password,
                    pay_url: item.pay_url,
                    is_code: item.is_code,
                    name: item.name,
                    type: item.type,
                    status: item.status,
                    channel: item.channel,
                    pay_target: item.pay_target,
                    pay_number: item.pay_number,
                    pay_secret: item.pay_secret,
                    pay_method: item.pay_method,
                    pay_format: item.pay_format,
                    return_notify: item.return_notify,
                    payment_a: item.payment_a,
                    payment_w: item.payment_w,
                    return_msg: item.return_msg,
                    return_order: item.return_order,
                    return_ok_field: item.return_ok_field,
                    return_ok_msg: item.return_ok_msg,
                };
                this.dialog.title = '编辑支付';
                this.dialog.show = true;
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //锁定
            lock(id){
                PayLock({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //激活
            active(id){
                PayActive({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该支付信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    PayDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
