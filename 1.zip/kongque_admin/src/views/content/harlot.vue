<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    楼凤管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="正 常" name="1"></el-tab-pane>
                    <el-tab-pane label="锁 定" name="2"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()"  size="medium" v-model="params.kwd" clearable placeholder="请输入标题名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select size="medium" @change="search()" v-model="params.cid" placeholder="请选择">
                                <el-option label="类目(全部)" value=""></el-option>
                                <el-option
                                    v-for="item in categorys"
                                    :key="item.id"
                                    :label="item.title"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="80"></el-table-column>
                    <el-table-column align="center" label="类目" width="80">
                        <template slot-scope="scope">
                            <span v-for="(cate) in categorys" v-if="cate.id == scope.row.cate_id"> {{ cate.title }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="title" label="标题" width="350" :show-overflow-tooltip="true"></el-table-column>
                    <el-table-column align="center" prop="province" label="省份" width="70"></el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="70">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="created_at" label="创建时间" width="165"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>
                                修改
                            </el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">
                    <div style="display: flex">
                        <div style="width: 50%">
                            <el-form-item :rules="[{ required: true, message: '请填写标题', trigger: 'blur'}]" label="标题："
                                          prop="title">
                                <el-input  v-model="form.title" placeholder="请填写标题"></el-input>
                            </el-form-item>
                            <el-form-item label="类目：" prop="cate_id" >
                                <el-radio-group v-model="form.cate_id" size="medium">
                                    <el-radio-button  v-for="item in categorys" :key="item.id" :label="item.id">{{ item.title }}</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="目标人数：" prop="nums">
                                <el-input  v-model="form.nums" placeholder="请填写目标人数"></el-input>
                            </el-form-item>
                            <el-form-item label="目标年龄：" prop="age">
                                <el-input  v-model="form.age" placeholder="请填写目标年龄"></el-input>
                            </el-form-item>
                            <el-form-item label="详细地址：" prop="address">
                                <el-input  v-model="form.address" placeholder="请填写详细地址"></el-input>
                            </el-form-item>
                            <el-form-item label="联系方式：" prop="tel">
                                <el-input  v-model="form.tel" placeholder="请填写联系方式"></el-input>
                            </el-form-item>
                            <el-form-item label="目标素质：" prop="quality">
                                <el-input  v-model="form.quality" placeholder="请填写目标素质"></el-input>
                            </el-form-item>
                            <el-form-item label="目标外形：" prop="wai">
                                <el-input  v-model="form.wai" placeholder="请填写目标外形"></el-input>
                            </el-form-item>
                            <el-form-item label="服务项目：" prop="project">
                                <el-input  v-model="form.project" placeholder="请填写服务项目"></el-input>
                            </el-form-item>
                            <el-form-item label="价格区间：" prop="price">
                                <el-input  v-model="form.price" placeholder="请填写价格区间"></el-input>
                            </el-form-item>
                            <el-form-item label="其他信息：" prop="other">
                                <el-input  v-model="form.other" placeholder="请填写其他信息"></el-input>
                            </el-form-item>
                            <el-form-item label="状态：" prop="status">
                                <el-radio-group v-model="form.status">
                                    <el-radio :label="1" border>正常</el-radio>
                                    <el-radio :label="2" border>锁定</el-radio>
                                </el-radio-group>
                            </el-form-item>
                        </div>
                        <div style="width: 50%">
                            <el-form-item label="省份：" prop="province">
                                <el-input  v-model="form.province" placeholder="请填写省份"></el-input>
                            </el-form-item>
                            <el-form-item label="城市：" prop="city">
                                <el-input  v-model="form.city" placeholder="请填写城市"></el-input>
                            </el-form-item>
                            <el-form-item label="地区：" prop="region">
                                <el-input  v-model="form.region" placeholder="请填写地区"></el-input>
                            </el-form-item>
                            <el-form-item label="性别：" prop="sex">
                                <el-input  v-model="form.sex" placeholder="请填写性别"></el-input>
                            </el-form-item>
                            <el-form-item label="身高：" prop="height">
                                <el-input  v-model="form.height" placeholder="请填写身高"></el-input>
                            </el-form-item>
                            <el-form-item label="婚否：" prop="marriage">
                                <el-input  v-model="form.marriage" placeholder="请填写婚否"></el-input>
                            </el-form-item>
                            <el-form-item label="优点：" prop="good">
                                <el-input  v-model="form.good" placeholder="请填写优点"></el-input>
                            </el-form-item>
                            <el-form-item label="营业时间：" prop="btime">
                                <el-input  v-model="form.btime" placeholder="请填写营业时间"></el-input>
                            </el-form-item>
                            <el-form-item label="环境设备：" prop="ambient">
                                <el-input  v-model="form.ambient" placeholder="请填写环境设备"></el-input>
                            </el-form-item>
                            <el-form-item label="安全评估：" prop="safe_ment">
                                <el-input  v-model="form.safe_ment" placeholder="请填写安全评估"></el-input>
                            </el-form-item>
                            <el-form-item label="综合评估：" prop="risk_ment">
                                <el-input  v-model="form.risk_ment" placeholder="请填写综合评估"></el-input>
                            </el-form-item>
                            <el-form-item label="信息来源：" prop="resouce">
                                <el-input  v-model="form.resouce" placeholder="请填写信息来源"></el-input>
                            </el-form-item>
                        </div>
                    </div>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {HarlotCategory,HarlotList,HarlotUpdate,HarlotDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, kwd: '', status: 0,cid: ''},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    title: '',
                    cate_id: 15,
                    province: '',
                    city: '',
                    region: '',
                    nums: '',
                    age: '',
                    quality: '',
                    wai: '',
                    project: '',
                    price: '',
                    btime: '',
                    ambient: '',
                    safe_ment: '',
                    risk_ment: '',
                    resouce: '',
                    address: '',
                    tel: '',
                    other: '',
                    sex: '',
                    height: '',
                    marriage: '',
                    good: '',
                    status: 1,
                },
                categorys: [],
                dialog: {
                    title: '',
                    show: false,
                },
            }
        },
        created(){
            this.getCate();
        },
        activated(){
            this.$store.dispatch('setActive', '/harlot');
            this.list();
        },
        methods: {
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            getCate(){
                HarlotCategory().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.categorys = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        HarlotUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                HarlotList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form =  {
                    id: 0,
                    title: '',
                    cate_id: 15,
                    province: '',
                    city: '',
                    region: '',
                    nums: '',
                    age: '',
                    quality: '',
                    wai: '',
                    project: '',
                    price: '',
                    btime: '',
                    ambient: '',
                    safe_ment: '',
                    risk_ment: '',
                    resouce: '',
                    address: '',
                    tel: '',
                    other: '',
                    sex: '',
                    height: '',
                    marriage: '',
                    good: '',
                    status: 1,
                };
                this.dialog.title = '新增楼凤';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    title: item.title,
                    cate_id: item.cate_id,
                    cate_pid: item.cate_pid,
                    province: item.province,
                    city: item.city,
                    region: item.region,
                    nums: item.nums,
                    age: item.age,
                    quality: item.quality,
                    wai: item.wai,
                    project: item.project,
                    price: item.price,
                    btime: item.btime,
                    ambient: item.ambient,
                    safe_ment: item.safe_ment,
                    risk_ment: item.risk_ment,
                    resouce: item.resouce,
                    address: item.address,
                    tel: item.tel,
                    other: item.other,
                    sex: item.sex,
                    height: item.height,
                    marriage: item.marriage,
                    good: item.good,
                    status: item.status,
                };
                this.dialog.title = '编辑楼凤';
                this.dialog.show = true;
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该楼凤信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    HarlotDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
