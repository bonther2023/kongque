<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    视频管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="正 常" name="1"></el-tab-pane>
                    <el-tab-pane label="推 荐" name="2"></el-tab-pane>
                    <el-tab-pane label="锁 定" name="3"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()"  size="medium" v-model="params.kwd" clearable placeholder="请输入标题名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item"  style="width: 100px">
                            <el-select size="medium" @change="search()" v-model="params.source">
                                <el-option v-for="(platform,pi) in platforms" :key="pi" :label="platform.title" :value="platform.name"></el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select size="medium" @change="search()" v-model="params.tid" placeholder="请选择">
                                <el-option label="专题(全部)"  value=""></el-option>
                                <el-option
                                    v-for="item in topics"
                                    :key="item.id"
                                    :label="item.title"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select size="medium" @change="search()" v-model="params.cid" placeholder="请选择">
                                <el-option label="类目(全部)" value=""></el-option>
                                <el-option
                                    v-for="item in categorys"
                                    :key="item.id"
                                    :label="item.title"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          ref="multipleHandle"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="80"></el-table-column>
                    <el-table-column align="center" prop="thumb" label="封面" width="100">
                        <template slot-scope="scope">
                            <el-popover placement="right" trigger="click">
                                <img :src="scope.row.thumb" style="width: 550px;height: auto"/>
                                <img v-if="scope.row.thumb_type == 1" slot="reference" title="点击查看原图" alt="点击查看原图" :src="scope.row.thumb"
                                     style="height: 30px;width: 70px"/>
                                <img v-if="scope.row.thumb_type == 2" slot="reference" title="点击查看原图" alt="点击查看原图" :src="scope.row.thumb"
                                     style="height: 30px;width: 30px"/>
                            </el-popover>
                        </template>
                    </el-table-column>
                    <el-table-column prop="title" label="标题" width="300" :show-overflow-tooltip="true">
                        <template slot-scope="scope">
                            <el-tag v-if="scope.row.free == 2" type="danger" effect="dark" size="mini">限免</el-tag> {{ scope.row.title }}
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="类目" width="80">
                        <template slot-scope="scope">
                            <span v-for="(cate,ci) in categorys" :key="ci" v-if="cate.id == scope.row.category_id"> {{ cate.title }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" label="专题" width="80">
                        <template slot-scope="scope">
                            <span v-for="(topic,ti) in topics" :key="ti" v-if="topic.id == scope.row.topic_id"> {{ topic.title }}</span>
                        </template>
                    </el-table-column>
<!--                    <el-table-column align="center" prop="tag" label="标签" width="80"></el-table-column>-->
                    <el-table-column align="center" prop="view" label="浏览量" width="100"></el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="70">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row.id)" icon="fa fa-edit" type="primary" size="mini" plain>
                                编辑
                            </el-button>
                            <el-button v-if="scope.row.status != 3" @click="lock(scope.row.id)" icon="fa fa-lock"
                                       type="danger" size="mini" plain> 锁定
                            </el-button>
                            <el-button v-if="scope.row.status == 3" @click="active(scope.row.id)"
                                       icon="fa fa-unlock-alt" type="success" size="mini" plain> 启用
                            </el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {VideoCategory,VideoList,VideoLock,VideoActive,VideoDestroy,ConfigPlatform} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, kwd: '', status: 0,source: 'bili',cid: '',tid: ''},
                loading: false,
                categorys: [],
                topics: [],
                platforms: [],
            }
        },
        created(){
            this.platform();
            this.getCate();
            this.params.source = this.$cookie.get('video_select');
        },
        activated(){
            this.$store.dispatch('setActive', '/video');
            this.list();
        },
        methods: {
            platform(){
                ConfigPlatform().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.platforms = detail;
                });
            },
            getCate(){
                VideoCategory().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.categorys = detail.cates;
                    this.topics = detail.topic;
                });
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //列表
            list(){
                this.loading = true;
                VideoList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.$router.push({name:'video_update',query:{source:this.params.source}});
            },
            //编辑
            edit(id) {
                this.$router.push({name:'video_update',query:{id: id, source:this.params.source}});
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //锁定
            lock(id){
                VideoLock({params:this.$crypto.encrypt({id: id, source:this.params.source})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //激活
            active(id){
                VideoActive({params:this.$crypto.encrypt({id: id, source:this.params.source})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该管理员信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    VideoDestroy({params:this.$crypto.encrypt({id: id, source:this.params.source})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
