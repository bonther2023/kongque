<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    标签管理
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                </div>
                <div>
                    <el-tag style="margin: 0 10px 10px 0"
                            :key="ti"
                            v-for="(tag,ti) in tags"
                        closable
                        :disable-transitions="false"
                        @close="destroy(tag.id)">
                        {{tag.name}}
                    </el-tag>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false" style="min-height: calc(100vh - 326px) !important;"
                       :title="dialog.title"
                       :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form"  label-width="120px">
                    <el-form-item label="名称：" prop="name">
                        <el-input v-model="form.name" placeholder="标签名称"></el-input>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                               :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {TagList,TagUpdate,TagDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                tags: [],//列表数据
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    name: '',
                },
                dialog: {
                    title: '',
                    show: false,
                },
                agents: [],
            }
        },
        created(){
        },
        activated(){
            this.list();
            this.$store.dispatch('setActive', '/tag');
        },
        methods: {
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        TagUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.tags = [];
                this.loading = true;
                TagList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.tags = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form = {
                    id: 0,
                    name: '',
                };
                this.dialog.title = '新增';
                this.dialog.show = true;
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该标签信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    TagDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
