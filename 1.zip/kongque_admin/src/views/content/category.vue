<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    类目管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column align="center" prop="icon" label="封面" width="115">
                        <template slot-scope="scope">
                            <img :src="scope.row.icon" style="width: 45px;height: 45px;border-radius: 50%"/>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="title" label="名称" width="150"></el-table-column>
                    <el-table-column align="center" prop="kind_text" label="类型" width="75">
                        <template slot-scope="scope">
                            <span v-html="scope.row.kind_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="sort" label="排序" width="80"></el-table-column>
                    <el-table-column label="操作" >
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain> 编辑</el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash" type="info" size="mini" plain> 删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false" style="min-height: calc(100vh - 326px) !important;"
                       :title="dialog.title"
                       :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form"  label-width="120px">
                    <el-form-item label="类别：" prop="kind">
                        <el-radio-group v-model="form.kind" size="medium">
                            <el-radio-button label="1">视频</el-radio-button>
                            <el-radio-button label="2">专题</el-radio-button>
                            <el-radio-button label="3">楼凤</el-radio-button>
                            <el-radio-button label="4">小说</el-radio-button>
                            <el-radio-button label="5">图片</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请填写类目/专题名称', trigger: 'blur'}]" label="名称："
                                  prop="title">
                        <el-input v-model="form.title" placeholder="请填写类目/专题名称"></el-input>
                    </el-form-item>
                    <el-form-item label="备注：" prop="note">
                        <el-input v-model="form.note" placeholder="备注"></el-input>
                    </el-form-item>
                    <el-form-item label="封面：" prop="icon">
                        <el-input v-model="form.icon" placeholder="封面图片地址"></el-input>
                    </el-form-item>
                    <el-form-item label="排序：" prop="sort">
                        <el-input v-model="form.sort" placeholder="排序，越小越靠前"></el-input>
                    </el-form-item>
                    <el-form-item v-if="form.icon">
                        <img :src="form.icon" alt="" style="height: 150px;width: auto">
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                               :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {CategoryList,CategoryUpdate,CategoryDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    title: '',
                    icon: "",
                    note: '',
                    kind: 2,
                    sort: 0,
                },
                dialog: {
                    title: '',
                    show: false,
                },
                agents: [],
            }
        },
        created(){
        },
        activated(){
            if(this.$route.query.agent_id){
                this.params.agent_id = this.$route.query.agent_id;
            }
            this.list();
            this.$store.dispatch('setActive', '/category');
        },
        methods: {
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        CategoryUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                CategoryList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form = {
                    id: 0,
                    title: '',
                    icon: "",
                    note: '',
                    kind: 2,
                    sort: 0,
                };
                this.dialog.title = '新增';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    title: item.title,
                    icon: item.icon,
                    note: item.note,
                    kind: item.kind,
                    sort: item.sort,
                };
                this.dialog.title = '编辑';
                this.dialog.show = true;
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该渠道信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    CategoryDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
