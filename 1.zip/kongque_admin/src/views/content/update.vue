<template>
    <div class="panel-content">
        <div class="panel-body panel-info">
            <div class="panel-header">
                <div class="panel-title">
                    视频编辑
                </div>
            </div>
            <div class="panel-main">
                <div id="vs" class="dplayer"></div>
                <el-form :model="form" ref="form" class="form" label-width="100px">
                    <el-form-item  label="视频源站：" :rules="[{ required: true, message: '请选择视频源站', trigger: 'blur'}]" prop="source">
                        <el-radio-group v-model="form.source" size="medium">
                            <el-radio-button v-for="(platform,pi) in platforms" :key="pi"  :label="platform.name">{{ platform.title }}</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请填写标题', trigger: 'blur'}]" label="视频标题："
                                  prop="title">
                        <el-input  v-model="form.title" placeholder="请填写视频标题"></el-input>
                    </el-form-item>
                    <el-form-item label="视频资源：" :rules="[{ required: true, message: '请填写视频资源地址', trigger: 'blur'}]" prop="target">
                        <el-input  v-model="form.target" placeholder="请填写视频资源地址"></el-input>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请上传封面图', trigger: 'blur'}]" label="视频封面：" prop="thumb">
                        <el-input  v-model="form.thumb" placeholder="请上传封面图"></el-input>
                    </el-form-item>
                    <el-form-item label="视频专题：" prop="topic_id" >
                        <el-radio-group v-model="form.topic_id" size="medium">
                            <el-radio-button  v-for="item in topics" :key="item.id" :label="item.id">{{ item.title }}</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="视频类目：" prop="category_id"
                                  :rules="[{ required: true, message: '请选择视频类目', trigger: 'blur'}]">
                        <el-radio-group v-model="form.category_id" size="medium">
                            <el-radio-button   v-for="item in categorys" :key="item.id" :label="item.id">{{ item.title }}</el-radio-button>
                        </el-radio-group>
                    </el-form-item>

                    <div style="display: flex">
                        <div style="width: 50%">
                            <el-form-item label="封面属性：" prop="thumb_type">
                                <el-radio-group v-model="form.thumb_type" size="medium">
                                    <el-radio-button label="1">横图</el-radio-button>
                                    <el-radio-button label="2">竖图</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="视频状态：" prop="status">
                                <el-radio-group v-model="form.status" size="medium">
                                    <el-radio-button label="1">正常</el-radio-button>
                                    <el-radio-button label="2">推荐</el-radio-button>
                                    <el-radio-button label="3">锁定</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item label="视频限免：" prop="free">
                                <el-radio-group v-model="form.free" size="medium">
                                    <el-radio-button label="1">正常</el-radio-button>
                                    <el-radio-button label="2">限免</el-radio-button>
                                </el-radio-group>
                            </el-form-item>
                        </div>
                        <div style="width: 50%">
                            <img v-if="form.thumb" :src="form.thumb" style="width: auto;height: 150px" alt="">
                        </div>
                    </div>
                    <el-form-item label="视频浏量：" prop="view">
                        <el-input  placeholder="视频浏量" v-model="form.view"></el-input>
                    </el-form-item>
                    <el-form-item label="视频标签：" prop="tag">
                        <el-input  placeholder="视频标签" v-model="form.tag"></el-input>
                        <div>
                            <el-tag style="margin: 0 10px 10px 0;cursor: pointer" @click="selectTag(tag.name)"
                                    :key="ti"
                                    v-for="(tag,ti) in tags" :class="stags.includes(tag.name) ? 'tag-active' : ''">
                                {{tag.name}}
                            </el-tag>
                        </div>
                    </el-form-item>
                    <el-form-item label="清晰度：" prop="quality">
                        <el-radio-group v-model="form.quality" size="medium">
                            <el-radio-button label="高清">高清</el-radio-button>
                            <el-radio-button label="超清">超清</el-radio-button>
                            <el-radio-button label="蓝光">蓝光</el-radio-button>
                            <el-radio-button label="HD">HD</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item style="padding-left: 150px;margin-top: 50px">
                        <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                   :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                        <el-button @click="back()" style="margin-left: 50px">返 回</el-button>
                    </el-form-item>
                </el-form>
            </div>
        </div>
    </div>
</template>

<script>
    import {VideoCategory,VideoUpdate,VideoInfo,ConfigPlatform,TagList} from '@/utils/request';
    import HlsJsPlayer from 'xgplayer-hls.js';
    export default {
        data: function() {
            return {
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                topics: [],
                tags: [],
                platforms: [],
                form: {
                    id: 0,
                    source: this.$cookie.get('video_select'),
                    title: '',
                    thumb: '',
                    thumb_type: 1,
                    category_id: 1,
                    topic_id: '',
                    status: 1,
                    free: 1,
                    target: '',
                    view: 0,
                    tag: '',
                    quality: '高清',
                    date: '',
                },
                stags: [],
                categorys: [],
                options: {
                    id: 'vs',
                    autoplay: false,
                    fluid: true,
                    width: 450,
                    height: 90,
                    closeVideoClick: true,
                    closeVideoTouch: true,
                    url: '',
                    poster: '',
                    useHls: true,
                    'webkit-playsinline': true,
                    'playsinline': true,
                    'x5-playsinline': true,
                    'x-webkit-airplay': "allow"
                },
                player: null
            }
        },
        beforeRouteLeave(to, from, next) {
            this.$destroy();
            next();
        },
        created(){
            this.getCate();
            this.platform();
            this.tag();
        },
        activated(){
            this.$store.dispatch('setActive', '/video');
            if(this.$route.query.id){
                this.videoInfo(this.$route.query.id,this.$route.query.source)
            }else{
                this.form = {
                    id: 0,
                    source: this.$cookie.get('video_select'),
                    title: '',
                    thumb: '',
                    thumb_type: 1,
                    category_id: 1,
                    topic_id: '',
                    status: 1,
                    free: 1,
                    target: '',
                    view: 0,
                    tag: '',
                    quality: '高清',
                    date: '',
                };
                this.player = null;
            }
        },
        methods:{
            selectTag(name){
                let that = this;
                if(this.stags.includes(name)){
                    this.stags.forEach((tag,index) => {
                        if(tag == name){
                            that.stags.splice(index,1);
                            that.form.tag = that.stags.join('、');
                        }
                    })
                }else{
                    this.stags.push(name);
                    this.form.tag = this.stags.join('、');
                }
            },
            tag(){
                this.tags = [];
                TagList().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.tags = detail;
                });
            },
            platform(){
                ConfigPlatform().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.platforms = detail;
                });
            },
            getCate(){
                VideoCategory().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.categorys = detail.cates;
                    this.topics = detail.topic;
                });
            },
            videoInfo(id,source){
                VideoInfo({params:this.$crypto.encrypt({id:id,source:source})}).then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.form = detail;
                    this.options.url = detail.target;
                    this.options.poster = detail.thumb;
                    if(detail.tag){
                        this.stags = detail.tag.split('、');
                    }
                    this.form.source = this.$route.query.source;
                    if(this.player){
                        this.player.src  = detail.target;
                        this.player.poster = detail.thumb;
                    }else{
                        this.player = new HlsJsPlayer(this.options);
                    }
                });
            },
            //返回
            back() {
                window.history.go(-1);
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        VideoUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        window.history.go(-1);
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
        },
    }
</script>

<style scoped>
    .dplayer{
        position: fixed;top:82px;right: 15px;width: 450px !important;z-index: 1000;
    }
    .tag-active{
        color: #fff;background-color: #409EFF;
        border-color: #409EFF;
    }
</style>
