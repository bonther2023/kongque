<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    图片管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column align="center" label="类目" width="80">
                        <template slot-scope="scope">
                            <span v-for="(cate) in categorys" v-if="cate.id == scope.row.cate_id"> {{ cate.title }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="title" label="标题" width="350" :show-overflow-tooltip="true"></el-table-column>
                    <el-table-column align="center" prop="created_at" label="创建时间" width="165"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>
                                修改
                            </el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">
                    <el-form-item label="类目：" prop="cate_id" >
                        <el-radio-group v-model="form.cate_id" size="medium">
                            <el-radio-button  v-for="item in categorys" :key="item.id" :label="item.id">{{ item.title }}</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item :rules="[{ required: true, message: '请填写标题', trigger: 'blur'}]" label="标题："
                                  prop="title">
                        <el-input clearable v-model="form.title" placeholder="标题"></el-input>
                    </el-form-item>
                    <el-form-item label="图片：">
                        <el-button type="primary" icon="fa fa-plus" @click="add()" size="mini"> 添加</el-button>
                    </el-form-item>
                    <el-form-item v-if="form.content.length > 0" v-for="(photo,gi) in form.content" :key="gi">
                        <el-input style="width: 650px;margin-right: 10px" v-model="photo.img" placeholder="图片地址"></el-input>
                        <el-button icon="fa fa-trash" v-if="gi > 0" style="margin-left: 15px" type="info" size="mini" @click="del(gi)"> 删除</el-button>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {PhotoCategory,PhotoList,PhotoUpdate,PhotoDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    content: [{img:''}],
                    cate_id: 26,
                    title: '',
                },
                categorys: [],
                dialog: {
                    title: '',
                    show: false,
                },
            }
        },
        created(){
            this.getCate();
        },
        activated(){
            this.$store.dispatch('setActive', '/photo');
            this.list();
        },
        methods: {
            getCate(){
                PhotoCategory().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.categorys = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        PhotoUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                PhotoList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form =  {
                    id: 0,
                    content: [{img:''}],
                    cate_id: 26,
                    title: '',
                };
                this.dialog.title = '新增图片';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    content: item.content,
                    cate_id: item.cate_id,
                    title: item.title,
                };
                this.dialog.title = '编辑图片';
                this.dialog.show = true;
            },
            del(i){
                this.form.content.splice(i,1);
            },
            add() {
                this.form.content.push({img:''});
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该图片信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    PhotoDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
