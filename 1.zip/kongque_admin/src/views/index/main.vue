<template>
    <div class="panel-content">
        <div class="panel-body panel-home"  style="line-height: 600px;text-align: center;font-size: 30px">
            欢迎来到后台...
        </div>
    </div>
</template>

<script>
    import {Configs} from '@/utils/request';
    export default {
        data() {
            return {

            }
        },
        created(){
            Configs().then((res) => {
                let detail = this.$crypto.decrypt(res.data);
                this.$cookie.set('video_select', detail.configs.video_resource, { expires: '30d' });
            });
        },
        activated(){
            this.$store.dispatch('setActive', '/main');
        },
        methods: {

        }
    }
</script>

<style scoped>

</style>
