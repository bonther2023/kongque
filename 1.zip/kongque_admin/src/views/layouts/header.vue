<template>
    <header  class="header">
        <div class="header-logo" style="box-shadow: 0 1px 1px rgba(0,0,0,.1)">
            <span><img src="../../assets/img/logo.png" alt=""></span>
        </div>
        <div class="header-user">
            <ul style="float: left;padding-inline-start: 5px;">
                <li style="color: red;cursor: pointer" title="5分钟在线人数" alt="5分钟在线人数"><i class="fa fa-user-plus"></i>：{{ online_user }} 人</li>
            </ul>
            <ul style="float: right">
                <li>{{ username }}</li>
                <li><span style="cursor: pointer" @click="logout"><i class="fa fa-power-off"></i> 退出</span></li>
            </ul>
        </div>
    </header>
</template>
<script>
    import {Socket,UserOnline,CustomLogout} from '@/utils/request';
    export default {
        data: function() {
            return {
                username: '',
                online_user: 0,
            }
        },
        created(){
            this.username = this.$cookie.get('username');
            Socket().then((res) => {
                if(res.code == 0){
                    let detail = this.$crypto.decrypt(res.data);
                    this.$cookie.set('custom_ws', detail, { expires: '30d' });
                }
            });
            this.online();
            setInterval(() => {
                this.online();
            }, 20000);
        },
        methods:{
            online(){
                UserOnline().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.online_user = detail;
                    }
                });
            },
            logout() {
                this.$notify({
                    title: '成功',
                    message: '稍等，即将退出......',
                    type: 'success',
                    duration: '1000',
                    onClose:() =>{
                        CustomLogout().then((res) => {
                            if(res.code == 0){
                                this.$store.dispatch('userLogout').then(()=>{
                                    this.$router.push({name:'login'});
                                });
                            }
                        });
                    }
                });
            }
        }
    }
</script>
