<template>
    <div class="footer">
        Copyright © Powered By Admin System 2022
    </div>
</template>
