<template>
    <div class="main">
        <v-head></v-head>
        <v-menu></v-menu>
        <div class="content">
            <transition name="slide-fade" mode="out-in">
                <keep-alive>
                    <router-view/>
                </keep-alive>
            </transition>
        </div>
        <v-foot></v-foot>
    </div>
</template>
<script>
    // @ is an alias to /src
    import vHead from '@/views/layouts/header.vue';
    import vMenu from '@/views/layouts/menu.vue';
    import vFoot from '@/views/layouts/footer.vue';

    export default {
        components: {vHead, vMenu, vFoot},
    }
</script>
