<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    订单管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】【金额：<em>{{ total ? total : 0 }} </em>元】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="未支付" name="1"></el-tab-pane>
                    <el-tab-pane label="已支付" name="2"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item" style="width: 200px">
                            <el-input  size="medium" @input="search()" v-model="params.kwd" clearable placeholder="用户ID或者订单号" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-input  size="medium" @input="search()" v-model="params.name" clearable placeholder="用户名称" class="input-with-select"/>
                        </div>
                        <div class="panel-search-item" style="width: 110px">
                            <el-select filterable size="medium" @change="search()" v-model="params.cid" placeholder="请选择">
                                <el-option label="渠道(全部)"  value=""></el-option>
                                <el-option
                                    v-for="canal in canals"
                                    :key="canal.id"
                                    :label="canal.username"
                                    :value="canal.id">
                                </el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 195px">
                            <el-date-picker style="width: 195px"
                                            size="medium"
                                            :clearable="false"
                                            v-model="date"
                                            type="daterange"
                                            @change="pickerChange"
                                            :picker-options="pickerOptions2"
                                            range-separator="-"
                                            start-placeholder="开始日期"
                                            end-placeholder="结束日期"
                                            align="right">
                            </el-date-picker>
                        </div>
                        <div class="panel-search-item" style="width: 110px">
                            <el-select size="medium" @change="search()" v-model="params.payment" placeholder="请选择">
                                <el-option label="方式(全部)"  value=""></el-option>
                                <el-option label="微信"  value="1"></el-option>
                                <el-option label="支付宝"  value="2"></el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 110px">
                            <el-select size="medium" @change="search()" v-model="params.platform" placeholder="请选择">
                                <el-option label="支付(全部)"  value=""></el-option>
                                <el-option
                                    v-for="pay in pays"
                                    :key="pay.name"
                                    :label="pay.title"
                                    :value="pay.name">
                                </el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 110px">
                            <el-select  size="medium" @change="search()" v-model="params.system">
                                <el-option label="系统(全部)" value=""></el-option>
                                <el-option label="Android" value="Android"></el-option>
                                <el-option label="IOS" value="iOS"></el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="created_at" label="日期" width="160"></el-table-column>
                    <el-table-column align="center" prop="order_id" label="订单号" width="188"></el-table-column>
                    <el-table-column align="center" prop="money" label="价格" width="50"></el-table-column>
                    <el-table-column align="center" prop="payment" label="方式" width="50">
                        <template slot-scope="scope">
                            <img style="margin-top: 6px" v-if="scope.row.payment == 1" src="../../assets/img/w.png" alt="">
                            <img style="margin-top: 6px" v-if="scope.row.payment == 2" src="../../assets/img/a.png" alt="">
                            <img style="margin-top: 6px" v-if="scope.row.payment == 3" src="../../assets/img/code.png" alt="">
                        </template>
                    </el-table-column>
                    <el-table-column prop="username" label="用户" width="200">
                        <template slot-scope="scope">
                            <el-tag v-if="scope.row.is_new == 1" effect="dark"  size="mini">新</el-tag>
                            <el-tag v-if="scope.row.is_new == 2" effect="dark" type="danger" size="mini">老</el-tag>
                            <span style="cursor: pointer" class="user-name" @click="goToUser(scope.row.user_id)"> {{ scope.row.username }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="system" label="系统"  width="50">
                        <template slot-scope="scope">
                            <img style="margin-top: 6px" v-if="scope.row.system == 'Android'" src="../../assets/img/android.png" alt="">
                            <img style="margin-top: 6px" v-if="scope.row.system == 'iOS'" src="../../assets/img/ios.png" alt="">
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="platform" label="支付渠道" width="100">
                        <template slot-scope="scope">
                            <span v-for="(pay,ci) in pays" :key="ci" v-if="pay.name == scope.row.platform"> {{ pay.title }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="deduct_text" label="扣量" width="68">
                        <template slot-scope="scope">
                            <span v-if="scope.row.status == 2" v-html="scope.row.deduct_text"></span>
                        </template>
                    </el-table-column>

                    <el-table-column align="center" prop="status_text" label="状态" width="68">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="pay_at" label="支付日期"  width="165"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button v-if="scope.row.status == 1"  @click="update(scope.row.id)" icon="fa fa-file-text" type="primary" size="mini" plain>
                                补单
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {OrderList,OrderUpdate,PaySelect,CanalSelect} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, oid: '', cid: '', start: '', end: '', status: 0,payment: '',platform: '',system: '', kwd: '',name:''},
                loading: false,
                date: '',
                total: '',
                pays: [],
                canals: [],
                pickerOptions2: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() - 3600 * 1000 * 24 * 1);
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                }
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/order');
            let nowDate = new Date();
            this.params.start = this.$moment(nowDate).format('YYYY-MM-DD');
            this.params.end = this.$moment(nowDate).format('YYYY-MM-DD');
            this.date = [
                this.params.start, this.params.end
            ];
            if(this.$route.query.kwd){
                this.params.kwd = this.$route.query.kwd;
                let start = nowDate;
                start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                console.log();
                this.params.start = this.$moment(start).format('YYYY-MM-DD');
                this.date = [
                    this.params.start, this.params.end
                ];
            }
            this.list();
            this.getPay();
            this.getCanal();
        },
        methods: {
            goToUser(uid){
                let target = window.location.protocol + "//" + window.location.host + "/user?id=" + uid;
                window.open(target, '_blank');
            },
            getCanal(){
                CanalSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.canals = detail;
                });
            },
            //时间筛选
            pickerChange() {
                if (this.date) {
                    this.params.start = this.$moment(this.date[0]).format('YYYY-MM-DD');
                    this.params.end = this.$moment(this.date[1]).format('YYYY-MM-DD');
                } else {
                    this.params.start = '';
                    this.params.end = '';
                }
                this.params.page = 1;
                this.list();
            },
            getPay(){
                PaySelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.pays = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //列表
            list(){
                this.loading = true;
                OrderList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail.lists;
                        this.total = detail.total;
                        this.loading = false;
                    }
                });
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            update(id){
                this.$confirm('确定补发该订单信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    OrderUpdate({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>
    .user-name:hover{
        color: #0000cc;
    }
</style>
