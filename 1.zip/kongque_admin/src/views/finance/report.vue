<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    报表统计
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-random" @click="compare()" size="small"> 对比</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item" style="width: 150px">
                            <el-date-picker style="width: 150px"
                                v-model="date"
                                size="medium"
                                :clearable="false"
                                type="date"
                                @change="pickerChange"
                                placeholder="选择日期">
                            </el-date-picker>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select filterable size="medium" @change="search()" v-model="params.cid" placeholder="请选择">
                                <el-option label="渠道(全部)"  value=""></el-option>
                                <el-option
                                    v-for="canal in canals"
                                    :key="canal.id"
                                    :label="canal.username"
                                    :value="canal.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <div id="echart" style="width: 100%;height:250px;"></div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData" border>
                    <el-table-column prop="date" label="日期" width="100"></el-table-column>
                    <el-table-column prop="hour" label="小时" width="120"></el-table-column>
                    <el-table-column prop="installs" label="安装量" width="120"></el-table-column>
                    <el-table-column prop="orders" label="订单量" width="120"></el-table-column>
                    <el-table-column prop="pays" label="支付量"></el-table-column>
                </el-table>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                       :title="dialog.title"
                       :visible.sync="dialog.show" center>
                <div class="panel-search-item" style="width: 120px;float: right;position: absolute;top:11px;right:65px;z-index: 55">
                    <el-select filterable size="medium" @change="scompare()" v-model="cparams.cid" placeholder="请选择">
                        <el-option label="渠道(全部)"  value=""></el-option>
                        <el-option
                            v-for="canal in canals"
                            :key="canal.id"
                            :label="canal.username"
                            :value="canal.id">
                        </el-option>
                    </el-select>
                </div>
                <el-table style="margin-top: -5px" v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="compareData" border>
                    <el-table-column align="center"  prop="hour" label="小时" width="60"></el-table-column>
                    <el-table-column align="center"  v-for="date in dates" :prop="date" :label="date"></el-table-column>
                </el-table>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {ReportList,ReportCompare,CanalSelect} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: { cid: '', date: ''},
                cparams: {cid: '', },
                loading: false,
                date: '',
                dates: [],
                statis: [],
                canals: [],
                dialog: {
                    title: '数据对比',
                    show: false,
                },
                compareData: []
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/report');
            let nowDate = new Date();
            this.date = this.$moment(nowDate).format('YYYY-MM-DD');
            this.params.date = this.date;
            this.list();
            this.getCanal();
        },
        methods: {
            compare(){
                this.cparams.cid = '';
                this.scompare();
            },
            scompare(){
                ReportCompare({params:this.$crypto.encrypt(this.cparams)}).then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.compareData = detail.lists;
                    this.dates = detail.dates;
                    this.dialog.show = true;
                });
            },
            echart(){
                let myChart = this.$echarts.init(document.getElementById('echart'));
                let colors = ['#59bef1', '#ec6459', '#675bba'];
                let option = {
                    color: colors,
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data:['安装量','订单量','支付量']
                    },
                    xAxis: {
                        type: 'category',
                        name: '时间',
                        boundaryGap: false,
                        data: ["0:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"]
                    },
                    yAxis: {
                        type: 'value',
                        name: '流量统计',
                        nameLocation: 'middle',
                        nameGap: '50'
                    },
                    series: [{
                        name: '安装量',
                        type: 'line',
                        data: this.statis.install
                    },{
                        name: '订单量',
                        type: 'line',
                        data: this.statis.order
                    },{
                        name: '支付量',
                        type: 'line',
                        data: this.statis.pay
                    }]
                };
                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            },
            getCanal(){
                CanalSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.canals = detail;
                });
            },
            //时间筛选
            pickerChange() {
                if (this.date) {
                    this.params.date = this.$moment(this.date).format('YYYY-MM-DD');
                } else {
                    this.params.date = '';
                }
                this.list();
            },
            //筛选
            search(){
                this.list();
            },
            //列表
            list(){
                this.loading = true;
                ReportList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail.lists;
                        this.statis = detail.statis;
                        this.loading = false;
                        this.echart();
                    }
                });
            },
        }
    }
</script>

<style scoped>

</style>
