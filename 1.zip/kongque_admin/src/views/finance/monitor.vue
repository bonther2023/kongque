<template>
    <div class="panel-content">
        <div class="panel-body panel-home"  style="text-align: center;">
            <table style="background: #fff;border-spacing: 0;border: 1px solid #f3f3f3;position: absolute;top:15px;left: 15px;width: 450px;z-index: 1000;">
                <caption style="font-weight:700;text-align: center;background: #00bcd4;height: 55px;line-height:55px;color: #fff">
                    安卓最近5分钟安装量(小于50个报警)
                </caption>
                <tr :class="andNum < 50 && andhong ? 'hong': ''">
                    <td width="100"></td>
                    <td width="100" style="text-align: center;height: 35px">{{ andNum }} 个</td>
                    <td width="100"></td>
                </tr>
            </table>
            <table style="background: #fff;border-spacing: 0;border: 1px solid #f3f3f3;position: absolute;top:15px;right: 15px;width: 450px;z-index: 1000;">
                <caption style="font-weight:700;text-align: center;background: #00bcd4;height: 55px;line-height:55px;color: #fff">
                    IOS最近5分钟安装量(小于3个报警)
                </caption>
                <tr :class="iosNum < 3 && ioshong ? 'hong': ''">
                    <td width="100"></td>
                    <td width="100" style="text-align: center;height: 35px">{{ iosNum }} 个</td>
                    <td width="100"></td>
                </tr>
            </table>
            <table style="background: #fff;border-spacing: 0;border: 1px solid #f3f3f3;position: absolute;top:155px;left: 15px;width: 450px;z-index: 1000;">
                <caption style="font-weight:700;text-align: center;background: #00bcd4;height: 55px;line-height:55px;color: #fff">最近{{ nums }}笔订单成功率</caption>
                <tr style="background: rgb(239, 246, 255);height: 55px;">
                    <td width="100">支付名称</td>
                    <td width="100">已支付量</td>
                    <td width="100">成功率</td>
                </tr>
                <tr v-for="payInfo in paySuccess" :class="payInfo.hong ? 'hong': ''" style="height: 35px">
                    <td style="text-align: left;padding-left: 35px">{{ payInfo.platform }}</td>
                    <td>{{ payInfo.yespay }}</td>
                    <td>{{ payInfo.success }}</td>
                </tr>
            </table>
        </div>
    </div>
</template>

<script>
    import {UserMonitor} from '@/utils/request';
    export default {
        data() {
            return {
                paySuccess: null,
                iosNum: 0,
                ioshong: 0,
                andNum: 0,
                andhong: 0,
                nums: 0,
                waudio: null,
                wautoplay: false,
            }
        },
        created(){
            this.monitor();
            setInterval(() => {
                this.monitor();
            }, 20000);
        },
        activated(){
            this.$store.dispatch('setActive', '/monitor');
        },
        mounted() {
            document.addEventListener('click', ()=>{
                this.wautoplay = true;
            });
        },
        methods: {
            monitor(){
                let that = this;
                UserMonitor().then((res) => {
                    if(res.code == 0){
                        let detail = that.$crypto.decrypt(res.data);
                        that.paySuccess = detail.success;
                        that.nums = detail.warning_order;
                        that.iosNum = detail.ios;
                        that.andNum = detail.android;
                        that.paySuccess.filter((item,index)=>{
                            if(item.hong){
                                that.aplayAudio();
                            }
                        });
                        if(that.iosNum < 3 && detail.warning_ios == 1){
                            that.ioshong = 1;
                            that.aplayAudio();
                        }else{
                            that.ioshong = 0;
                        }
                        if(that.andNum < 50 && detail.warning_android == 1){
                            that.andhong = 1;
                            that.aplayAudio();
                        }else{
                            that.andhong = 0;
                        }
                    }
                });
            },
            // 语音播放
            aplayAudio () {
                if(this.wautoplay){
                    if(this.waudio != null){
                        this.waudio = null;
                    }
                    this.waudio = new Audio();
                    this.waudio.src = require('../../assets/img/warming.mp3');
                    this.waudio.play();
                }
            },
        }

    }
</script>

<style scoped>
    .hong{
        background: red;color: #fff;
    }
</style>
