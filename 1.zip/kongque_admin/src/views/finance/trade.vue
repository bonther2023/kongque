<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    结算管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()" size="medium" v-model="params.username" clearable placeholder="请输入用户名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item" style="width: 210px">
                            <el-date-picker style="width: 210px"
                                            size="medium"
                                            :clearable="false"
                                            v-model="date"
                                            type="daterange"
                                            @change="pickerChange"
                                            :picker-options="pickerOptions2"
                                            range-separator="-"
                                            start-placeholder="开始日期"
                                            end-placeholder="结束日期"
                                            align="right">
                            </el-date-picker>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center"  prop="date" label="日期" width="100"></el-table-column>
                    <el-table-column align="center"  prop="username" label="用户名称" width="100"></el-table-column>
                    <el-table-column align="center"  prop="money" label="结算金额" width="100"></el-table-column>
                    <el-table-column align="center"  prop="name" label="联系人" width="100"></el-table-column>
                    <el-table-column prop="bank" label="银行名称" width="150" :show-overflow-tooltip="true"></el-table-column>
                    <el-table-column prop="card" label="银行卡号" width="250" :show-overflow-tooltip="true"></el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="80">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
<!--                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>-->
<!--                                修改-->
<!--                            </el-button>-->
                            <el-button v-if="scope.row.status == 1" @click="send(scope.row.id)" icon="fa fa-send" type="primary" size="mini" plain>
                                结算
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {TradeList,TradeUpdate,TradeStatus} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, username: '', start: '', end: ''},
                loading: false,
                date: '',
                pickerOptions2: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() - 3600 * 1000 * 24 * 1);
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                }
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/trade');
            // let nowDate = new Date();
            // this.params.start = this.$moment(nowDate).format('YYYY-MM-DD');
            // this.params.end = this.$moment(nowDate).format('YYYY-MM-DD');
            // this.date = [
            //     this.params.start, this.params.end
            // ];
            this.list();
        },
        methods: {
            //时间筛选
            pickerChange() {
                if (this.date) {
                    this.params.start = this.$moment(this.date[0]).format('YYYY-MM-DD');
                    this.params.end = this.$moment(this.date[1]).format('YYYY-MM-DD');
                } else {
                    this.params.start = '';
                    this.params.end = '';
                }
                this.params.page = 1;
                this.list();
            },
            //列表
            list(){
                this.loading = true;
                TradeList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            send(id){
                this.$confirm('确定已经结算该流水信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    TradeStatus({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
