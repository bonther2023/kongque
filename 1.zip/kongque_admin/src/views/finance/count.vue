<template>
    <div class="panel-content">
        <div class="panel-body panel-home">
            <div class="panel-header">
                <div class="panel-title">
                    数据统计
                </div>
            </div>
            <div class="panel-header">
                <div class="panel-title">
                    今昨对比
                </div>
            </div>
            <div class="panel-main home-realtime">
                <div class="realtime-item order-realtime">
                    <div class="card-icon"><div><i class="fa fa-cart-plus"></i></div></div>
                    <div class="card-body">
                        <div class="card-header">订单</div>
                        <div class="card-number">{{ nowOrderNum }}</div>
                        <div class="card-description">昨日：{{ yesOrderNum }}</div>
                    </div>
                </div>
                <div class="realtime-item new-realtime">
                    <div class="card-icon"><div><i class="fa fa-user"></i></div></div>
                    <div class="card-body">
                        <div class="card-header">新增</div>
                        <div class="card-number">{{ nowSInstall }}</div>
                        <div class="card-description">昨日：{{ yesSInstall }}</div>
                    </div>
                </div>
                <div class="realtime-item good-realtime">
                    <div class="card-icon"><div><i class="fa fa-user-o"></i></div></div>
                    <div class="card-body">
                        <div class="card-header">活跃</div>
                        <div class="card-number">{{ nowActiveUser }}</div>
                        <div class="card-description">昨日：{{ yesActiveUser }}</div>
                    </div>
                </div>
                <div class="realtime-item user-realtime">
                    <div class="card-icon"><div><i class="fa fa-cny"></i></div></div>
                    <div class="card-body">
                        <div class="card-header">收益(元)</div>
                        <div class="card-number">0</div>
                        <div class="card-description">昨日：0</div>
                    </div>
                </div>
            </div>
            <div class="panel-header">
                <div class="panel-title">
                    实时概况
                </div>
            </div>
            <div>
                <table style="border-spacing: 0px;margin-top: 15px;border: 1px solid #f3f3f3">
                    <tr style="text-align: center;background: rgb(239, 246, 255);height: 40px;">
                        <td width="100">用户</td>
                        <td  width="100">总金额</td>
                        <td  width="100">订单量</td>
                        <td  width="100">支付量</td>
                        <td  width="100">成功率</td>
                    </tr>
                    <tr style="text-align: center;height: 50px">
                        <td>新用户</td>
                        <td>{{ newUserOrderMoney }}</td>
                        <td>{{ newUserOrderNum }}</td>
                        <td>{{ newUserOrderPayNum }}</td>
                        <td>{{ newUserOrderNum ? (newUserOrderPayNum/newUserOrderNum).toFixed(2) : '0.00' }}%</td>
                    </tr>
                    <tr style="text-align: center;height: 50px">
                        <td>老用户</td>
                        <td>{{ oldUserOrderMoney }}</td>
                        <td>{{ oldUserOrderNum }}</td>
                        <td>{{ oldUserOrderPayNum }}</td>
                        <td>{{ oldUserOrderNum ? (oldUserOrderPayNum/oldUserOrderNum).toFixed(2) : '0.00' }}%</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    import {Count} from '@/utils/request';
    export default {
        data() {
            return {
                videoTotal: 0,
                userTotal: 0,
                userActiveTotal: 0,
                rechageTotal: 0,
                nowProfit: 0,
                yesProfit: 0,
                nowOrderNum: 0,
                yesOrderNum: 0,
                yesSInstall: 0,
                yesDInstall: 0,
                nowSInstall: 0,
                nowDInstall: 0,
                nowActiveUser: 0,
                yesActiveUser: 0,
                newUserOrderPayNum: 0,
                oldUserOrderPayNum: 0,
                newUserOrderMoney: 0,
                oldUserOrderMoney: 0,
                newUserOrderNum: 0,
                oldUserOrderNum: 0
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/count');
            Count().then((res) => {
                let detail = this.$crypto.decrypt(res.data);
                this.videoTotal = detail.videoTotal,
                this.userTotal = detail.userTotal,
                this.userActiveTotal = detail.userActiveTotal,
                this.rechageTotal = detail.rechageTotal,
                this.nowProfit = detail.nowProfit,
                this.yesProfit = detail.yesProfit,
                this.nowOrderNum = detail.nowOrderNum,
                this.yesOrderNum = detail.yesOrderNum,
                this.yesSInstall = detail.yesSInstall,
                this.yesDInstall = detail.yesDInstall,
                this.nowSInstall = detail.nowSInstall,
                this.nowDInstall = detail.nowDInstall,
                this.nowActiveUser = detail.nowActiveUser,
                this.yesActiveUser = detail.yesActiveUser,
                this.newUserOrderPayNum = detail.newUserOrderPayNum,
                this.oldUserOrderPayNum = detail.oldUserOrderPayNum,
                this.newUserOrderMoney = detail.newUserOrderMoney,
                this.oldUserOrderMoney = detail.oldUserOrderMoney,
                this.newUserOrderNum = detail.newUserOrderNum,
                this.oldUserOrderNum = detail.oldUserOrderNum
            });
        },
        methods: {

        }
    }
</script>

<style scoped>

</style>
