<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    流量趋势 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item" style="width: 200px">
                            <el-date-picker style="width: 200px"
                                            size="medium"
                                            v-model="date"
                                            :clearable="false"
                                            type="daterange"
                                            @change="pickerChange"
                                            :picker-options="pickerOptions2"
                                            range-separator="-"
                                            start-placeholder="开始日期"
                                            end-placeholder="结束日期"
                                            align="right">
                            </el-date-picker>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select filterable size="medium" @change="search()" v-model="params.cid" placeholder="请选择">
                                <el-option label="渠道(全部)"  value=""></el-option>
                                <el-option
                                    v-for="canal in canals"
                                    :key="canal.id"
                                    :label="canal.username"
                                    :value="canal.id">
                                </el-option>
                            </el-select>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select filterable size="medium" @change="search()" v-model="params.aid" placeholder="请选择">
                                <el-option label="代理(全部)"  value=""></el-option>
                                <el-option
                                    v-for="agent in agents"
                                    :key="agent.id"
                                    :label="agent.username"
                                    :value="agent.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>

                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          :summary-method="getSummaries"
                          show-summary
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center"  prop="date" label="日期" width="100"></el-table-column>
                    <el-table-column align="center" prop="agent_username" label="代理名称" width="80"></el-table-column>
                    <el-table-column align="center" prop="canal_username" label="渠道名称" width="130">
                        <template slot-scope="scope">
                            【{{ scope.row.canal_id }}】{{ scope.row.canal_username }}
                        </template>
                    </el-table-column>
                    <el-table-column align="center"  prop="s_install" label="安装量" width="90"></el-table-column>
                    <el-table-column align="center"  prop="d_install" label="安装扣量" width="90"></el-table-column>
                    <el-table-column align="center"  prop="settlement" label="结算量" width="75"></el-table-column>
                    <el-table-column align="center"  prop="deduct" label="扣量" width="75"></el-table-column>
                    <el-table-column align="center"  prop="money" label="代理佣金" width="95"></el-table-column>
                    <el-table-column align="center"  prop="rebate" label="渠道佣金" width="100"></el-table-column>
                    <el-table-column align="center"  prop="payable" label="结算" width="100"></el-table-column>
                    <el-table-column align="center" prop="profit" label="利润" width="100"></el-table-column>
                    <el-table-column prop="rechage" label="总和"></el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {FlowList,AgentSelect,CanalSelect} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, aid: '', cid: '', start: '', end: ''},
                loading: false,
                date: '',
                totalData: [],
                agents: [],
                canals: [],
                pickerOptions2: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() - 3600 * 1000 * 24 * 1);
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                }
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/flow');
            let nowDate = new Date();
            this.params.start = this.$moment(nowDate).format('YYYY-MM-DD');
            this.params.end = this.$moment(nowDate).format('YYYY-MM-DD');
            this.date = [
                this.params.start, this.params.end
            ];
            this.list();
            this.getAgent();
            this.getCanal();
        },
        methods: {
            getSummaries(param) {
                const { columns, data } = param;
                const sums = [];
                columns.forEach((column, index) => {
                    switch (index) {
                        case 1:
                            sums[index] = '';
                            break;
                        case 2:
                            sums[index] = '';
                            break;
                        case 3:
                            sums[index] = this.totalData['s_installs'];
                            break;
                        case 4:
                            sums[index] = this.totalData['d_installs'];
                            break;
                        case 5:
                            sums[index] = this.totalData['settlements'];
                            break;
                        case 6:
                            sums[index] = this.totalData['deducts'];
                            break;
                        case 7:
                            sums[index] = this.totalData['moneys'];
                            break;
                        case 8:
                            sums[index] = this.totalData['rebates'];
                            break;
                        case 9:
                            sums[index] = this.totalData['payables'];
                            break;
                        case 10:
                            sums[index] = this.totalData['profits'];
                            break;
                        case 11:
                            sums[index] = this.totalData['rechages'];
                            break;
                        default:
                            sums[index] = '总计';
                            break;
                    }
                    return;
                });
                return sums;
            },
            getCanal(){
                CanalSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.canals = detail;
                });
            },
            //时间筛选
            pickerChange() {
                if (this.date) {
                    this.params.start = this.$moment(this.date[0]).format('YYYY-MM-DD');
                    this.params.end = this.$moment(this.date[1]).format('YYYY-MM-DD');
                } else {
                    this.params.start = '';
                    this.params.end = '';
                }
                this.params.page = 1;
                this.list();
            },
            getAgent(){
                AgentSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.agents = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //列表
            list(){
                this.loading = true;
                FlowList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail.lists;
                        this.totalData = detail.totals;
                        this.loading = false;
                    }
                });
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
        }
    }
</script>

<style scoped>

</style>
