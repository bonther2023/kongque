<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    用户管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.system" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name=""></el-tab-pane>
                    <el-tab-pane label="安 卓" name="Android"></el-tab-pane>
                    <el-tab-pane label="苹 果" name="iOS"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item" style="width: 300px">
                            <el-input @input="search()" size="medium" v-model="params.username" clearable placeholder="请输入用户名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item" style="width: 100px">
                            <el-input @input="search()" size="medium" v-model="params.id" clearable placeholder="编号" class="input-with-select"/>
                        </div>
                        <div class="panel-search-item" style="width: 200px">
                            <el-input @input="search()" size="medium" v-model="params.mobile" clearable placeholder="手机号码" class="input-with-select"/>
                        </div>
                        <div class="panel-search-item" style="width: 150px">
                            <el-select @change="search()" filterable size="medium" v-model="params.cid">
                                <el-option  label="渠道(全部)" value=""></el-option>
                                <el-option
                                    v-for="canal in canals"
                                    :key="canal.id"
                                    :label="canal.username"
                                    :value="canal.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column type="expand" width="40">
                        <template slot-scope="props">
                            <el-form label-position="right" inline class="demo-table-expand">
                                <el-form-item label="VIP到期：">
                                    <span>{{ props.row.vip_at }}</span>
                                </el-form-item>
                                <el-form-item label="绑定手机：">
                                    <span>{{ props.row.mobile }}</span>
                                </el-form-item>
                                <el-form-item label="最近登录：">
                                    <span>{{ props.row.login_at }}</span>
                                </el-form-item>
                                <el-form-item label="手机型号：">
                                    <span>{{ props.row.app_model }}</span>
                                </el-form-item>
                                <el-form-item label="系统版本：">
                                    <span>{{ props.row.app_release }}</span>
                                </el-form-item>
                                <el-form-item label="网络状态：">
                                    <span>{{ props.row.app_network }}</span>
                                </el-form-item>
                                <el-form-item label="ip地址库：">
                                    <span>{{ props.row.ip_address }}</span>
                                </el-form-item>
                                <el-form-item label="UUID：">
                                    <span>{{ props.row.uuid }}</span>
                                </el-form-item>
                            </el-form>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="canal_name" label="【代理】渠道"  width="160">
                        <template slot-scope="scope">
                            【{{ scope.row.agent_name }}】{{ scope.row.canal_name }}
                        </template>
                    </el-table-column>
                    <el-table-column prop="username" label="用户名" width="240">
                        <template slot-scope="scope">
                           【{{ scope.row.id }}】{{ scope.row.username }}
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="vip" label="VIP" width="60">
                        <template slot-scope="scope">
                            <span v-if="scope.row.vip == 'free_vip'">免费</span>
                            <span v-if="scope.row.vip == 'day_vip'">一日</span>
                            <span v-if="scope.row.vip == 'month_vip'">一月</span>
                            <span v-if="scope.row.vip == 'quarter_vip'">半年</span>
                            <span v-if="scope.row.vip == 'year_vip'">一年</span>
                            <span v-if="scope.row.vip == 'forever_vip'">永久</span>
                        </template>
                    </el-table-column>
                    <el-table-column prop="ip" label="注册IP" width="135" :show-overflow-tooltip="true"></el-table-column>
                    <el-table-column align="center" prop="app_system" label="系统" width="50">
                        <template slot-scope="scope">
                            <img style="margin-top: 6px" v-if="scope.row.app_system == 'Android'" src="../../assets/img/android.png" alt="">
                            <img style="margin-top: 6px" v-if="scope.row.app_system == 'iOS'" src="../../assets/img/ios.png" alt="">
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="app_vendor" label="品牌" :show-overflow-tooltip="true" width="100"></el-table-column>
                    <el-table-column align="center" prop="created_at" label="注册日期" width="165"></el-table-column>
                    <el-table-column align="center" prop="app_version" label="版本号" width="75"></el-table-column>
                    <el-table-column label="操作" >
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain> 编辑</el-button>
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash" type="info" size="mini" plain> 删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                style="min-height: calc(100vh - 326px) !important;"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" label-width="120px">
                    <el-form-item label="用户名：" prop="username">
                        <el-input readonly v-model="form.username"></el-input>
                    </el-form-item>
                    <el-form-item label="vip等级：" prop="vip">
                        <el-radio-group v-model="form.vip" size="medium">
                            <el-radio-button label="" border>无</el-radio-button>
                            <el-radio-button label="day_vip" border>日VIP</el-radio-button>
                            <el-radio-button label="month_vip" border>月VIP</el-radio-button>
                            <el-radio-button label="quarter_vip" border>半年VIP</el-radio-button>
                            <el-radio-button label="year_vip" border>年VIP</el-radio-button>
                            <el-radio-button label="forever_vip" border>永久VIP</el-radio-button>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="VIP到期时间：" prop="vip_at">
                        <el-date-picker
                            v-model="form.vip_at"
                            type="datetime"
                            placeholder="选择日期时间">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item label="注册IP：" prop="ip">
                        <el-input readonly v-model="form.ip"></el-input>
                    </el-form-item>
                    <el-form-item label="IP地址：" prop="ip_address">
                        <el-input readonly v-model="form.ip_address"></el-input>
                    </el-form-item>
                    <el-form-item label="注册时间：" prop="created_at">
                        <el-input readonly v-model="form.created_at"></el-input>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {UserList,UserUpdate,CanalSelect,UserDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, username: '',id: '',mobile: '', system: '', cid : '',date: ''},
                date: '',
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    username: '',
                    created_at: '',
                    vip_at: '',
                    ip: '',
                    ip_address: '',
                    vip: '',
                },
                dialog: {
                    title: '',
                    show: false,
                },
                canals: [],
            }
        },
        created(){
            this.getCanal();
        },
        activated(){
            if(this.$route.query.kwd){
                this.params.kwd = this.$route.query.kwd;
            }
            if(this.$route.query.id){
                this.params.id = this.$route.query.id;
            }
            this.list();
            this.$store.dispatch('setActive', '/user');
        },
        methods: {
            getCanal(){
                CanalSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.canals = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        this.form.vip_at = this.$moment(this.form.vip_at).format('YYYY-MM-DD HH:mm:ss');
                        UserUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                UserList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    vip: item.vip == 'free_vip' ? '' : item.vip,
                    created_at: item.created_at,
                    vip_at: item.vip_at,
                    ip: item.ip,
                    ip_address: item.ip_address,
                    username: item.username,
                };
                this.dialog.title = '编辑用户';
                this.dialog.show = true;
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该用户信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    UserDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>
    .demo-table-expand {
        font-size: 0;
    }
    .demo-table-expand label {
        width: 90px;
        color: #99a9bf;
    }
    .demo-table-expand .el-form-item {
        margin-right: 0;
        margin-bottom: 0;
        width: 33%;
    }
</style>
