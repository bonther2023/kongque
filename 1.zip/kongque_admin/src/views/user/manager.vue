<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    管理人员 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="正 常" name="1"></el-tab-pane>
                    <el-tab-pane label="锁 定" name="2"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()" size="medium" v-model="params.kwd" clearable placeholder="请输入账号或者昵称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          ref="multipleHandle"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column prop="username" label="账户" width="140"></el-table-column>
                    <el-table-column prop="nickname" label="昵称" width="140"></el-table-column>
<!--                    <el-table-column align="center" prop="name" label="角色" width="120"></el-table-column>-->
                    <el-table-column align="center" prop="status_text" label="状态" width="75">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="login_at" label="最近登录" width="165"></el-table-column>
                    <el-table-column label="操作" >
                        <template slot-scope="scope">
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain> 编辑</el-button>
                            <el-button v-if="scope.row.id > 1 && scope.row.status == 1" @click="lock(scope.row.id)" icon="fa fa-lock" type="danger" size="mini" plain> 锁定</el-button>
                            <el-button v-if="scope.row.id >1 && scope.row.status == 2" @click="active(scope.row.id)" icon="fa fa-unlock-alt" type="success" size="mini" plain> 启用</el-button>
                            <el-button v-if="scope.row.id >1 " @click="destroy(scope.row.id)" icon="fa fa-trash" type="info" size="mini" plain> 删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">
                    <el-form-item :rules="[{ required: true, message: '请填写管理员账户', trigger: 'blur'}]" label="管理员账户："
                                  prop="username">
                        <el-input clearable v-model="form.username" placeholder="请填写管理员账户"></el-input>
                    </el-form-item>
<!--                    <el-form-item label="管理员角色：" :rules="[{ required: true, message: '请选择管理员角色', trigger: 'blur'}]"-->
<!--                                  prop="role_id">-->
<!--                        <el-select filterable v-model="form.role_id" placeholder="请选择管理员角色">-->
<!--                            <el-option-->
<!--                                v-for="(role,index) in roles"-->
<!--                                :key="index"-->
<!--                                :label="role.name"-->
<!--                                :value="role.id">-->
<!--                            </el-option>-->
<!--                        </el-select>-->
<!--                    </el-form-item>-->
                    <el-form-item :rules="[{ required: true, message: '请填写管理员昵称', trigger: 'blur'}]" label="管理员昵称："
                                  prop="nickname">
                        <el-input clearable v-model="form.nickname" placeholder="请填写管理员昵称"></el-input>
                    </el-form-item>
                    <el-form-item v-if="form.id == 0" label="管理员密码：" prop="password">
                        <el-input clearable type="password" v-model="form.password" placeholder="请填写管理员密码，默认123456"></el-input>
                    </el-form-item>
                    <el-form-item v-else label="管理员密码：" prop="password">
                        <el-input clearable type="password" v-model="form.password" placeholder="请填写管理员密码，不填写表示不修改密码"></el-input>
                    </el-form-item>
                    <el-form-item label="管理员状态：" prop="status">
                        <el-radio-group v-model="form.status">
                            <el-radio :label="1" border>正常</el-radio>
                            <el-radio :label="2" border>锁定</el-radio>
                        </el-radio-group>
                    </el-form-item>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {ManagerList,ManagerUpdate,ManagerLock,ManagerActive,ManagerDestroy} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, kwd: '', status: 0},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    username: '',
                    nickname: '',
                    role_id: 1,
                    password: '',
                    status: 1,
                },
                dialog: {
                    title: '',
                    show: false,
                },
            }
        },
        created(){

        },
        activated(){
            this.$store.dispatch('setActive', '/manager');
            this.list();
        },
        methods: {
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        ManagerUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                ManagerList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form =  {
                    id: 0,
                    username: '',
                    nickname: '',
                    role_id: 1,
                    password: '',
                    status: 1,
                };
                this.dialog.title = '新增管理员';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    nickname: item.nickname,
                    username: item.username,
                    role_id: item.role_id,
                    password: '',
                    status: item.status,
                };
                this.dialog.title = '编辑管理员';
                this.dialog.show = true;
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //锁定
            lock(id){
                ManagerLock({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //激活
            active(id){
                ManagerActive({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该管理员信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    ManagerDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$message.error(res.msg);
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
