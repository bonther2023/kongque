<template>
    <div class="panel-content">
        <div class="panel-body">
            <div class="panel-header">
                <div class="panel-title">
                    渠道管理 <span>【共 <em> {{ listData.total ? listData.total : 0}} </em> 条记录】</span>
                </div>
                <el-tabs v-model="params.status" type="card" @tab-click="list">
                    <el-tab-pane label="全 部" name="0"></el-tab-pane>
                    <el-tab-pane label="正 常" name="1"></el-tab-pane>
                    <el-tab-pane label="锁 定" name="2"></el-tab-pane>
                </el-tabs>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="success" icon="fa fa-refresh" @click="list()" size="small"> 刷新</el-button>
                        <el-button type="primary" icon="fa fa-plus" @click="create()" size="small"> 新增</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item">
                            <el-input @input="search()" size="medium" v-model="params.username" clearable placeholder="请输入渠道名称" class="input-with-select">
                                <el-button type="primary" @click="search()" slot="append" icon="el-icon-search"></el-button>
                            </el-input>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-input  size="medium" @input="search()" v-model="params.id" clearable placeholder="渠道ID" class="input-with-select"/>
                        </div>
                        <div class="panel-search-item" style="width: 120px">
                            <el-select filterable size="medium" v-model="params.agent_id">
                                <el-option  label="代理(全部)" :value="0"></el-option>
                                <el-option
                                    v-for="item in agents"
                                    :key="item.id"
                                    :label="item.username"
                                    :value="item.id">
                                </el-option>
                            </el-select>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="努力加载中..."
                          element-loading-spinner="el-icon-loading"
                          ref="multipleHandle"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column align="center" prop="id" label="编号" width="60"></el-table-column>
                    <el-table-column prop="agent_name" label="代理名称" width="100"></el-table-column>
                    <el-table-column prop="username" label="用户名" width="115"></el-table-column>
                    <el-table-column prop="nickname" label="昵称" width="100"></el-table-column>
                    <el-table-column prop="balance" label="余额" width="100">
                        <template slot-scope="scope">
                            <span style="cursor: pointer" @click="open(scope.row.id,scope.row.balance)">{{ scope.row.balance }}</span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="canal_rebate" label="分成" width="60"></el-table-column>
                    <el-table-column align="center" prop="status_text" label="状态" width="75">
                        <template slot-scope="scope">
                            <span v-html="scope.row.status_text"></span>
                        </template>
                    </el-table-column>
                    <el-table-column align="center" prop="login_at" label="最近登录" width="165"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button @click="login(scope.row)" icon="fa fa-sign-in" type="primary" size="mini" plain>
                                授权
                            </el-button>
                            <el-button @click="edit(scope.row)" icon="fa fa-edit" type="primary" size="mini" plain>
                                编辑
                            </el-button>

                            <el-button v-if="scope.row.status == 1" @click="lock(scope.row.id)" icon="fa fa-lock"
                                       type="danger" size="mini" plain> 锁定
                            </el-button>
                            <el-button v-if="scope.row.status == 2" @click="active(scope.row.id)"
                                       icon="fa fa-unlock-alt" type="success" size="mini" plain> 启用
                            </el-button>
<!--                            <el-button @click="trade(scope.row.id)" icon="fa fa-yen" type="primary" size="mini" plain>-->
<!--                                结算-->
<!--                            </el-button>-->
                            <el-button @click="destroy(scope.row.id)" icon="fa fa-trash"
                                       type="info" size="mini" plain> 删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="上一页"
                                   next-text="下一页"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
            <!-- 表单弹窗-->
            <el-dialog fullscreen :modal="false"
                :title="dialog.title"
                :visible.sync="dialog.show" center>
                <el-form :model="form" ref="form" style="min-height: calc(100vh - 326px) !important;" label-width="120px">
                    <div style="display: flex">
                        <div style="width: 50%">
                            <el-form-item :rules="[{ required: true, message: '请上级代理名称', trigger: 'blur'}]" label="代理名称："
                                          prop="agent_id">
                                <el-select filterable v-model="form.agent_id" placeholder="请选择代理">
                                    <el-option
                                        v-for="item in agents"
                                        :key="item.id"
                                        :label="item.username"
                                        :value="item.id">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写渠道名称', trigger: 'blur'}]" label="渠道名称："
                                          prop="username">
                                <el-input clearable v-model="form.username" placeholder="请填写渠道名称"></el-input>
                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写渠道昵称', trigger: 'blur'}]" label="渠道昵称："
                                          prop="nickname">
                                <el-input clearable v-model="form.nickname" placeholder="请填写渠道昵称"></el-input>
                            </el-form-item>
                            <el-form-item label="渠道状态：" prop="status">
                                <el-radio-group v-model="form.status">
                                    <el-radio :label="1" border>正常</el-radio>
                                    <el-radio :label="2" border>锁定</el-radio>
                                </el-radio-group>
                            </el-form-item>
                            <el-form-item v-if="form.id == 0" label="渠道密码：" prop="password">
                                <el-input type="password" clearable v-model="form.password" placeholder="请填写渠道密码，默认123456"></el-input>
                            </el-form-item>
                            <el-form-item v-else label="渠道密码：" prop="password">
                                <el-input type="password" clearable v-model="form.password" placeholder="请填写渠道密码，不填写表示不修改密码"></el-input>
                            </el-form-item>
                            <el-form-item label="联系人：" prop="name">
                                <el-input clearable v-model="form.name" placeholder="请填写联系人"></el-input>
                            </el-form-item>
                            <el-form-item label="联系QQ：" prop="qq">
                                <el-input clearable v-model="form.qq" placeholder="请填写联系QQ"></el-input>
                            </el-form-item>
                            <el-form-item label="银行名称：" prop="bank">
                                <el-input clearable v-model="form.bank" placeholder="请填写银行名称"></el-input>
                            </el-form-item>
                            <el-form-item label="银行卡号：" prop="card">
                                <el-input clearable v-model="form.card" placeholder="请填写银行卡号"></el-input>
                            </el-form-item>
                            <el-form-item  label="APK名称：" prop="apk_name">
                                <el-input clearable v-model="form.apk_name" placeholder="APK名称"></el-input>
                            </el-form-item>
                        </div>
                        <div style="width: 50%">

                            <el-form-item label="日卡扣量：" prop="day_vip_rebate">
                                <el-input clearable v-model="form.day_vip_rebate" style="width: 70%" placeholder="日卡扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="月卡扣量：" prop="month_vip_rebate">
                                <el-input clearable v-model="form.month_vip_rebate" style="width: 70%" placeholder="月卡扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="半年卡扣量：" prop="quarter_vip_rebate">
                                <el-input clearable v-model="form.quarter_vip_rebate" style="width: 70%" placeholder="半年卡扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="年卡扣量：" prop="year_vip_rebate">
                                <el-input clearable v-model="form.year_vip_rebate" style="width: 70%" placeholder="年卡扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="终生卡扣量：" prop="forever_vip_rebate">
                                <el-input clearable v-model="form.forever_vip_rebate" style="width: 70%" placeholder="终生卡扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="免单订单数：" prop="amount_new_user">
                                <el-input clearable v-model="form.amount_new_user" style="width: 70%" placeholder="新用户免单数">
                                    <template slot="append">单</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="总订单数：" prop="order_num">
                                <el-input clearable v-model="form.order_num" style="width: 70%" placeholder="总订单数">
                                    <template slot="append">单</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="注册扣量：" prop="register_rebate">
                                <el-input clearable v-model="form.register_rebate" style="width: 70%" placeholder="注册扣量">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                            <el-form-item label="渠道分成：" prop="canal_rebate">
                                <el-input clearable v-model="form.canal_rebate" style="width: 70%" placeholder="渠道分成">
                                    <template slot="append">%</template>
                                </el-input>
                            </el-form-item>
                        </div>
                    </div>
                </el-form>
                <span slot="footer" class="dialog-footer">
                    <el-button type="primary" class="login-btn" :loading="buttonLoading"
                                 :disabled="formDisabled" @click="update">{{buttonTitle}}</el-button>
                    <el-button @click="dialog.show = false"  style="margin-left: 50px">关 闭</el-button>
                </span>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import {CanalList,CanalUpdate,CanalLock,CanalActive,CanalDestroy,AgentSelect,CanalDomain} from '@/utils/request';
    export default {
        data: function() {
            return {
                listData: [],//列表数据
                params: {page: 1, username: '',id: '', status: 0, agent_id : 0},
                loading: false,
                buttonLoading : false,
                formDisabled : false,
                buttonTitle : '保 存',
                form: {
                    id: 0,
                    agent_id: '',
                    username: '',
                    nickname: '',
                    status: 1,
                    password: '',
                    name: '',
                    qq: '',
                    bank: '',
                    card: '',
                    order_num: 0,
                    day_vip_rebate: 0,
                    month_vip_rebate: 30,
                    quarter_vip_rebate: 50,
                    year_vip_rebate: 100,
                    forever_vip_rebate: 100,
                    apk_name: '',
                    video_rebate: 50,
                    amount_new_user: 3,
                    canal_rebate: 90,
                    register_rebate: 60,
                },
                dialog: {
                    title: '',
                    show: false,
                },
                agents: [],
                canal_link: ''
            }
        },
        created(){
            this.getAgent();
            this.domain();
        },
        activated(){
            if(this.$route.query.agent_id){
                this.params.agent_id = this.$route.query.agent_id;
            }
            this.list();
            this.$store.dispatch('setActive', '/canal');
        },
        methods: {
            domain(){
                CanalDomain().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.canal_link = detail;
                });
            },
            login(info){
                let params = this.$crypto.encrypt({cid:info.id, aid: info.agent_id});
                let target = this.canal_link + "/authorize?params=" + encodeURIComponent(params);
                window.open(target, '_blank');
            },
            getAgent(){
                AgentSelect().then((res) => {
                    let detail = this.$crypto.decrypt(res.data);
                    this.agents = detail;
                });
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
            open(id,money) {
                this.$prompt('请输入金额', '余额', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    inputValue: money,
                }).then(({ value }) => {
                    CanalUpdate({params:this.$crypto.encrypt({id: id, balance:value})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.$notify({
                                title: '成功',
                                message: res.msg,
                                type: 'success',
                                duration: '1000',
                                onClose:() =>{
                                    this.list();
                                }
                            });
                        }
                    });
                }).catch(() => {});
            },
            //更新
            update(){
                this.$refs['form'].validate((valid) => {
                    if (valid) {
                        this.buttonLoading = true;
                        this.formDisabled = true;
                        this.buttonTitle = '保存中...';
                        CanalUpdate({params:this.$crypto.encrypt(this.form)}).then((res) => {
                            this.buttonLoading = false;
                            this.formDisabled = false;
                            this.buttonTitle = '保 存';
                            if(res.code){
                                this.$notify.error({
                                    title: '错误',
                                    message: res.msg
                                });
                            }else{
                                this.$notify({
                                    title: '成功',
                                    message: res.msg,
                                    type: 'success',
                                    duration: '1000',
                                    onClose:() =>{
                                        this.dialog.show = false;
                                        this.list();
                                    }
                                });
                            }
                        });
                    } else {
                        return false;
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                CanalList({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //新增
            create() {
                this.form = {
                    id: 0,
                    agent_id: '',
                    username: '',
                    nickname: '',
                    status: 1,
                    password: '',
                    name: '',
                    qq: '',
                    bank: '',
                    card: '',
                    order_num: 0,
                    day_vip_rebate: 0,
                    month_vip_rebate: 30,
                    quarter_vip_rebate: 50,
                    year_vip_rebate: 100,
                    forever_vip_rebate: 100,
                    apk_name: '',
                    video_rebate: 50,
                    amount_new_user: 3,
                    canal_rebate: 90,
                    register_rebate: 60,
                };
                this.dialog.title = '新增渠道';
                this.dialog.show = true;
            },
            //编辑
            edit(item) {
                this.form =  {
                    id: item.id,
                    agent_id: item.agent_id,
                    username: item.username,
                    nickname: item.nickname,
                    status: item.status,
                    password: '',
                    name: item.name,
                    qq: item.qq,
                    bank: item.bank,
                    card: item.card,
                    order_num: item.order_num,
                    day_vip_rebate: item.day_vip_rebate,
                    month_vip_rebate: item.month_vip_rebate,
                    quarter_vip_rebate: item.quarter_vip_rebate,
                    year_vip_rebate: item.year_vip_rebate,
                    forever_vip_rebate: item.forever_vip_rebate,
                    apk_name: item.apk_name,
                    video_rebate: item.video_rebate,
                    amount_new_user: item.amount_new_user,
                    canal_rebate: item.canal_rebate,
                    register_rebate: item.register_rebate,
                };
                this.dialog.title = '编辑渠道';
                this.dialog.show = true;
            },
            //筛选
            search(){
                this.params.page = 1;
                this.list();
            },
            //锁定
            lock(id){
                CanalLock({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //激活
            active(id){
                CanalActive({params:this.$crypto.encrypt({id: id})}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            message: res.msg
                        });
                    }else{
                        this.list();
                    }
                });
            },
            //删除
            destroy(id){
                this.$confirm('确定要删除该渠道信息吗？', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    CanalDestroy({params:this.$crypto.encrypt({id: id})}).then((res) => {
                        if(res.code){
                            this.$notify.error({
                                title: '错误',
                                message: res.msg
                            });
                        }else{
                            this.list();
                        }
                    });
                }).catch(() => {});
            },
        }
    }
</script>

<style scoped>

</style>
