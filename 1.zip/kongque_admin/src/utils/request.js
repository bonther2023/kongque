import Vue from 'vue'
import axios from 'axios';
import VueAxios from 'vue-axios';
import Qs from 'qs';
import cookie from 'vue-cookie';
import router from '../router';

Vue.use(VueAxios, axios);

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
    config.headers['Accept'] = 'application/json';
    //配置header的token信息
    // const ua = window.navigator.userAgent.toLowerCase();
    const token = cookie.get('token');
    if(token){
        config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config;
}, function (error) {
    return Promise.reject(error);
});

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
    // 对响应数据做点什么
    return response.data;
}, function (error) {
    // 对响应错误做点什么
    if(error.response.status == 401){
        cookie.delete('custom_online');
        cookie.delete('token');
        cookie.delete('username');
        return router.push({name:'login'})
    }else{
        return Promise.reject(error);
    }
});


// 定义基础路由
let base = '/admin';

//主页
export const Socket = params => { return axios.get(`${base}/socket`, {params:params}).then(res => res)};
export const UserOnline = params => { return axios.get(`${base}/online`, {params:params}).then(res => res)};
export const UserMonitor = params => { return axios.get(`${base}/monitor`, {params:params}).then(res => res)};
export const Count= params => { return axios.get(`${base}/count`, {params:params}).then(res => res)};
//登录
export const Captcha = params => { return axios.get(`${base}/captcha`, {params:params}).then(res => res)};
export const UserLogin = params => { return axios.post(`${base}/login`, Qs.stringify(params)).then(res => res)};

//管理员
export const ManagerList = params => { return axios.get(`${base}/manager/list`, {params:params}).then(res => res)};
export const ManagerUpdate = params => { return axios.post(`${base}/manager/update`, Qs.stringify(params)).then(res => res)};
export const ManagerLock = params => { return axios.post(`${base}/manager/lock`, Qs.stringify(params)).then(res => res)};
export const ManagerActive = params => { return axios.post(`${base}/manager/active`, Qs.stringify(params)).then(res => res)};
export const ManagerDestroy = params => { return axios.post(`${base}/manager/destroy`, Qs.stringify(params)).then(res => res)};

//代理
export const AgentList = params => { return axios.get(`${base}/agent/list`, {params:params}).then(res => res)};
export const AgentDomain = params => { return axios.get(`${base}/agent/domain`, {params:params}).then(res => res)};
export const AgentUpdate = params => { return axios.post(`${base}/agent/update`, Qs.stringify(params)).then(res => res)};
export const AgentLock = params => { return axios.post(`${base}/agent/lock`, Qs.stringify(params)).then(res => res)};
export const AgentActive = params => { return axios.post(`${base}/agent/active`, Qs.stringify(params)).then(res => res)};
export const AgentDestroy = params => { return axios.post(`${base}/agent/destroy`, Qs.stringify(params)).then(res => res)};
export const AgentSelect = params => { return axios.get(`${base}/agent/select`, {params:params}).then(res => res)};

//渠道
export const CanalList = params => { return axios.get(`${base}/canal/list`, {params:params}).then(res => res)};
export const CanalDomain = params => { return axios.get(`${base}/canal/domain`, {params:params}).then(res => res)};
export const CanalUpdate = params => { return axios.post(`${base}/canal/update`, Qs.stringify(params)).then(res => res)};
export const CanalLock = params => { return axios.post(`${base}/canal/lock`, Qs.stringify(params)).then(res => res)};
export const CanalActive = params => { return axios.post(`${base}/canal/active`, Qs.stringify(params)).then(res => res)};
export const CanalDestroy = params => { return axios.post(`${base}/canal/destroy`, Qs.stringify(params)).then(res => res)};
export const CanalSelect = params => { return axios.get(`${base}/canal/select`, {params:params}).then(res => res)};

//支付
export const PayList = params => { return axios.get(`${base}/pay/list`, {params:params}).then(res => res)};
export const PayUpdate = params => { return axios.post(`${base}/pay/update`, Qs.stringify(params)).then(res => res)};
export const PayLock = params => { return axios.post(`${base}/pay/lock`, Qs.stringify(params)).then(res => res)};
export const PayActive = params => { return axios.post(`${base}/pay/active`, Qs.stringify(params)).then(res => res)};
export const PayDestroy = params => { return axios.post(`${base}/pay/destroy`, Qs.stringify(params)).then(res => res)};
export const PaySelect = params => { return axios.get(`${base}/pay/select`, {params:params}).then(res => res)};

//配置
export const Configs = params => { return axios.get(`${base}/setting`, {params:params}).then(res => res)};
export const ConfigUpdate = params => { return axios.post(`${base}/setting/update`, Qs.stringify(params)).then(res => res)};
export const ConfigPlatform = params => { return axios.get(`${base}/setting/platform`, {params:params}).then(res => res)};

//广告
export const AdList = params => { return axios.get(`${base}/ad/list`, {params:params}).then(res => res)};
export const AdUpdate = params => { return axios.post(`${base}/ad/update`, Qs.stringify(params)).then(res => res)};
export const AdDestroy = params => { return axios.post(`${base}/ad/destroy`, Qs.stringify(params)).then(res => res)};

//分类
export const CategoryList = params => { return axios.get(`${base}/category/list`, {params:params}).then(res => res)};
export const CategoryUpdate = params => { return axios.post(`${base}/category/update`, Qs.stringify(params)).then(res => res)};
export const CategoryDestroy = params => { return axios.post(`${base}/category/destroy`, Qs.stringify(params)).then(res => res)};

//标签
export const TagList = params => { return axios.get(`${base}/tag/list`, {params:params}).then(res => res)};
export const TagUpdate = params => { return axios.post(`${base}/tag/update`, Qs.stringify(params)).then(res => res)};
export const TagDestroy = params => { return axios.post(`${base}/tag/destroy`, Qs.stringify(params)).then(res => res)};


//视频
export const VideoList = params => { return axios.get(`${base}/video/list`, {params:params}).then(res => res)};
export const VideoCategory = params => { return axios.get(`${base}/video/category`, {params:params}).then(res => res)};
export const VideoUpdate = params => { return axios.post(`${base}/video/update`, Qs.stringify(params)).then(res => res)};
export const VideoLock = params => { return axios.post(`${base}/video/lock`, Qs.stringify(params)).then(res => res)};
export const VideoActive = params => { return axios.post(`${base}/video/active`, Qs.stringify(params)).then(res => res)};
export const VideoDestroy = params => { return axios.post(`${base}/video/destroy`, Qs.stringify(params)).then(res => res)};
export const VideoInfo = params => { return axios.get(`${base}/video/info`, {params:params}).then(res => res)};

//订单
export const OrderList = params => { return axios.get(`${base}/order/list`, {params:params}).then(res => res)};
export const OrderUpdate = params => { return axios.post(`${base}/order/update`, Qs.stringify(params)).then(res => res)};

//流量趋势
export const FlowList = params => { return axios.get(`${base}/flow/list`, {params:params}).then(res => res)};

//报表
export const ReportList = params => { return axios.get(`${base}/report/list`, {params:params}).then(res => res)};
export const ReportCompare = params => { return axios.get(`${base}/report/compare`, {params:params}).then(res => res)};

//结算
export const TradeList = params => { return axios.get(`${base}/trade/list`, {params:params}).then(res => res)};
export const TradeUpdate = params => { return axios.post(`${base}/trade/update`, Qs.stringify(params)).then(res => res)};
export const TradeStatus= params => { return axios.post(`${base}/trade/status`, Qs.stringify(params)).then(res => res)};

//用户
export const UserList = params => { return axios.get(`${base}/user/list`, {params:params}).then(res => res)};
export const UserUpdate = params => { return axios.post(`${base}/user/update`, Qs.stringify(params)).then(res => res)};
export const UserDestroy = params => { return axios.post(`${base}/user/destroy`, Qs.stringify(params)).then(res => res)};

//图片
export const PhotoCategory = params => { return axios.get(`${base}/photo/category`, {params:params}).then(res => res)};
export const PhotoList = params => { return axios.get(`${base}/photo/list`, {params:params}).then(res => res)};
export const PhotoUpdate = params => { return axios.post(`${base}/photo/update`, Qs.stringify(params)).then(res => res)};
export const PhotoDestroy = params => { return axios.post(`${base}/photo/destroy`, Qs.stringify(params)).then(res => res)};

//小说
export const NovelCategory = params => { return axios.get(`${base}/novel/category`, {params:params}).then(res => res)};
export const NovelList = params => { return axios.get(`${base}/novel/list`, {params:params}).then(res => res)};
export const NovelUpdate = params => { return axios.post(`${base}/novel/update`, Qs.stringify(params)).then(res => res)};
export const NovelDestroy = params => { return axios.post(`${base}/novel/destroy`, Qs.stringify(params)).then(res => res)};

//楼凤
export const HarlotCategory = params => { return axios.get(`${base}/harlot/category`, {params:params}).then(res => res)};
export const HarlotList = params => { return axios.get(`${base}/harlot/list`, {params:params}).then(res => res)};
export const HarlotUpdate = params => { return axios.post(`${base}/harlot/update`, Qs.stringify(params)).then(res => res)};
export const HarlotDestroy = params => { return axios.post(`${base}/harlot/destroy`, Qs.stringify(params)).then(res => res)};

//客服
export const Custom = params => { return axios.get(`${base}/custom`, {params:params}).then(res => res)};
export const CustomUser = params => { return axios.get(`${base}/custom/user`, {params:params}).then(res => res)};
export const CustomLogout = params => { return axios.get(`${base}/custom/logout`, {params:params}).then(res => res)};

//批量操作
export const HandleTarget = params => { return axios.post(`${base}/handle/target`, Qs.stringify(params)).then(res => res)};
export const HandleThumb = params => { return axios.post(`${base}/handle/thumb`, Qs.stringify(params)).then(res => res)};
export const HandleImage = params => { return axios.post(`${base}/handle/image`, Qs.stringify(params)).then(res => res)};
