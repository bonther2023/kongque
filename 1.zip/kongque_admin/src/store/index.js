import Vue from 'vue';
import Vuex from 'vuex';
import Cookie from 'vue-cookie';
import {asyncRouterMap} from '@/router';
import {Configs} from '@/utils/request';

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        active: '',//菜单选中,主要针对F5刷新后菜单的默认选中
        routers: [],//权限筛选后的路由
        config: null,//所有系统配置
    },
    getters: {
        active: (state) => {
            return state.active;
        },
        routers: (state) => {
            return state.routers;
        },
        config: (state) => {
            return state.config;
        },
    },
    mutations: {
        SET_ACTIVE(state, param) {
            state.active = param;
        },
        SET_ROUTERS(state,param){
            state.routers = param;
        },
        USER_LOGIN(state, param) {
            Cookie.set('token', param.token, { expires: '7d' });
            Cookie.set('username', param.username, { expires: '7d' });
        },
        USER_LOGOUT() {
            Cookie.delete('custom_online');
            Cookie.delete('token');
            Cookie.delete('username');
        },
    },
    actions: {
        //设置菜单选中
        setActive({commit}, param) {
            commit('SET_ACTIVE', param);
        },
        //登陆
        userLogin({commit}, param) {
            return new Promise((resolve) => {
                commit('USER_LOGIN', param);
                resolve();
            });
        },
        //退出登录
        userLogout({commit}){
            return new Promise((resolve) => {
                commit('USER_LOGOUT');
                resolve();
            });
        },
        generateRoutes({commit}){
            //全部执行完再返回
            return new Promise(resolve => {
                const accessedRouters = asyncRouterMap.filter(v => {
                    return true;
                });
                commit('SET_ROUTERS', accessedRouters);
                resolve();
            });
        },
    },
    modules: {}
})
