// vue.config.js
module.exports = {
    devServer: {
        proxy: {
            '/admin': {
                target: 'https://rnmkq.koging.com',//http://www.aftersale.bh
                changeOrigin: true,
                ws: true,
                pathRewrite: {
                    // '^/api': ''
                }
            },
        }
    }
}
