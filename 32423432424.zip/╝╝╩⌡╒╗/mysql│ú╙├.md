## MYSQL 常用

### 批量替换

```php
table 表替换 field 字段的 str1 为 str2 
update `table` set `field` = replace(`field`, 'str1', 'str2');
```

