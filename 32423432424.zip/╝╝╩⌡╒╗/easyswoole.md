### 常用命令

```php
#启动
    php easyswoole server start -d
#停用
    php easyswoole server stop
```

### ES配置

```php
# 通信配置
map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}
upstream web{
	server 127.0.0.1:9510 weight=5 max_fails=3 fail_timeout=30s;
	keepalive 16;
}
server
{
    listen 80;
    server_name app.hzyktl.cn;
    index index.php index.html index.htm default.php default.htm default.html;
    root /www/wwwroot/web-app/Public;
    location / {
		try_files $uri @web;
		autoindex  off;
	}
	location @web {
		proxy_http_version 1.1;
		proxy_set_header Connection "keep-alive";
		proxy_set_header X-Real-IP $remote_addr;
		proxy_set_header X-Real-PORT $remote_port;
		proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
		proxy_set_header Host $http_host;
		proxy_set_header Scheme $scheme;
		proxy_set_header Server-Protocol $server_protocol;
		proxy_set_header Server-Name $server_name;
		proxy_set_header Server-Addr $server_addr;
		proxy_set_header Server-Port $server_port;
		proxy_pass http://web;
	}
    # 通信配置
    location =/ws {
      proxy_http_version 1.1;
      # proxy_connect_timeout 60s;
      # proxy_send_timeout 60s;
      # proxy_read_timeout：如果60秒内客户端没有发数据到服务端，那么Nginx会关闭连接；同时，Swoole的心跳设置也会影响连接的关闭
      proxy_read_timeout 300s;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Real-PORT $remote_port;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_set_header Host $http_host;
      proxy_set_header Scheme $scheme;
      proxy_set_header Server-Protocol $server_protocol;
      proxy_set_header Server-Name $server_name;
      proxy_set_header Server-Addr $server_addr;
      proxy_set_header Server-Port $server_port;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection $connection_upgrade;
      proxy_pass http://web;
    }
}
```

### 常见问题

```php
# 如果composer报错，可能是由于php禁用函数的问题
# 如果不能启动，EasySwoole的temp不能在虚拟机centos共享目录，可以设置成"/temp"
```

### 自定义函数

```php
"autoload": {
    "files":[
        "App/Helper/function.php"
    ]
}
#运行
composer dump-autoload
```







