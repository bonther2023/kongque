## 开启BBR加速

```php
BBR是google的TCP阻塞控制算法，可以最大程度的利用带宽，提升网络传输速率。
Linux kernel 4.9 及以上已支持 tcp_bbr
```

### ubuntu系统

```php
1、内核版本：
uname -r

2、开启BBR：
echo "net.core.default_qdisc=fq" >> /etc/sysctl.conf
echo "net.ipv4.tcp_congestion_control=bbr" >> /etc/sysctl.conf

3、保存生效：
sysctl -p

4、是否启用：
lsmod | grep bbr
```

