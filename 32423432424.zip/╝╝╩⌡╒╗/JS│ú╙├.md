## JS常用

### 复制

```js
function copy(message) {
    let input = document.createElement("input");
    input.value = message;
    document.body.appendChild(input);
    input.select();
    input.setSelectionRange(0, input.value.length), document.execCommand('Copy');
    document.body.removeChild(input);
}
```

### 获取get参数

```js
function getQueryString(name) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    let r = window.location.search.substr(1).match(reg); //search,查询？后面的参数，并匹配正则
    if (r != null) return unescape(r[2]);
    return null;
}
```

### 判断是否是IOS

```js
let isiOS = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
```

### 数字转万

```js
function numfix(num){
    //小于10000，直接显示
    if(parseInt(num) < 10000){
        return num;
    }
    let a = parseFloat(num) / 10000;
    //根据.分割结果
    let arr = a.toString().split('.');
    if(arr.length > 1 && arr[1].length > 1){
        return a.toFixed(2) + 'w';
    }else{
        return a  + 'w';
    }
},
```

