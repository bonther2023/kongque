## Vagrant开发box环境
### 安装Virtualbox
```php
依次打开：管理-全局设定-常规
设置默认虚拟电脑位置（不放C盘）
```
#### 安装Vagrant

查看vagrant版本
```php
vagrant -v
```
安装vagrant插件
```php
vagrant plugin install vagrant-vbguest --plugin-version 0.24
# vagrant-vbguest是安装Virtualbox增强工具的插件，不然不能设置共享文件夹
```
查看已安装的插件
```php
vagrant plugin list
```
安装centos/7镜像
```php
打开Vagrant box镜像库，找到centos/7的box镜像
```
初始化镜像
```php
vagrant init centos/7
# vagrant init完成后会在当前目录生成一个Vagrantfile文件，
# 该文件为vagrant启动虚拟机的配置文件。
# vagrant up会按Vagrantfile的配置项来启动虚拟机。
```
配置Vagrantfile
```php
	Vagrant.configure("2") do |config|
        # box name
        config.vm.box = "centos/7"
        
        # 配置端口转发
        # for Redis
    	config.vm.network "forwarded_port", guest: 6379, host: 6379
    	# for HTTP
    	config.vm.network "forwarded_port", guest: 80, host: 8080
    	# for MySQL
    	config.vm.network "forwarded_port", guest: 3306, host: 3306
    	# 批量端口转发
    	#for i in 9500..9599
    		#config.vm.network :forwarded_port, guest: i, host: i
    	#end
    	config.vm.network "forwarded_port", guest: 9500, host: 9500
    	config.vm.network "forwarded_port", guest: 9501, host: 9501
    	
        # 配置桥接网卡 
        config.vm.network "public_network"
        
        # 配置共享文件夹自动挂载
        config.vm.synced_folder "D:/www", "/home/www/"
        
        # 虚拟机配置设置
        config.vm.provider "virtualbox" do |vb|
            # 虚拟机名称
            vb.name = "centos7"
            # 是否在up的时候打开virtual box窗口
            vb.gui = false
            # 虚拟机内存大小
            vb.memory = "4096"
            # 虚拟机cpu个数
            vb.cpus = 2
        end
        
        # 默认启动后执行的命令
        config.vm.provision "shell", inline: <<-SHELL
        	# 切换到root用户 密码是vagrant 
        	su root
        	# yum库更新
        	yum -y update
        	# 安装基本的yum库
        	yum -y install git wget vim autoconf tree net-tools.x86_64
        SHELL
    end
```
启动vagrant
```php
vagrant up
# vagrant up过程会根据Vagrantfile文件的设置自动设置虚拟机
# 如果出现一些错误，可以尝试更新centos：yum -y update,这个命令可以多执行几次，知道更新完毕
```
登录vagrant
```php
vagrant ssh
# 登陆默认的用户是vagrant用户，没有密码
# centos镜像默认没有开启防火墙，也不需要开启，就算手动打开了，下一次登录的时候默认也是关闭的
# yum更新/安装一些扩展，由于登录用户不是root,所以会有权限问题，请在开始加上 "sudo" ,如果想切换到root,请执行 "su root" 命令
# root账户的默认登录密码是vagrant
```
设置登录密码
```php
su root
passwd root
# 连续输入两次密码即可
```
设置centos默认密码登录
```php
vim /etc/ssh/sshd_config
修改两项：
PasswordAuthentication yes
PermitRootLogin yes
保存
:wq
```
配置Vagrantfile
```php
Vagrant.configure("2") do |config|
    config.ssh.username = "root"
    config.ssh.password = "root"
    config.ssh.insert_key = "true"
end
```
重启vagrant
```php
vagrant reload 
# 再次用ssh登录的时候自动变成root登录，并要求输入密码，也可以用xshell等其他工具连了
配置该box的桌面启动
新建start.bat,写入以下内容：
start D:\laragon\bin\git\git-bash.exe --cd=D:\Vagrant
# start用于启动一个窗口
# D:\laragon\bin\git\git-bash.exe是git-bash的路径，如果路径中有空格，注意要用引号包起来，例如：D:\Program" "Files\git\git-bash.exe
# --cd=D:\Vagrant指定git-bash的启动目录
# 创建桌面快捷方式，并更改图标即可
配置系统环境（nginx+php+redis+mysql）
虚拟机可能会出现静态资源刷新慢或者不刷新的问题，请将nginx.conf中的sendfile的值设为off

```
#### 开发box环境

打包成本地box文件
```php
vagrant package --base centos7 --output box_name.box
# vagrant package可以不带任何参数
# --base是指代表本地box的名称，即config.vm.provider中的vb.name（虚拟机名称）
# --output是导出的box的名称
```
配置box的版本信息
```php
新建并编辑 metadata.json
{
    "name": "centos7",
    "versions": [{
        "version": "2019.03",
        "providers": [{
            "name": "virtualbox",
            "url": "box_name.box"
        }]
    }]
}
# metadata.json必须和box_name.box在同一目录
```
添加已有box到box列表
```php
vagrant box add metadata.json
# 查看box列表： vagrant box list
# 删除已有box： vagrant box remove box_name
```
新建虚拟机
```php
vagrant init box_name
vagrant up 
    
vagrant ssh登录报错：
Vagrant 使用中发生的 vagrant@127.0.0.1: Permission denied (publickey,gssapi-keyex,gssapi-with-mic)
修改.vagrant\machines\default\virtualbox右键属性-安全-高级，找到用户，设置用户禁用继承，修改用户权限完全控制就好 
```