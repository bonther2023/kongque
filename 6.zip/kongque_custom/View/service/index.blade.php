<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>管理中心</title>
    <meta name="description" content="">
    <meta name="keyword" content="">
    <meta http-equiv=”pragma” content=”no-cache” />
    <meta http-equiv=”Cache-Control” content=”no-cache, must-revalidate” />
    <meta http-equiv=”expires” content=”0″/>
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/element-ui@2.13.0/lib/theme-chalk/index.css">
    <style>
        [v-cloak]{
            display:none
        }
        .user-avatar{
            width: 50px;
            height: 50px;
            border-radius: 100%;margin-right: 10px;
        }
        .menu {
            width: 210px;height: calc(100vh - 110px);overflow-x: hidden;overflow-y: auto;display: inline-block;
        }
        .menu ul li{
            position: relative;height: 80px;
        }
        .menu ul li a {
            display: flex;
        }
        .menu ul li a span{
            width: 120px;
            display: inline-block;
            word-break: keep-all;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            position: relative;top:22px
        }
        .main .content .panel-content {
            margin: 15px 15px 0 225px;min-height: calc(100vh - 125px);
        }
        .main .content .panel-content {
            padding: 0;
        }
        .panel-body{
            display: flex;
        }
        .panel-body-chat{
            width: 50%;border-right: 1px solid #e8e8e8;height: calc(100vh - 125px);
        }
        .panel-body-chat .chat-pool{
            height: calc(50vh);overflow-x: hidden;overflow-y: auto;padding:15px 15px 0;
        }
        .panel-body-chat .chat-pool::-webkit-scrollbar{
            display: none;
        }
        .user-avatar{
            width: 40px;
            height: 40px;border-radius: 50%;
        }

        .msg-item{
            margin-bottom: 20px;width: 100%;
        }
        .msg-item-1{
            display: flex;
        }
        .msg-item-2{
            display: flex;
        }
        .msg-item-content{
            vertical-align: top;width: 100%;
        }
        .msg-item-content1{
            text-align: left;padding-left: 8px;
        }
        .msg-item-content2{
            padding-right: 8px;text-align: left;
        }
        .message{
            background: #ececec;display: inline-block;line-height: 20px;padding:8px 15px;border-radius: 5px;
            position: relative;margin-top: 15px;
        }
        .message1:after{
            content: '';
            position: absolute;
            left: -10px;
            top: 10px;
            width: 0;
            height: 0;
            border-style: dashed;
            border-color: transparent;
            overflow: hidden;
            border-width: 10px;
            border-top-style: solid;
            border-top-color: #ececec;
        }
        .message2{
            float: right;background-color: #5FB878;color: #FFF;line-height: 22px;
        }
        .message2:before{
            content: '';
            position: absolute;
            right: -10px;
            top: 10px;
            width: 0;
            height: 0;
            border-style: dashed;
            border-color: transparent;
            overflow: hidden;
            border-width: 10px;
            border-top-style: solid;
            border-top-color: #5FB878;
        }
        .msg-item-img{
            min-width: 40px;max-width: 40px;
        }
        .chat-title{
            font-size: 12px;color: #999;
        }
        .msg-item-1 .chat-title{
            position: relative;top:5px
        }
        .msg-item-2 .chat-title{
            position: relative;top:5px;text-align: right;
        }
        .chat-time{
            text-align: center;font-size: 12px;color:#fff;display: inline-block;width: 100%;margin-bottom: 10px;
        }
        .chat-time span{
            background: #cccfd2;padding: 5px 8px;border-radius: 3px;
        }


        .panel-body-chat .chat-text{
            border-top: 1px solid #e8e8e8;padding: 0 15px 15px;position: relative;
        }
        .panel-body-chat .chat-text .chat-icon{
            font-size: 26px;margin-right: 15px;
        }
        .panel-body-chat .chat-text .chat-icon .fa-image{
            font-size: 24px;
        }
        .el-textarea__inner {
            border: none !important;
            padding: 0 !important;
        }
        .el-badge {
            position: absolute;
            top: 16px !important;
            right: 16px !important;
        }
        .chat-avatar .user-avatar{
            width: 40px;
            height: 40px;
        }
        .emotion-box{
            position: absolute;    top: -200px;
            left: 10px;
            width: 352px;
            background: #fff; box-shadow: 0 0 20px rgba(0,0,0,.2);
            border: 1px solid #D9D9D9;border-radius: 5px;padding-bottom: 12px;
        }
        .emotion-box ul {
            padding-inline-start:15px;
        }
        .emotion-box .emotion-item{
            list-style: none;float: left;
            padding: 2px;cursor: pointer;
            border: 1px solid #D9D9D9;margin: -1px 0 0 -1px;
        }
        .emotion-box .emotion-item:hover{
            background: #ffb2b0;
        }
        .html-input{
            height: 150px;overflow-x: hidden;word-break: break-all;
            user-select: text;
            white-space: pre-wrap;
            -webkit-user-select: text;
            text-align: left;
        }
        .html-input::-webkit-scrollbar{
            display: none;
        }
        .html-input:focus{
            border: none;
            outline: none;
        }
        .el-dialog__body {
            padding: 10px 20px 30px !important;
        }
        .panel-body-ip{
            width: 50%;
            padding: 15px;height: calc(100vh - 130px);overflow-x: hidden;
        }
        .visitor{
            margin-bottom: 15px;
        }
        .el-input-group__prepend {
            width: 100px !important;text-align: center;
        }
        .words-li{
            list-style: none;padding-inline-start:0px;line-height: 45px;
        }
        .words-li li{
            border-bottom: 1px solid #e9e9e9;cursor: pointer;position: relative;
        }
        .words-li li .yingyong{
            font-size: 14px;position: absolute;right:0;bottom: 2px;
        }
    </style>
</head>
<body>
<div class="main" id="app" v-cloak>
    <header class="header">
        <div class="header-logo"  style="width: 210px">
            <span>客服工作台</span>
        </div>
        <div style="width: 200px;float: left;color: #fff;padding-left: 15px">状态：@{{ title }}</div>
        <div class="header-user">
            <ul>
                <li></li>
                <li>@{{ login.nickname }}</li>
                <li @click="logout"><a href="javascript:void(0)"><i class="fa fa-power-off"></i> 退出</a></li>
            </ul>
        </div>
    </header>
    <div class="menu sidebar-menu">
        <aside class="main-sidebar">
            <section class="sidebar" id="menu">
                <ul id="demo-list">
                    <li  v-for="(user,ui) in userList" :key="ui"
                         :class=" ui==userActive ? 'active' : ''"
                         @click="selectUser(ui,user)">
                        <a href="javascript:void(0)">
                            <img class="user-avatar" src="{{ asset('img/user_avatar.png') }}" alt="">
                            <span>@{{ user.username }}</span>
                        </a>
                        <el-badge v-if="user.unread" :value="user.unread" class="item"></el-badge>
                    </li>
                </ul>
            </section>
        </aside>
    </div>
    <div class="content">
        <div class="panel-content">
            <div class="panel-body">
                <div class="panel-body-chat">
                   <div style="position: absolute;top:0;left:0">
                       <el-dialog title="图片预览" :visible.sync="imageShow" width="50%">
                           <img style="max-width: 100%;margin: 0 auto" :src="imageLink" alt="">
                       </el-dialog>
                   </div>
                    <div ref="chatPool" class="chat-pool">
                        <div class="msg-item" v-for="(item,i) in chatList" :key="i">
                            <div class="msg-item-1" v-if="item.type == 1">
                                <div class="msg-item-img">
                                    <img class="user-avatar" src="{{ asset('img/user_avatar.png') }}"/>
                                </div>
                                <div class="msg-item-content msg-item-content1">
                                    <div class="chat-title">@{{ item.username }} <span style="margin-left: 10px">@{{ item.created_at }}</span></div>
                                    <div class="message message1" v-html="item.content"></div>
                                </div>
                            </div>
                            <div class="msg-item-2" v-if="item.type == 2">
                                <div class="msg-item-content msg-item-content2">
                                    <div class="chat-title"><span style="margin-right: 10px">@{{ item.created_at }}</span> @{{ item.custom_name }}</div>
                                    <div class="message message2" v-html="item.content"></div>
                                </div>
                                <div class="msg-item-img">
                                    <img class="user-avatar" src="{{ asset('img/custom_online.png') }}"/>
                                </div>
                            </div>
                        </div>
                        <div style="height: 10px"></div>
                    </div>
                    <div class="chat-text">
                        <div class="emotion-box" v-if="emotionShow">
                            <ul class="emotion-box-line" v-for="(line, i) in emotionList" :key="i" >
                                <li @click="selectEmoticon(i)" class="emotion-item"><img :src="'https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/' + i + '.gif'"></li>
                            </ul>
                        </div>
                        <div style="display: flex">
                            <el-button @click="openEmotion" class="chat-icon" icon="fa fa-smile-o" type="text"></el-button>
                            <el-upload
                                    class="avatar-uploader"
                                    action="{{ url_api('upload/image') }}"
                                    :show-file-list="false"
                                    name="image"
                                    :on-error="handleError"
                                    :accept="'image/*'"
                                    :on-success="handleSuccess"
                                    :before-upload="beforeUpload">
                                <el-button class="chat-icon" :disabled="disabled" icon="fa fa-image" type="text"></el-button>
                            </el-upload>
                        </div>
                        <div ref="contentBox" id="contentBox" autofocus contenteditable="true"  v-html="content" class="html-input"
                             placeholder="请输入内容"
                             @keyup="changeInput"
                             @blur="overInput" ></div>
                        <el-button style="float: right;margin-top: 25px" icon="el-icon-s-promotion" size="medium" @click="say()" type="primary">发送</el-button>
                        <div style="line-height: 10px;color: #a4abb5;margin-top: 35px;">
                            <p>注：enter键快捷发送 </p>
                            <p>截屏图片直接粘贴发送</p>
                            <p>F5刷新后没声音，点击一次页面即可</p>
                        </div>
                    </div>
                </div>
                <div class="panel-body-ip">
                    <el-tabs v-model="tabActive">
                        <el-tab-pane label="访客信息" name="visitor">
                            <div v-if="visitorData">
                                <el-input class="visitor" placeholder="访客编号" readonly v-model="visitorData.id">
                                    <template slot="prepend">访客编号</template>
                                </el-input>
                                <el-input class="visitor" placeholder="访客名称" readonly v-model="visitorData.username">
                                    <template slot="prepend">访客名称</template>
                                </el-input>
                                <el-input class="visitor" placeholder="注册时间" readonly v-model="visitorData.created_at">
                                    <template slot="prepend">注册时间</template>
                                </el-input>
                                <el-input class="visitor" placeholder="绑定手机" readonly v-model="visitorData.mobile">
                                    <template slot="prepend">绑定手机</template>
                                </el-input>
                                <el-input class="visitor" placeholder="VIP类型" readonly v-model="visitorData.vip">
                                    <template slot="prepend">VIP类型</template>
                                </el-input>
                                <el-input class="visitor" placeholder="过期时间" readonly v-model="visitorData.vip_at">
                                    <template slot="prepend">过期时间</template>
                                </el-input>
                                <el-input class="visitor" placeholder="系统名称" readonly v-model="visitorData.name">
                                    <template slot="prepend">系统名称</template>
                                </el-input>
                                <el-input class="visitor" placeholder="设备型号" readonly v-model="visitorData.model">
                                    <template slot="prepend">设备型号</template>
                                </el-input>
                                <el-input class="visitor" placeholder="系统版本" readonly v-model="visitorData.version">
                                    <template slot="prepend">系统版本</template>
                                </el-input>
                                <el-input class="visitor" placeholder="所用网络" readonly v-model="visitorData.network">
                                    <template slot="prepend">所用网络</template>
                                </el-input>
                                <el-input class="visitor" placeholder="访客IP" readonly v-model="visitorData.ip">
                                    <template slot="prepend">访客IP</template>
                                </el-input>
                                <el-input class="visitor" placeholder="IP地区" readonly v-model="visitorData.ip_address">
                                    <template slot="prepend">IP地区</template>
                                </el-input>
{{--                                <el-input class="visitor" placeholder="余额" readonly v-model="visitorData.balance">--}}
{{--                                    <template slot="prepend">余额</template>--}}
{{--                                </el-input>--}}
                            </div>
                        </el-tab-pane>
                        <el-tab-pane label="常用语" name="words">
                            <ul class="words-li">
                                <li v-for="(word,wi) in words" :key="wi">
                                    <span>@{{ wi+1 }}、@{{ word }}</span>
                                    <el-link @click="wordMessage(word,wi)" class="yingyong" type="primary">应用</el-link>
                                </li>
                            </ul>
                        </el-tab-pane>
                        <el-tab-pane label="订单信息" name="order">
                            <div v-if="orderList">
                                <el-table tooltip-effect="dark" :data="orderList" border>
                                    <el-table-column align="center" prop="created_at" label="日期" width="165"></el-table-column>
                                    <el-table-column align="center" prop="order_id" label="订单号" width="240"></el-table-column>
                                    <el-table-column align="center" prop="money" label="价格" width="50"></el-table-column>
                                    <el-table-column align="center" prop="payment_text" label="方式" width="75">
                                        <template slot-scope="scope">
                                            <span v-html="scope.row.payment_text"></span>
                                        </template>
                                    </el-table-column>
                                    <el-table-column align="center" prop="status_text" label="状态" width="80">
                                        <template slot-scope="scope">
                                            <span v-html="scope.row.status_text"></span>
                                        </template>
                                    </el-table-column>
                                    <el-table-column prop="pay_at" label="支付日期"></el-table-column>
                                </el-table>
                            </div>
                        </el-tab-pane>
                    </el-tabs>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        © 2015-2019 Powered By Video Management System
    </div>
</div>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/vue.min.js') }}"></script>
<script src="https://unpkg.com/element-ui@2.13.0/lib/index.js"></script>
<script>
    let app = new Vue({
        el: '#app',
        data: function () {
            return {
                title: '',
                order: null,
                userActive: 0,
                visitorData: null,
                orderList: null,
                tabActive: 'visitor',
                userActiveInfo: null,
                content: '',
                autoplay: false,
                ws: "{{ $ws }}",
                ping: null,
                audio: null,
                isLock: true,
                imageShow: false,
                imageLink: '',
                emotionShow: false,
                readonly: true,
                disabled: true,
                websocket: null,
                system: null,
                words: JSON.parse('{!! $words !!}'),
                login: JSON.parse('{!! $user !!}'),
                chatList: [],
                userList: JSON.parse('{!! $userList !!}'),
                emotionList: ['微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭',
                    '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱',
                    '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘',
                    '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼',
                    '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜'],
                // , '菜刀', '西瓜', '啤酒',
                // '篮球', '乒乓', '咖啡', '饭', '猪头', '玫瑰', '凋谢', '示爱', '爱心', '心碎', '蛋糕', '闪电', '炸弹',
                // '刀', '足球', '瓢虫', '便便', '月亮', '太阳', '礼物', '拥抱', '强', '弱', '握手', '胜利', '抱拳', '勾引',
                // '拳头', '差劲', '爱你', 'NO', 'OK', '爱情', '飞吻', '跳跳', '发抖', '怄火', '转圈', '磕头', '回头', '跳绳', '挥手',
                // '激动', '街舞', '献吻', '左太极', '右太极'
                scrollHeight: 0,
            }
        },
        created(){
            // 加锁
            this.lockInput();
            this.title = '正在连接...';
            // 设置标题
            this.connect();
        },
        mounted() {
            this.keyupSubmit();
            this.keyPaste();
            document.addEventListener('click', ()=>{
                this.autoplay = true;
            });
        },
        watch: {
            chatList(){
                this.$nextTick(()=>{
                    this.$refs.chatPool.scrollTop = this.$refs.chatPool.scrollHeight;
                });
            },
        },
        methods: {
            //粘贴事件
            keyPaste(){
                let that = this;
                this.$refs.contentBox.addEventListener('paste',function(e){
                    if ( !(e.clipboardData && e.clipboardData.items) ) {
                        return;
                    }
                    for (let i = 0, len = e.clipboardData.items.length; i < len; i++) {
                        let item = e.clipboardData.items[i];
                        if (item.kind === "file" && item.type.split("/")[0] == "image") {
                            let img = item.getAsFile();
                            that.getBase64(img).then(function(ret){
                                that.request("{{ url_api('upload/img') }}", {"img":ret}, 'POST').then((result) => {
                                    that.content += '<img class="up-img" style="max-width: 250px;height: auto" src="'+ result +'" />';
                                    that.say();
                                }).catch(()=>{});
                                // document.execCommand("insertImage",false,ret);
                            }).catch(function(ret){});
                        }
                    }
                })
            },
            getBase64(img) {
                return new Promise(function(resolve,reject){
                    const reader = new FileReader();
                    reader.addEventListener('load', () =>{resolve(reader.result)});
                    reader.readAsDataURL(img);
                })

            },
            keyupSubmit(){
                document.onkeydown=(event)=>{
                    if(event.keyCode === 13){
                        event.preventDefault();//禁止回车的默认换行
                    }
                }
            },
            connect(){
                let wsServer = this.ws;
                this.websocket = new WebSocket(wsServer);
                let that = this;
                this.websocket.onopen = function (evt) {
                    that.title = '连接成功';
                    //前端循环心跳,停留不断线
                    that.ping = setInterval(()=>{
                        that.websocket.send('PING');
                    }, 30000);
                    // 解锁
                    that.unlockInput();
                    //设置默认信息
                    if(that.userList.length){
                        that.userActiveInfo = that.userList[0];
                        let message = {
                            class: "Service",
                            action: 'login',
                            content: {login:that.login,userList:that.userList}
                        };
                        that.websocket.send(JSON.stringify(message));//通知在线
                        //获取第一个用户的相关数据
                        let message2 = {
                            class: "Service",
                            action: 'chatlog',
                            content: {platform:that.userActiveInfo.platform,user_id:that.userActiveInfo.user_id}
                        };
                        that.websocket.send(JSON.stringify(message2));
                    }
                };
                this.websocket.onclose = function (evt) {
                    that.title = '断开连接';
                    clearInterval(that.ping);
                };
                this.websocket.onmessage = function (evt) {
                    let result = JSON.parse(evt.data);
                    switch (result.type) {
                        case 'chat'://客服发送消息给用户
                            that.chatList.push(result.data);
                            break;
                        case 'replay'://客服接受用户发送的消息
                            let chat = result.data.chat;
                            let userInfo = result.data.user_info;
                            if(that.userList.length){
                                if(userInfo.user_id == that.userActiveInfo.user_id){
                                    //当前聊天窗口就是该用户的窗口
                                    that.chatList.push(chat);
                                }else{
                                    //如果用户存在于列表，增加未读消息提示,
                                    //如果用户不存在，则插入第一行
                                    let newUserIn = false;//是否在列表中
                                    that.userList.forEach((item,index)=>{
                                        if(item.user_id == userInfo.user_id){
                                            newUserIn = true;
                                            that.userList[index].unread ++;
                                        }
                                    });
                                    if(newUserIn == false){
                                        //首次消息未读为1
                                        userInfo['unread'] = 1;
                                        that.userList.unshift(userInfo);
                                        that.userActive ++;
                                    }
                                }
                            }else{
                                that.userList.unshift(userInfo);
                                that.chatList.push(chat);
                                that.userActiveInfo = userInfo;
                            }
                            that.aplayAudio();
                            break;
                        case 'chatlog':
                            setTimeout(()=>{
                                //更新当前用户未读消息为0
                                that.userList[that.userActive].unread = 0;
                                that.orderList = result.data.order;
                                that.visitorData = result.data.user;
                                that.chatList = result.data.chat;
                            },200);
                            break;
                        default:
                            break;
                    }
                };
                this.websocket.onerror = function (evt, e) {
                    console.log('Error occured: ' + evt.data);
                };
            },
            // 语音播放
            aplayAudio () {
                if(this.autoplay){
                    if(this.audio != null){
                        this.audio = null;
                    }
                    this.audio = new Audio();
                    this.audio.src = "{{ asset('js/tip.mp3') }}";
                    this.audio.play();
                }
            },
            //用户切换
            selectUser(ui,user){
                if(this.userActive != ui){
                    this.userActive = ui;
                    this.userActiveInfo = user;
                    this.orderList = null;
                    this.visitorData = null,
                    this.tabActive = 'visitor';
                    //获取聊天记录
                    let message = {
                        class: "Service",
                        action: 'chatlog',
                        content: {platform:user.platform,user_id:user.user_id}
                    };
                    this.websocket.send(JSON.stringify(message));
                }
            },
            //发送消息
            say() {
                if(!this.userList.length){
                    return false;
                }
                if(!this.content){
                    return false;
                }
                //选中的用户信息
                let message = {
                    class: "Service",
                    action: 'message',
                    content: {content:this.content,user:this.userActiveInfo,custom:this.login}
                };
                this.content = '';
                this.websocket.send(JSON.stringify(message));
            },
            wordMessage(word,i){
                if(!this.userList.length){
                    return false;
                }
                if(i == 0){
                    word = '<a class="download" style="color:#000"  href="javascript:void(0)">点我下载蜜蜂视频</a>';
                }
                //选中的用户信息
                let message = {
                    class: "Service",
                    action: 'message',
                    content: {content:word,user:this.userActiveInfo,custom:this.login}
                };
                this.websocket.send(JSON.stringify(message));
            },
            // 锁住输入框和禁用发送按钮
            lockInput(){
                this.readonly = true;
                this.disabled = true;
            },
            // 解锁输入框和发送按钮
            unlockInput(){
                this.readonly = false;
                this.disabled = false;
            },
            //ajax请求数据
            request(target,params,method){
                method = method ? method : 'GET';
                return new Promise((resolve, reject)=>{
                    $.ajax({
                        type: method,
                        url: target,
                        ContentType: "application/x-www-form-urlencoded",
                        data: params,
                        dataType: "json",
                        success:(result)=>{if(result.code){reject(false)}else{resolve(result.data)}},
                        error: (e)=>{reject(false)}
                    });
                });
            },
            openEmotion(){
                if(this.emotionShow){
                    this.emotionShow = false;
                }else{
                    this.emotionShow = true;
                }
            },
            changeInput(event){
                //防止中文输入的时候出现光标问题
                if(event.keyCode == 13){
                    this.content = event.target.innerHTML;
                    event.target.innerHTML = '';
                    this.say();
                }
            },
            overInput(event){
                this.content = event.target.innerHTML;
            },
            selectEmoticon(i){
                let imgHTML = `<img src="https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/${i}.gif">`;
                this.content  += imgHTML;
                this.emotionShow = false;
            },
            handleSuccess(res, file) {
                this.content += '<img class="up-img" style="max-width: 250px;height: auto" src="'+ res.data +'">';
                this.say();
            },
            handleError(res, file){
                console.log(JSON.stringify(res)); console.log(JSON.stringify(file));
            },
            beforeUpload(file) {
                if(this.disabled){
                    return false;
                }
                const isLt10M = file.size / 1024 / 1024 < 10;
                if (!isLt10M) {
                    this.$message.error('图片不能大于10M');
                }
                return isLt10M;
            },
            showImg(img){
                this.imageLink = img;
                this.imageShow = true;
            },
            logout(){
                let that = this;
                this.request("{{ url_service('logout') }}", {},'POST').then(() => {
                    let message = {
                        class: "Service",
                        action: 'offline',
                        content: {'userList' : that.userList, uid:that.login.id}
                    };
                    that.lockInput();
                    //登录
                    that.websocket.send(JSON.stringify(message));
                    that.websocket.close();
                    window.location.href = "{{ url_service('login') }}";
                }).catch(()=>{});
            }
        }
    });
    $(function () {
        $("body").on("click", ".up-img", function () {
            let img = $(this).attr('src');
            app.showImg(img);
        });
    });
</script>
</body>
</html>
