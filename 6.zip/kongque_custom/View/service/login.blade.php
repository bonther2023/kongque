<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>登录</title>
    <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/element-ui@2.13.0/lib/theme-chalk/index.css">
    <link href="{{ asset('css/util.css') }}" rel="stylesheet">
    <link href="{{ asset('css/main.css') }}" rel="stylesheet">
    <style>
        body {
            color: #545454;
            background: #93defe;
            font-family: '微软雅黑','Open Sans', sans-serif;
            padding: 0px !important;
            margin: 0px !important;
            font-size:14px;
        }
        a:hover, a:focus {
            text-decoration: none;
            outline: none;
        }
        [v-cloak]{
            display:none
        }
        .el-input__inner {
            border: none !important;
        }
        .label-input100{
            font-size: 16px;
        }
        .el-button{
            width: 100%;
            z-index: 55555;
            height: 100%;
            line-height: 1.8;
            background: #a64bf4;
            color: #fff;font-size: 16px;
            background: -webkit-linear-gradient(right, #00dbde, #12deb8, #fc00ff, #a64bf4);
            background: -o-linear-gradient(right, #00dbde, #12deb8, #fc00ff, #a64bf4);
            background: -moz-linear-gradient(right, #00dbde, #12deb8, #fc00ff, #a64bf4);
            background: linear-gradient(right, #00dbde, #12deb8, #fc00ff, #a64bf4);
            -webkit-transition: all 0.4s;
            -o-transition: all 0.4s;
            -moz-transition: all 0.4s;
            transition: all 0.4s;
        }
        .el-button:focus,.el-button:hover{
            color: #fff;
        }
    </style>
</head>
<body>
<div class="container main">
    <div class="row">
        <div class="col-lg-12" id="app" v-cloak>
            <div class="limiter">
                <div class="container-login100" style="background-image: url({{ asset('img/bg-01.jpg') }});">
                    <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                        <el-form class="login100-form validate-form" :model="form" status-icon ref="form">
                            <span class="login100-form-title p-b-43">客服登录</span>
                            <el-form-item :rules="[{ required: true, message: '请填写账号', trigger: 'blur'}]" prop="username">
                                <div class="wrap-input100 validate-input m-b-23" data-validate="请输入用户名">
                                    <span class="label-input100">用户名</span>
                                    <el-input prefix-icon="fa fa-user-o" type="text" placeholder="请填写账号" v-model="form.username" auto-complete="off"></el-input>
                                </div>

                            </el-form-item>
                            <el-form-item :rules="[{ required: true, message: '请填写密码', trigger: 'blur'}]" prop="password">
                                <div class="wrap-input100 validate-input" data-validate="请输入密码">
                                    <span class="label-input100">密码</span>
                                    <el-input prefix-icon="fa fa-unlock-alt" type="password" v-model="form.password" placeholder="请填写密码" auto-complete="off"></el-input>
                                </div>
                            </el-form-item>
                            <el-form-item>
                                <div class="container-login100-form-btn" style="margin-top: 15px">
                                    <div class="wrap-login100-form-btn">
                                        <el-button :loading="buttonLoading"
                                                   :disabled="formDisabled" @click="submitForm">
                                            @{{buttonTitle}}</el-button>
                                    </div>
                                </div>
                            </el-form-item>
                        </el-form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/vue.min.js') }}"></script>
<script src="https://unpkg.com/element-ui@2.13.0/lib/index.js"></script>
<script>
    $(function () {
        let app = new Vue({
            el: '#app',
            data: function() {
                return {
                    buttonLoading : false,
                    formDisabled : false,
                    buttonTitle : '登 录',
                    form: {username: '', password: ''},
                }
            },
            created(){
                this.keyupSubmit();
            },
            methods: {
                keyupSubmit(){
                    document.onkeydown=(event)=>{
                        if(event.keyCode === 13){
                            this.submitForm();
                        }
                    }
                },
                submitForm() {
                    this.$refs['form'].validate((valid) => {
                        if (valid) {
                            this.buttonLoading = true;
                            this.formDisabled = true;
                            this.buttonTitle = '登录中...';
                            let $this = this;
                            $.post("{{ url_service('login') }}",this.form,function(res){
                                $this.buttonLoading = false;
                                $this.formDisabled = false;
                                if(res.code){
                                    $this.buttonTitle = '登 录';
                                    $this.$message.error(res.msg);
                                }else{
                                    $this.$message({
                                        message: '登录成功，页面即将跳转......',
                                        type: 'success',
                                        duration: '1000',
                                        onClose:() =>{
                                            window.location.href = "{{ url_service() }}";
                                        }
                                    });
                                }
                            },'JSON ');
                        } else {
                            return false;
                        }
                    });
                    return false;
                },
            }
        });
    })
</script>
</html>
