<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>在线客服</title>
    <meta name="description" content="">
    <meta name="keyword" content="">
    <meta http-equiv=”pragma” content=”no-cache” />
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv=”Cache-Control” content=”no-cache, must-revalidate” />
    <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/element-ui@2.13.0/lib/theme-chalk/index.css">
    <meta http-equiv=”expires” content=”0″/>
    <style>
        [v-cloak]{
            display:none
        }
        body{
            overflow-x: hidden;background: #fff;
        }
        .title{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 50px;
            line-height: 50px;
            padding: 0 15px;
            background-color: #252942;
            border-top:0.5px solid #191a33;
            color: #fff;
            font-size: 18px;
        }
        .panel-body-chat{
            height: calc(100vh - 145px);margin-top: 50px;
        }
        .panel-body-chat::-webkit-scrollbar{
            display: none;
        }
        .panel-body-chat .chat-pool{
            height: calc(100vh - 145px);overflow-x: hidden;overflow-y: auto;padding-top: 15px;
        }
        .panel-body-chat .chat-pool::-webkit-scrollbar{
            display: none;
        }
        .user-avatar{
            width: 40px;
            height: 40px;border-radius: 50%;
        }

        .msg-item{
            margin-bottom: 20px;
        }
        .msg-item-1{
            display: flex;
        }
        .msg-item-2{
            display: flex;
        }
        .msg-item-content{
            width: calc(86vw);vertical-align: top;
        }
        .msg-item-content1{
            text-align: left;
        }
        .msg-item-content2{
            padding-right: 8px;text-align: left;
        }
        .message{
            background: #E5E5E5;display: inline-block;line-height: 20px;border-radius: 5px;
            position: relative;margin-top: 15px;padding:8px 10px 10px 10px;
        }
        .message1:after{
            content: '';
            position: absolute;
            left: -10px;
            top: 10px;
            width: 0;
            height: 0;
            border-style: dashed;
            border-color: transparent;
            overflow: hidden;
            border-width: 10px;
            border-top-style: solid;
            border-top-color: #E5E5E5;
        }
        .message2{
            float: right;background-color: #12B7F5;color: #FFF;line-height: 22px;
        }
        .message2:before{
            content: '';
            position: absolute;
            right: -10px;
            top: 10px;
            width: 0;
            height: 0;
            border-style: dashed;
            border-color: transparent;
            overflow: hidden;
            border-width: 10px;
            border-top-style: solid;
            border-top-color: #12B7F5;
        }
        .msg-item-img{
            width: calc(14vw);
        }
        .chat-title{
            font-size: 12px;
        }
        .msg-item-1 .chat-title{
            position: relative;top:5px
        }
        .msg-item-2 .chat-title{
            position: relative;top:5px;text-align: right;
        }
        .chat-time{
            text-align: center;font-size: 12px;color:#fff;display: inline-block;width: 100%;margin-bottom: 10px;

        }
        .chat-time span{
            padding: 5px 8px;border-radius: 3px;color: #cccccc;
        }
        .handle{
            position: fixed;bottom: 0;left:0;right: 0;height: 80px;
            padding: 0 10px;background: #fff;
        }
        .handle .chat-icon{
            font-size: 26px;
        }
        .chat-icon .el-button{
            margin-right: 10px !important;
        }
        .handle .chat-icon .fa-image{
            font-size: 24px;
        }
        .handle-input{
            display: flex;
            /*width: calc(90vw) !important;*/
        }
        .html-input{
            height: 24px;overflow-x: hidden;word-break: break-all;
            user-select: text;width:calc(80vw);background: #E5E5E5;
            white-space: pre-wrap;
            -webkit-user-select: text;padding: 8px;
            text-align: left;margin-right: 15px;border-radius: 5px;
        }
        .html-input::-webkit-scrollbar{
            display: none;
        }
        .html-input:focus{
            border: none;
            outline: none;
        }
        .emotion-box{
            position: absolute;bottom: 85px;height: calc(30vh);
            overflow-x: hidden;
            left: calc(3vw);
            width: calc(92.5vw);background: #fff; box-shadow: 0 0 5px rgba(0,0,0,.2);
            border: 1px solid #D9D9D9;border-radius: 5px;padding-bottom: 10px;padding-right: 5px;
        }
        .emotion-box ul {
            padding-inline-start:10px;
        }
        .emotion-box .emotion-item{
            list-style: none;float: left;
            padding: 2px;cursor: pointer;
            border: 1px solid #D9D9D9;margin: -1px 0 0 -1px;
        }
        .emotion-box .emotion-item:hover{
            background: #ffb2b0;
        }
        .handle-icon{
            display: flex;
        }
        @media screen and (max-width: 320px) {
            .emotion-box .emotion-item{
                padding: 3px;
            }
        }
        .system{
            width: 100%;padding-top: 75px;
        }


        #loading {
            width: 180px;
            margin:calc(30vh) 0 0 calc(28vw);
        }
        #loading h1 {
            font-family: 'Lato';
            color: #252942;
            text-transform: uppercase;
            font-size: 1em;
            letter-spacing: 1.5px;
            text-align: center;
            width: 155px;
            margin-top: 20px;
            -webkit-animation: fade 2s infinite;
            -moz-animation: fade 2s infinite;
        }

        .stick {
            width: 30px;
            height: 3px;
            background: #252942;
            display: inline-block;
            margin-left: -8px;
        }

        .stick:nth-child(n) {
            transform: rotate(30deg);
            -ms-transform: rotate(30deg);
            /* IE 9 */
            -webkit-transform: rotate(30deg);
            /* Safari and Chrome */
            -moz-transform: rotate(30deg);
            -webkit-animation: fall 2s infinite;
            -moz-animation: fall 2s infinite;
        }

        .stick:nth-child(2n) {
            transform: rotate(-30deg);
            -ms-transform: rotate(-30deg);
            /* IE 9 */
            -webkit-transform: rotate(-30deg);
            /* Safari and Chrome */
            -moz-transform: rotate(-30deg);
            -webkit-animation: rise 2s infinite;
            -moz-animation: rise 2s infinite;
        }

        @-webkit-keyframes rise {
            50% {
                transform: rotate(30deg);
                -ms-transform: rotate(30deg);
                /* IE 9 */
                -webkit-transform: rotate(30deg);
                -moz-transform: rotate(30deg);
            }
        }
        @-moz-keyframes rise {
            50% {
                transform: rotate(30deg);
                -ms-transform: rotate(30deg);
                /* IE 9 */
                -webkit-transform: rotate(30deg);
                -moz-transform: rotate(30deg);
            }
        }
        @-o-keyframes rise {
            50% {
                transform: rotate(30deg);
                -ms-transform: rotate(30deg);
                /* IE 9 */
                -webkit-transform: rotate(30deg);
                -moz-transform: rotate(30deg);
            }

        @keyframes rise {
            50% {
                transform: rotate(30deg);
                -ms-transform: rotate(30deg);
                /* IE 9 */
                -webkit-transform: rotate(30deg);
                -moz-transform: rotate(30deg);
            }
        }
        }
        @-webkit-keyframes fall {
            50% {
                transform: rotate(-30deg);
                -ms-transform: rotate(-30deg);
                /* IE 9 */
                -webkit-transform: rotate(-30deg);
                -moz-transform: rotate(30deg);
            }
        }
        @-moz-keyframes fall {
            50% {
                transform: rotate(-30deg);
                -ms-transform: rotate(-30deg);
                /* IE 9 */
                -webkit-transform: rotate(-30deg);
                -moz-transform: rotate(-30deg);
            }
        }
        @-o-keyframes fall {
            50% {
                transform: rotate(-30deg);
                -ms-transform: rotate(-30deg);
                /* IE 9 */
                -webkit-transform: rotate(-30deg);
                -moz-transform: rotate(30deg);
            }

        @keyframes fall {
            50% {
                transform: rotate(-30deg);
                -ms-transform: rotate(-30deg);
                /* IE 9 */
                -webkit-transform: rotate(-30deg);
                -moz-transform: rotate(30deg);
            }
        }
        }
        @-webkit-keyframes fade {
            50% {
                opacity: 0.5;
            }

            100% {
                opacity: 1;
            }
        }
        @-moz-keyframes fade {
            50% {
                opacity: 0.5;
            }

            100% {
                opacity: 1;
            }
        }
        @-o-keyframes fade {
            50% {
                opacity: 0.5;
            }

            100% {
                opacity: 1;
            }

        @keyframes fade {
            50% {
                opacity: 0.5;
            }

            100% {
                opacity: 1;
            }
        }
        .el-button--primary {
            color: #FFF;
            background-color: #12B7F5;
            border-color: #12B7F5;
        }
    </style>
</head>
<body>
<div class="main">
    <div id="loading">
        <div class="stick"></div>
        <div class="stick"></div>
        <div class="stick"></div>
        <div class="stick"></div>
        <div class="stick"></div>
        <div class="stick"></div>
        <h1>正在链接客服，请稍后...</h1>
    </div>
    <div class="content" id="app" v-cloak style="overflow-x: hidden">
        <div v-if="titleShow" class="title">@{{ title }}<span v-if="online == 2">(在线)</span>
            <span v-if="online == 1">(离线)</span></div>
        <div class="panel-body-chat">
            <div v-if="system && (chatList.length == 0)" class="system">
                @{{ system }}
            </div>
            <div ref="chatPool" class="chat-pool">
                <div class="msg-item" v-for="(item,i) in chatList" :key="i">
                    <div class="chat-time"><span>@{{ item.created_at }}</span></div>
                    <div class="msg-item-1" v-if="item.type == 2">
                        <div class="msg-item-img">
                            <img v-if="online == 2" class="user-avatar" src="{{ asset('img/custom_online.png') }}"/>
                            <img v-if="online == 1" class="user-avatar" src="{{ asset('img/custom.png') }}"/>
                        </div>
                        <div class="msg-item-content msg-item-content1">
                            <div  v-if="online == 2" class="chat-title" style="color:#252942">
                                @{{ item.custom_name }}
                                <span>(在线)</span>
                            </div>
                            <div v-if="online == 1" class="chat-title" style="color:#000">
                                @{{ item.custom_name }}
                                <span>(离线)</span>
                            </div>
                            <div class="message message1" v-html="item.content"></div>
                        </div>
                    </div>
                    <div class="msg-item-2" v-if="item.type == 1">
                        <div class="msg-item-content msg-item-content2">
                            <div class="chat-title">@{{ item.username }}</div>
                            <div class="message message2" v-html="item.content"></div>
                        </div>
                        <div class="msg-item-img">
                            <img class="user-avatar" src="{{ asset('img/user_avatar.png') }}"/>
                        </div>
                    </div>
                </div>
                <div style="height: 15px"></div>
            </div>
        </div>
        <div class="emotion-box"  v-if="emotionShow">
            <ul class="emotion-box-line" v-for="(line, i) in emotionList" :key="i" >
                <li @click="selectEmoticon(i)" class="emotion-item">
                    <img :src="'https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/' + i + '.gif'">
                </li>
            </ul>
        </div>
        <div class="handle">
            <div class="handle-input">
                <div ref="contentBox" contenteditable="true" v-html="content" class="html-input"
                     placeholder="请输入内容"
                     @blur="changeInput"
                     ></div>
                <el-button type="primary" :disabled="disabled" @click="say" style="border: none;height: 40px">发送</el-button>
            </div>
            <div class="handle-icon">
                <el-button @click="openEmotion" class="chat-icon" icon="fa fa-smile-o" style="padding: 8px 3px 8px;margin-right: 15px" type="text"></el-button>
                <el-upload
                        class="avatar-uploader"
                        action="{{ url_api('upload/image') }}"
                        :show-file-list="false"
                        name="image"
                        :accept="'image/*'"
                        :on-error="handleError"
                        :on-success="handleSuccess"
                        :before-upload="beforeUpload">
                    <el-button style="padding: 8px 3px 8px;" class="chat-icon" icon="fa fa-image" type="text"></el-button>
                </el-upload>
            </div>
        </div>
    </div>
</div>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/vue.min.js') }}"></script>
<script src="https://unpkg.com/element-ui@2.13.0/lib/index.js"></script>
<script>
    document.onreadystatechange = documentReadyState;
    //页面状态处理
    function documentReadyState() {
        if (document.readyState == "complete") {
            let loadingMask = document.getElementById('loading');
            loadingMask.parentNode.removeChild(loadingMask);
        }
    }
</script>
<script>
    let app = new Vue({
        el: '#app',
        data: function () {
            return {
                title: '',
                titleShow: false,
                content: '',
                readonly: true,
                online: 0,
                disabled: true,
                websocket: null,
                isLock: true,
                system: null,
                ws: "{{ $ws }}",
                login: JSON.parse('{!! $userInfo !!}'),
                chatList: [],
                emotionShow: false,
                emotionList: ['微笑', '撇嘴', '色', '发呆', '得意', '流泪', '害羞', '闭嘴', '睡', '大哭',
                    '尴尬', '发怒', '调皮', '呲牙', '惊讶', '难过', '酷', '冷汗', '抓狂', '吐', '偷笑', '可爱',
                    '白眼', '傲慢', '饥饿', '困', '惊恐', '流汗', '憨笑', '大兵', '奋斗', '咒骂', '疑问', '嘘',
                    '晕', '折磨', '衰', '骷髅', '敲打', '再见', '擦汗', '抠鼻', '鼓掌', '糗大了', '坏笑', '左哼哼',
                    '右哼哼', '哈欠', '鄙视', '委屈', '快哭了', '阴险', '亲亲', '吓', '可怜'],
            }
        },
        created(){
            this.titleShow = true;
            // 加锁
            this.lockInput();
            // 设置标题
            this.title = '拼命呼叫打瞌睡的客服...';
            this.connect();
        },
        mounted() {
            // 监听中文输入
            const el = this.$refs.contentBox;
        },
        watch: {
            chatList(){
                this.$nextTick(()=>{
                    this.$refs.chatPool.scrollTop = this.$refs.chatPool.scrollHeight;
                });
            }
        },
        methods: {
            goBack(){
                window.history.go(-1);
            },
            connect(){
                let wsServer = this.ws;
                this.websocket = new WebSocket(wsServer);
                let that = this;
                this.websocket.onopen = function (evt) {
                    // 解锁
                    setTimeout(()=>{
                        let message = {
                            class: "Index",
                            action: 'login',
                            content: that.login
                        };
                        that.websocket.send(JSON.stringify(message));
                        that.unlockInput();
                    },1000);
                };

                this.websocket.onclose = function (evt) {
                    that.title = '客服消失了';
                    that.lockInput();
                    that.online = 0;
                };
                this.websocket.onmessage = function (evt) {
                    let result = JSON.parse(evt.data);
                    switch (result.type) {
                        case 'system'://登录没有消息发送系统消息
                            that.system = result.data.content;
                            that.online = result.data.online;
                            break;
                        case 'chat'://用户发送消息
                            that.chatList = that.chatList.concat(result.data);
                            break;
                        case 'replay'://客服回复消息
                            that.chatList = that.chatList.concat(result.data);
                            break;
                        case 'login'://登录有消息
                            that.chatList = result.data.list;
                            that.online = result.data.online;
                            that.title = '客服阿蓝';
                            setTimeout(()=>{
                                that.$refs.chatPool.scrollTop = that.$refs.chatPool.scrollHeight;
                            },200);
                            break;
                        case 'online'://客服连接成功
                            that.online = result.data;
                            break;
                        case 'offline'://客服下线
                            that.online = result.data;
                            break;
                        default:
                            break;
                    }
                };
                this.websocket.onerror = function (evt, e) {
                    console.log('Error occured: ' + evt.data);
                };
            },
            say() {
                if(!this.content){
                    return false;
                }
                let message = {
                    class: "Index",
                    action: 'message',
                    content: {content:this.content,uid:this.login.user_id}
                };
                this.content = '';
                this.websocket.send(JSON.stringify(message));
            },
            // 锁住输入框和禁用发送按钮
            lockInput(){
                this.readonly = true;
                this.disabled = true;
            },
            // 解锁输入框和发送按钮
            unlockInput(){
                this.readonly = false;
                this.disabled = false;
            },
            changeInput(event){
                this.content = event.target.innerHTML;
            },
            handleError(res, file){
                console.log(JSON.stringify(res)); console.log(JSON.stringify(file));
            },
            handleSuccess(res, file) {
                this.content = '<img class="up-img" style="max-width: 250px;height: auto" src="'+ res.data +'">';
                let message = {
                    class: "Index",
                    action: 'message',
                    content: {content:this.content,uid:this.login.user_id}
                };
                this.content = '';
                this.websocket.send(JSON.stringify(message));
            },
            beforeUpload(file) {
                if(this.disabled){
                    return false;
                }
                const isLt10M = file.size / 1024 / 1024 < 10;
                if (!isLt10M) {
                    this.$message.error('图片不能大于10M');
                }
                return isLt10M;
            },
            openEmotion(){
                if(this.disabled){
                    return false;
                }
                if(this.emotionShow){
                    this.emotionShow = false;
                }else{
                    this.emotionShow = true;
                }
            },
            selectEmoticon(i){
                let imgHTML = `<img src="https://res.wx.qq.com/mpres/htmledition/images/icon/emotion/${i}.gif">`;
                this.content  += imgHTML;
                this.emotionShow = false;
            },
        }
    });
    $(function () {
        $("body").on("click", ".download", function () {
            let link = 'https://www.96que.com';
            plus.runtime.openURL(link);
        });
    });
</script>
</body>
</html>
