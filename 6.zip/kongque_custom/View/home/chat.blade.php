<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>管理中心</title>
    <meta name="description" content="">
    <meta name="keyword" content="">
    <meta http-equiv=”pragma” content=”no-cache” />
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv=”Cache-Control” content=”no-cache, must-revalidate” />
    <meta http-equiv=”expires” content=”0″/>
    <style>
        [v-cloak]{
            display:none
        }
    </style>
</head>
<body>
<div class="main">
    <div class="content" id="app" v-cloak>
        <div class="title">@{{ title }}</div>

{{--        <div v-if="system && (chatList.length == 0)" class="system">@{{ system.content }} @{{ system.time }}</div>--}}
{{--        <div v-if="chatList.length">--}}
{{--            <ul ref="line">--}}
{{--                <li v-for="(item,i) in chatList" :key="i">--}}
{{--                    @{{ item.content }}---[@{{ item.created_at }}]--}}
{{--                </li>--}}
{{--            </ul>--}}
{{--        </div>--}}
{{--        <input type="text" :readonly="readonly" v-model="content"  id="says">--}}
{{--        <button @click="say()" :disabled="disabled">发送</button>--}}
    </div>
</div>
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script src="{{ asset('js/vue.min.js') }}"></script>
<script>
    let app = new Vue({
        el: '#app',
        data: function () {
            return {
                title: '',
                content: '',
                readonly: true,
                disabled: true,
                websocket: null,
                system: null,
                login: JSON.parse('{!! $user !!}'),
                chatList: [],
            }
        },
        created(){
            // 加锁
            this.lockInput();
            // 设置标题
            this.title = '连接中...';
            // this.connect();
        },
        mounted() {

        },
        filters:{
            // dateFilter(value){
            //     return moment(value).format('YYYY-MM-DD');
            // }
        },
        methods: {
            connect(){
                let wsServer = 'ws://www.custom.bh/ws';
                this.websocket = new WebSocket(wsServer);
                let that = this;
                this.websocket.onopen = function (evt) {
                    //前端循环心跳,停留不断线
                    setInterval(()=>{
                        that.websocket.send('PING');
                    }, 30000);
                    // 解锁
                    setTimeout(()=>{
                        let message = {
                            class: "Index",
                            action: 'login',
                            content: that.login
                        };
                        //此处应该设置登录操作，返回token
                        that.websocket.send(JSON.stringify(message));
                        that.unlockInput();
                        that.title = '连接成功';
                    },1000);
                };
                this.websocket.onclose = function (evt) {
                    that.title = '连接关闭';
                    // that.title = '已断开，正在重连...';
                    // that.lockInput();
                    // setTimeout(()=>{
                    //     console.log('重连...');
                    //     that.connect();
                    // },2000);
                };
                this.websocket.onmessage = function (evt) {
                    let result = JSON.parse(evt.data);
                    console.log(result);
                    switch (result['type']) {
                        case 'system'://登录没有消息发送系统消息
                            that.system = result.data;
                            break;
                        case 'chat'://用户发送消息
                            that.chatList = that.chatList.concat(result.data);
                            break;
                        case 'login'://登录有消息
                            // that.chatList = result.data;
                            break;
                        default:
                            break;
                    }
                    // that.addLine('Retrieved data from server: ' + evt.data);
                };
                this.websocket.onerror = function (evt, e) {
                    that.addLine('Error occured: ' + evt.data);
                };
            },
            say() {
                let message = {
                    class: "Index",
                    action: 'message',
                    content: {content:this.content}
                };
                this.content = '';
                this.websocket.send(JSON.stringify(message));
            },
            // 锁住输入框和禁用发送按钮
            lockInput(){
                this.readonly = true;
                this.disabled = true;
            },
             // 解锁输入框和发送按钮
            unlockInput(){
                this.readonly = false;
                this.disabled = false;
            }
        }
    });
</script>
</body>
</html>
