<?php

namespace App\WebSocket;

use App\Model\Admins;
use App\Model\Customs;
use App\Model\CustomsModel;
use App\Model\Messages;
use App\Model\MessagesModel;
use App\Model\Users;
use App\Model\UsersModel;
use App\Utility\JwtToken;
use Carbon\Carbon;
use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\EasySwoole\Task\TaskManager;
use EasySwoole\RedisPool\RedisPool as Redis;
use EasySwoole\Socket\AbstractInterface\Controller;
use EasySwoole\FastCache\Cache;


/**
 * Class Index
 *
 * 此类是默认的 websocket 消息解析后访问的 控制器
 *
 * @package App\WebSocket
 */
class Kong extends Controller
{
    // ws://www.custom.bh/ws
    // http://www.custom.bh/service
    // http://www.custom.bh/custom

    /**
     * 检查当前连接是否有效
     * @param int $id 用户ID
     * @param int $fd 连接ID
     * @return bool
     */
    function check($id = 0, $fd = 0){
        if(!$id || !$fd) return false;
        //获取缓存
        $cache = Redis::defer('redis');
        $custom = $cache->get('custom:'.$id);
        //不存在或者用户身份不一样肯定不在线
        if(!$custom) return false;
        //存在不一定在线
        $server = ServerManager::getInstance()->getSwooleServer();
        $customClientInfo = $server->getClientInfo($fd);
        if($customClientInfo && $customClientInfo['websocket_status'] === WEBSOCKET_STATUS_FRAME){
            return true;
        }
        return false;
    }

    function login()
    {
        //获取用户登录参数
        $params = $this->caller()->getArgs();
        $userInfo = $params;
        //获取用户连接ID
        $fd = $this->caller()->getClient()->getFd();

        //更新缓存数据
        $cache = Redis::defer('redis');
        $cache->set('user:'.$userInfo['user_id'],$userInfo,86400);

        //更新数据库
        $userModel = Customs::create();
        $userModel->update(['socket_id' => $fd],['user_id' => $userInfo['user_id']]);

        //判断客服是否在线,客服固定admin的数据
        $customModel = Admins::create();
        $customInfo = $customModel->get(1);
        $check = $this->check(1, $customInfo['socket_id']);
        $online = 2;
        if(!$check){
            //提示当前客服不在线，可发送离线消息,用户前端用背景文字提示
            $online = 1;
        }

        //查询聊天记录，没有则发送默认系统消息
        $messageModel = Messages::create();
        $list = $messageModel->all([
            'platform' => 'micao',
            'user_id' => $userInfo['user_id'],
        ]);
        array_unshift($list,[
            'platform' => 'micao',
            'user_id'  => $userInfo['user_id'],
            'username'  => $userInfo['username'],
            'type'  => Messages::TYPE_2,
            'is_read'  => Messages::IS_READ_2,
            'custom_id'  => 1,
            'custom_name'  => '阿蓝',
            'content'  => '请不要聊无关话题，有事请直接说事情，拒绝闲谈',
            'created_at'  => Carbon::now(),
        ]);
        $message = [
            'type' => 'login',
            'data' => ['list' => $list, 'online' => $online, 'fd' => $fd, 'user' => $userInfo],
        ];
        $this->send($fd, $message);
    }


    function message()
    {
        $params = $this->caller()->getArgs();
        $fd = $this->caller()->getClient()->getFd();

        //获取当前登录用户信息
        $cache = Redis::defer('redis');
        $userInfo = $cache->get('user:'.$params['uid']);
        //初始化消息内容
        $data = [
            'platform' => 'micao',
            'user_id'  => $userInfo['user_id'],
            'username'  => $userInfo['username'],
            'type'  => Messages::TYPE_1,
            'is_read'  => Messages::IS_READ_1,
            'custom_id'  => 1,
            'custom_name'  => '阿蓝',
            'content'  => $params['content'],
            'created_at'  => Carbon::now(),
        ];

        //获取当前客服信息
        $customModel = Admins::create();
        $customInfo = $customModel->get(1);

        //保存数据库
        $messageModel = Messages::create();
        $messageModel->data($data,false)->save();

        //判断当前客服是否在线
        $check = $this->check($customInfo['id'], $customInfo['socket_id']);
        $data['created_at'] = $data['created_at']->format('Y-m-d H:i:s');
        if($check){
            $data['is_read'] = Messages::IS_READ_2;
            $c_message = [
                'type' => 'replay',
                'data' => [
                    'chat' => $data,
                    'user_info' => $userInfo
                ],
            ];
            //如果客服连接存在，直接发送客服
            $this->send($customInfo['socket_id'], $c_message);
        }
        //自己消息回调
        $message = [
            'type' => 'chat',
            'data' => $data,
        ];
        $this->send($fd, $message);
    }

    /**
     * @param $fd 连接号
     * @param $message 发送消息
     */
    protected function send($fd,$message){
        $server = ServerManager::getInstance()->getSwooleServer();
        $server->push($fd, json_encode($message));
    }

    public function who(){
        $this->response()->setMessage('your fd is '. $this->caller()->getClient()->getFd());
    }

    function delay()
    {
        $this->response()->setMessage('this is delay action');
        $client = $this->caller()->getClient();

        // 异步推送, 这里直接 use fd也是可以的
        TaskManager::getInstance()->async(function () use ($client){
            $server = ServerManager::getInstance()->getSwooleServer();
            $i = 0;
            while ($i < 5) {
                sleep(1);
                $server->push($client->getFd(),'push in http at '. date('H:i:s'));
                $i++;
            }
        });
    }
}