<?php

namespace App\WebSocket;

use App\Model\Admins;
use App\Model\Customs;
use App\Model\CustomsModel;
use App\Model\Messages;
use App\Model\MessagesModel;
use App\Model\UsersModel;
use App\Utility\JwtToken;
use Carbon\Carbon;
use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\EasySwoole\Task\TaskManager;
use EasySwoole\FastCache\Cache;
use EasySwoole\HttpClient\HttpClient;
use EasySwoole\RedisPool\RedisPool as Redis;
use EasySwoole\Socket\AbstractInterface\Controller;
use EasySwoole\Spl\SplString;

/**
 * Class Index
 *
 * 此类是默认的 websocket 消息解析后访问的 控制器
 *
 * @package App\WebSocket
 */
class Service extends Controller
{

    /**
     * 检查当前连接是否有效
     * @param int $id 用户ID
     * @param int $fd 连接ID
     * @return bool
     */
    function check($id = 0, $fd = 0, $type='user'){
        if(!$id || !$fd) return false;
        //获取缓存
        $cache = Redis::defer('redis');
        $user = $cache->get($type.':'.$id);
        //不存在或者用户身份不一样肯定不在线
        if(!$user) return false;
        //存在不一定在线
        $server = ServerManager::getInstance()->getSwooleServer();
        $customClientInfo = $server->getClientInfo($fd);
        if($customClientInfo && $customClientInfo['websocket_status'] === WEBSOCKET_STATUS_FRAME){
            return true;
        }
        return false;
    }

    function login()
    {
        //获取用户登录参数
        $params = $this->caller()->getArgs();
        $userList = $params['userList'];
        //获取客服连接ID
        $fd = $this->caller()->getClient()->getFd();

        $customInfo = [
            'id' => 1,
            'username' => '阿蓝',
            'socket_id' => $fd,
        ];
        //存入缓存
        $cache = Redis::defer('redis');
        $cache->set('custom:1',$customInfo,86400);
        //更新客服信息
        $model = Admins::create();
        $admin = $model->get(1);
        if($this->check($admin['id'], $admin['socket_id'], 'custom')){
            //有客服在线，通知下线
            //客服消息回调
            $message = [
                'type' => 'closeline',
                'data' => 2,
            ];
            $this->send($admin['socket_id'], $message);
        }
        $admin->update([
            'online' => 2,
            'socket_id' => $fd,
        ]);

        if(count($userList)){
            //更新用户界面的客服状态
            $userModel = Customs::create();
            foreach ($userList as $user){
                //实时读取用户信息
                $userInfo = $userModel->get($user['id']);
                if($this->check($user['user_id'], $userInfo['socket_id'])){
                    //客服消息回调
                    $message = [
                        'type' => 'online',
                        'data' => 2,
                    ];
                    $this->send($userInfo['socket_id'], $message);
                }
            }
        }
    }


    function message()
    {
        $params = $this->caller()->getArgs();
        //当前客服的连接ID
        $fd = $this->caller()->getClient()->getFd();
        $user = $params['user'];
        $platform = 'micao';
        //实时读取用户信息
        $userModel = Customs::create();
        $userInfo = $userModel->get([
            'platform' => $platform,
            'user_id' => $user['user_id'],
        ]);

        //组装初始消息
        $data = [
            'platform' => $userInfo['platform'],
            'user_id'  => $userInfo['user_id'],
            'username'  => $userInfo['username'],
            'type'  => Messages::TYPE_2,
            'is_read'  => Messages::IS_READ_2,
            'custom_id'  => 1,
            'custom_name'  => '阿蓝',
            'content'  => $params['content'],
            'created_at'  => Carbon::now(),
        ];

        //保存数据库
        $messageModel = Messages::create();
        $messageModel->data($data,false)->save();


        //判断当前用户是否在线
        $check = $this->check($userInfo['user_id'], $userInfo['socket_id']);
        $data['created_at'] = $data['created_at']->format('Y-m-d H:i:s');
        if($check){
            $u_message = [
                'type' => 'replay',
                'data' => $data,
            ];
            //如果用户连接存在，直接发送
            $this->send($userInfo['socket_id'], $u_message);
        }

        //客服消息回调
        $message = [
            'type' => 'chat',
            'data' => $data,
        ];
        $this->send($fd, $message);
    }


    public function offline(){
        $params = $this->caller()->getArgs();
        $userList = $params['userList'];

        //清除缓存
        $cache = Redis::defer('redis');
        $cache->del('custom:1');

        $userModel = Customs::create();
        foreach ($userList as $user){
            //实时读取用户信息
            $userInfo = $userModel->get($user['id']);
            if($this->check($user['user_id'], $userInfo['socket_id'])){
                //客服消息回调
                $message = [
                    'type' => 'offline',
                    'data' => 1,
                ];
                $this->send($userInfo['socket_id'], $message);
            }
        }
    }

    //获取用户聊天数据
    public function chatlog(){
        $params = $this->caller()->getArgs();
        $fd = $this->caller()->getClient()->getFd();
        //聊天记录
        $chatlog = $this->getChatLog($params['user_id']);
        $message = [
            'type' => 'chatlog',
            'data' => ['chat' => $chatlog],
        ];
        $this->send($fd, $message);
    }

    function getChatLog($user_id = 0){
        $platform = 'micao';
        if(empty($user_id)){
            return [];
        }
        //聊天记录
        $messageModel = Messages::create();
        $chatlog = $messageModel->where('platform',$platform)
            ->where('user_id',$user_id)//用户ID
            ->all();

        //绑定未读消息给当前客服,更新记录为已读状态
        $messageModel->update(['is_read' => Messages::IS_READ_2],
            ['platform' => $platform, 'user_id'=>$user_id, 'is_read' => Messages::IS_READ_1]);

        return $chatlog;
    }

    function getOrderLog3($uid){
        $request = new HttpClient('http://face.888-521-888.com/select/chat?uid='.$uid);
        $response = $request->get();
        $string = new SplString($response->getBody());
        $result = json_decode($string, true);
        $user = [
            'id' => $result['data']['user']['uid'],
            'username' => $result['data']['user']['nickname'],
            'mobile' => $result['data']['user']['mobile'],
            'name' => $result['data']['user']['source'],
            'model' => $result['data']['user']['model'],
            'vip' => $result['data']['user']['level'],
            'ip' => $result['data']['user']['regip'],
            'created_at' => $result['data']['user']['regtime'],
            'balance' => $result['data']['user']['balance'],
        ];
        $order = [];
        if(count($result['data']['order'])){
            foreach ($result['data']['order'] as $k => $o){
                $order[$k]['order_id'] = $o['order_sn'];
                $order[$k]['money'] = $o['amount'];
                $order[$k]['status_text'] = '<span>'.$o['status'].'</span>';
                $order[$k]['created_at'] = $o['created'];
            }
        }

        return ['data' => ['user' => $user, 'order' => $order]];
    }

    function getOrderLog2($uid){
        $request = new HttpClient('https://www.jiekou416.com/api/user_order?uid='.$uid);
        $response = $request->get();
        $string = new SplString($response->getBody());
        $result = json_decode($string, true);
        return $result;
    }


    function getOrderLog($uid){
        $request = new HttpClient('http://app.hzyktl.cn/user_order?uid='.$uid);
        $response = $request->get();
        $string = new SplString($response->getBody());
        $result = json_decode($string, true);
        return $result;
    }

    /**
     * @param $fd 连接号
     * @param $message 发送消息
     */
    protected function send($fd,$message){
        $server = ServerManager::getInstance()->getSwooleServer();
        $server->push($fd, json_encode($message));
    }
}