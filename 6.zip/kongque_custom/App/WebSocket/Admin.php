<?php

namespace App\WebSocket;

use App\Model\Admins;
use App\Model\Configs;
use App\Model\Customs;
use App\Model\CustomsModel;
use App\Model\Messages;
use App\Model\MessagesModel;
use App\Model\Users;
use App\Model\UsersModel;
use App\Utility\JwtToken;
use Carbon\Carbon;
use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\EasySwoole\Task\TaskManager;
use EasySwoole\RedisPool\RedisPool as Redis;
use EasySwoole\Socket\AbstractInterface\Controller;
use EasySwoole\FastCache\Cache;


/**
 * Class Index
 *
 * 此类是默认的 websocket 消息解析后访问的 控制器
 *
 * @package App\WebSocket
 */
class Admin extends Controller
{

    function online()
    {
        //获取用户连接ID
        $fd = $this->caller()->getClient()->getFd();

        //更新缓存数据
        $cache = Redis::defer('redis');
        $fd = $cache->get('socket:online_sid');
        if(!$fd){
            $fd = $cache->set('socket:online_sid',$fd);
        }
        $setting = $cache->get('setting');
        if (!$setting) {
            $setting = Configs::create()->getList();
            $cache->set('setting', $setting);
        }
        $time = time() + 100;
        $min = $time - (int)($setting['online_time']*60);
        $nums = $cache->zCount('online',$min,(int)$time);
        $message = [
            'type' => 'user_online',
            'data' => $nums,
        ];
        $this->send($fd, $message);
    }



    /**
     * @param $fd 连接号
     * @param $message 发送消息
     */
    protected function send($fd,$message){
        $server = ServerManager::getInstance()->getSwooleServer();
        $server->push($fd, json_encode($message));
    }

    public function who(){
        $this->response()->setMessage('your fd is '. $this->caller()->getClient()->getFd());
    }

    function delay()
    {
        $this->response()->setMessage('this is delay action');
        $client = $this->caller()->getClient();

        // 异步推送, 这里直接 use fd也是可以的
        TaskManager::getInstance()->async(function () use ($client){
            $server = ServerManager::getInstance()->getSwooleServer();
            $i = 0;
            while ($i < 5) {
                sleep(1);
                $server->push($client->getFd(),'push in http at '. date('H:i:s'));
                $i++;
            }
        });
    }
}