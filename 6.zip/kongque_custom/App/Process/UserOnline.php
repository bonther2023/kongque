<?php

namespace App\Process;

use ank\IpLookup;
use App\Model\Configs;
use App\Model\Users;
use Carbon\Carbon;
use EasySwoole\Component\Process\AbstractProcess;
use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\RedisPool\RedisPool as Redis;

class UserOnline extends AbstractProcess{
    private $isRun = false;
    public function run($arg){
        //每10秒执行一次清理
        $this->addTick(10000,function (){
            if(!$this->isRun){
                $this->isRun = true;
                go(function (){
                    try{
                        $redis = Redis::defer('redis');
                        $setting = $redis->get('setting');
                        if (!$setting) {
                            $setting = Configs::create()->getList();
                            $redis->set('setting', $setting);
                        }
                        $time = time();
                        $min = $time - (int)($setting['online_time']*60);
                        $redis->zRemRangeByScore('online',0,(int)$min);
                        $nums = $redis->zCount('online',$min,(int)$time + 100);
                        $fd = $redis->get('socket:online_sid');
                        // 通过Swoole实例拿连接信息
                        $server = ServerManager::getInstance()->getSwooleServer();
                        $info = $server->connection_info($fd);
                        if($info && is_array($info)){
                            $message = [
                                'type' => 'user_online',
                                'data' => $nums,
                            ];
                            $server->push($fd, json($message));
                        }
                    }catch (\Exception $e){
                        write_log('user-online:' . $e->getMessage());
                    }
                    $this->isRun = false;
                });
            }
        });
    }

    public function onShutDown()
    {
        // TODO: Implement onShutDown() method.
    }

    public function onReceive(string $str, ...$args)
    {
        // TODO: Implement onReceive() method.
    }
}
