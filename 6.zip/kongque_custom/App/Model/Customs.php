<?php

namespace App\Model;


use EasySwoole\ORM\AbstractModel;

class Customs extends AbstractModel
{
    protected $tableName = 'customs';


}
