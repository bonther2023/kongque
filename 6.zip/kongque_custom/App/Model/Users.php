<?php

namespace App\Model;

use EasySwoole\ORM\AbstractModel;

class Users extends AbstractModel
{
    protected $tableName = 'users';


}
