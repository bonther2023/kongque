<?php

namespace App\Model;

use EasySwoole\ORM\AbstractModel;

class Admins extends AbstractModel
{
    protected $tableName = 'admins';//数据表名称

}