<?php

namespace App\HttpController;

use duncan3dc\Laravel\BladeInstance;

class ViewController extends BaseController{

    protected $view;

    /**
     * 初始化模板引擎
     * ViewController constructor.
     */
    public function __construct()
    {
        $tempPath   = config('TEMP_DIR');    # 临时文件目录
        $this->view = new BladeInstance(EASYSWOOLE_ROOT . '/View', "{$tempPath}/views");
        parent::__construct();
    }


    /**
     * 输出模板到页面
     * @param string $view
     * @param array  $params
     */
    public function render(string $view, array $params = [])
    {
        $content = $this->view->render($view, $params);
        $this->response()->write($content);
    }


}
