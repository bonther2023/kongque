<?php

namespace App\HttpController\Service;

use App\HttpController\ViewController;
use App\Model\CustomsModel;
use App\Model\MessagesModel;
use App\Model\UsersModel;
use App\Utility\JwtToken;
use EasySwoole\HttpClient\HttpClient;
use EasySwoole\Spl\SplString;

class IndexController extends ViewController{

    const WORDS = [
        '发送下载地址',
        '客服时间。早上8点——凌晨3点',
        '长按复制分享地址：http://www.tv939.com',
        '请不要发\"你好\",\"在吗\"等词语，有事请说话',
        '请及时绑定手机',
        '如遇偶尔视频加载失败，可能是CDN个别时候延迟所致，请重启APP或者观看其他视频',
        'VIP没及时到账，可能受支付或者网络延迟的影响，请稍等几分钟或者重启APP',
    ];


    public function index()
    {
        //判断登录
        $request = $this->request();
        $token = $request->getCookieParams('token');
        if(!$token){
            return $this->response()->redirect(url_service('login'));
        }
        $jwtToken = new JwtToken();
        $uid = $jwtToken->check($token);
        if(!$uid) {
            $this->response()->setCookie('token', $token, expires(0));
            return $this->response()->redirect(url_service('login'));
        }

        //登录用户信息
        $customModel = new CustomsModel();
        $user = $customModel->get($uid);
        unset($user['password']);
        //更新所有离线消息的客服为当前客服ID
        $userModel = new UsersModel();
        $userModel->update([
            'custom_id' => $user['id'],
            'platform' => $user['platform'],
        ], ['custom_id' => 0]);

        //读取所有custom_id为当前客服ID的用户
        $userList = $userModel->where('platform', $user['platform'])
            ->where('custom_id',$user['id'])//客服ID
            ->order('created_at', 'DESC')
            ->findAll();

        //查询每个用户的未读消息数量
        $messageModel = new MessagesModel();
        foreach ($userList as $index=>&$item){
            //查看是否有消息记录
            $num = $messageModel->where('platform',$user['platform'])
                ->where('user_id',$item['user_id'])//用户ID
                ->count();
            if($num){
                $unread = $messageModel->where('platform',$user['platform'])
                    ->where('user_id',$item['user_id'])//用户ID
                    ->where('is_read',MessagesModel::IS_READ_1)
                    ->where('type',MessagesModel::TYPE_1)
                    ->count();
                $item['unread'] = $unread;
            }else{
                unset($userList[$index]);
            }
        }
        $userList = json(array_values($userList));
        $user = json($user);

        $words = json(self::WORDS);
        $ws = trim(config('SOCKET_SERVER_URL'), '/');
        return $this->render('service.index',compact('user','userList','words','ws'));
    }

    //获取用户聊天数据
    public function chat(){

        $request = $this->request();
        $platform = (string)trim($request->getRequestParam('platform')) ?: '';
        $user_id = (int)trim($request->getRequestParam('uid')) ?: 0;
        if(empty($platform) || empty($user_id)){
            return $this->writeJson(1);
        }

        //聊天记录
        $messageModel = new MessagesModel();
        $chatlog = $messageModel->where('platform',$platform)
            ->where('user_id',$user_id)//用户ID
            ->findAll();

        //绑定未读消息给当前客服,更新记录为已读状态
        $messageModel->update([ 'is_read' => MessagesModel::IS_READ_2, ],
            ['platform' => $platform, 'user_id'=>$user_id,'is_read' => MessagesModel::IS_READ_1]);
        return $this->writeJson(0,$chatlog);
    }


    public function ip(){
        $request = $this->request();
        $ip = (string)trim($request->getRequestParam('ip')) ?: '';
        if(!$ip || $ip == '127.0.0.1'){
            $this->writeJson(1);
        }
        $request = new HttpClient('http://ip-api.com/json/'.$ip.'?lang=zh-CN');
        $response = $request->get();
        $string = new SplString($response->getBody());
        $result = json_decode($string, true);
        return $this->writeJson(0,$result);
    }


}