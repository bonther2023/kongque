<?php

namespace App\HttpController\Service;

use App\HttpController\ViewController;
use App\Model\CustomsModel;
use App\Model\MessagesModel;
use App\Model\UsersModel;
use Carbon\Carbon;
use EasySwoole\FastCache\Cache;
use EasySwoole\RedisPool\Redis;
use EasySwoole\Utility\Hash;
use EasySwoole\Validate\Validate;
use App\Utility\JwtToken;

class LoginController extends ViewController{


    public function index(){
        if($this->ajax()){
            $request = $this->request();
            $data = $request->getRequestParam();
            $validate = new Validate();
            $model = new CustomsModel();
            $user = $model->get(['username' => $data['username']]);
            $validate->addColumn('username')->required('请填写账号')->func(function () use ($data, $user) {
                return !empty($user);
            }, '账户信息不存在');
            //$2y$10$ZDLDHT7.p5o9bBNkBxfQauvXszssmCQCCWodAdDUKVC2sjywB6d8i    abcd1234
//            $data['password'] = Hash::makePasswordHash($data['password']);//  kefu_001
//            return $this->writeJson(1, $data);
            $validate->addColumn('password')->required('请填写密码')->func(function () use ($data, $user) {
                return Hash::validatePasswordHash($data['password'], $user['password']);
            }, '密码输入错误');
            if ($this->validate($validate)) {
                $jwtToken = new JwtToken();
                $token = $jwtToken->token($user['id']);
                $this->response()->setCookie('token', $token, expires(86400 * 7));
                return $this->writeJson(0);
            } else {
                return $this->writeJson(1, null, $validate->getError()->__toString());
            }
        }else{
            $request = $this->request();
            $token = $request->getCookieParams('token');
            if ($token) {
                $this->response()->redirect(url_service());
                return false;
            }
            return $this->render('service.login');
        }
    }

    public function logout(){
        $request = $this->request();
        $token = $request->getCookieParams('token');
        $jwtToken = new JwtToken();
        $uid = $jwtToken->check($token);
        $model = new CustomsModel();
        $user = $model->get($uid);
        $user->update([
            'socket_id' => 0,
            'online' => CustomsModel::ONLINE_1,
        ]);
        $this->response()->setCookie('token', $token, expires(0));
        return $this->writeJson(0,$uid);
    }



}