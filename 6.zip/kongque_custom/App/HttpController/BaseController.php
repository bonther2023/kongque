<?php

namespace App\HttpController;

use EasySwoole\EasySwoole\ServerManager;
use EasySwoole\Http\AbstractInterface\Controller;

abstract class BaseController extends Controller
{

    /**
     * 不要打开不网站欸
     */
    public function index()
    {
        $this->actionNotFound('index');
    }

    /**
     * 重置writeJson 方法
     * @param int $statusCode 0成功 1失败
     * @param null $result 结果
     * @param null $msg 消息提示
     * @return bool
     */
    protected function writeJson($statusCode = 0, $result = null, $msg = null)
    {
        if (!$this->response()->isEndResponse()) {
            $data = [
                "code" => $statusCode,
                "data" => $result,
                "msg" => $msg ?? 'SUCCESS'
            ];
            $this->response()->write(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            $this->response()->withHeader('Content-type', 'application/json;charset=utf-8');
            $this->response()->withStatus(200);
            return true;
        } else {
            return false;
        }
    }

    protected function writeHtml($msg)
    {
        if (!$this->response()->isEndResponse()) {
            $this->response()->write($msg);
            $this->response()->withStatus(200);
            return true;
        } else {
            return false;
        }
    }

    /**
     * 获取IP
     * @return string
     */
    protected function getIp()
    {
        $ip = $this->request()->getHeaders();
        return $ip['x-real-ip'][0] ?: '127.0.0.1';
//        $ip = ServerManager::getInstance()->getSwooleServer()->connection_info($this->request()->getSwooleRequest()->fd);
//        return $ip['remote_ip'] ?: '127.0.0.1';
    }

    /**
     * 判断请求是否事ajax请求
     * @return bool
     */
    protected function ajax()
    {
        $requested = $this->request()->getHeader('x-requested-with');
        if (head($requested) == 'XMLHttpRequest') {
            return true;
        }
        return false;
    }

}
