<?php

namespace App\HttpController\Home;

use App\HttpController\ViewController;
use App\Model\Customs;
use App\Model\Users;
use Carbon\Carbon;

class IndexController extends ViewController {


    public function index()
    {
        return ;
    }
    //https://kf.kohring.co/custom?uid=3&username=用户_63uzblo0nk&platform=micao
    public function custom()
    {
        $request = $this->request();
        $user_id = (int)trim($request->getRequestParam('uid')) ?: 0;
        $username = (string)trim($request->getRequestParam('username')) ?: '';
        $platform = (string)trim($request->getRequestParam('platform')) ?: 'micao';
        if(empty($user_id) || empty($username) || empty($platform) || $platform != 'micao') return ;

        $cModel = Customs::create();
        $userInfo = $cModel->where('user_id',$user_id)->get();
        if(empty($userInfo)){
            //保存用户信息到数据库
            $userModel = Users::create();
            $user = $userModel->field('id,username,mobile,ip,ip_address,vip,vip_at,app_system,app_model,app_network,app_vendor,app_release,created_at')->get($user_id);
            if(!$user) return ;
            $userInfo = [
                'platform' => $platform,
                'username' => $user['username'],
                'user_id' => $user['id'],
                'mobile' => $user['mobile'],
                'ip' => $user['ip'],
                'ip_address' => $user['ip_address'],
                'vip' => $user['vip'],
                'vip_at' => date('Y-m-d H:i:s',$user['vip_at']),
                'app_system' => $user['app_system'],
                'app_model' => $user['app_model'],
                'app_network' => $user['app_network'],
                'app_vendor' => $user['app_vendor'],
                'app_release' => $user['app_release'],
                'reg_at' => $user['created_at'],
                'created_at' => Carbon::now(),
            ];
            $cModel->data($userInfo,false)->save();
        }else{
            $userModel = Users::create();
            $user = $userModel->field('id,username,mobile,ip,ip_address,vip,vip_at,app_system,app_model,app_network,app_vendor,app_release,created_at')->get($user_id);
            if(!$user) return ;
            $update = [
                'platform' => $platform,
                'username' => $user['username'],
                'user_id' => $user['id'],
                'mobile' => $user['mobile'],
                'ip' => $user['ip'],
                'ip_address' => $user['ip_address'],
                'vip' => $user['vip'],
                'vip_at' => date('Y-m-d H:i:s',$user['vip_at']),
                'app_system' => $user['app_system'],
                'app_model' => $user['app_model'],
                'app_network' => $user['app_network'],
                'app_vendor' => $user['app_vendor'],
                'app_release' => $user['app_release'],
                'reg_at' => $user['created_at'],
                'created_at' => Carbon::now(),
            ];
            $userInfo->update($update);
        }
        $userInfo = json($userInfo);
        $ws = 'wss://kf.kohring.co/ws';
        return $this->render('home.custom',compact('userInfo','ws'));
    }


    public function connect(){
        $platform = 'micao';
        $request = $this->request();
        $user_id = (int)trim($request->getRequestParam('uid')) ?: 0;
        $cModel = Customs::create();
        $userInfo = $cModel->where('user_id', $user_id)->where('platform',$platform)->get();
        $userInfo = json($userInfo);
        return $this->writeJson(0,$userInfo);
    }


}