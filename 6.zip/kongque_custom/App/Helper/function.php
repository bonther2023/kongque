<?php

use App\Model\Configs;
use EasySwoole\EasySwoole\Config;
use EasySwoole\EasySwoole\Logger;
use EasySwoole\FastCache\Cache;
use EasySwoole\RedisPool\RedisPool as Redis;

/**
 * 返回 dev.php 文件配置
 * @param string $name 配置名称
 * @param string $default 默认值
 * @return array|mixed|null
 */
function config($name = '', $default = '')
{
    return Config::getInstance()->getConf($name) ?: $default;
}

/**
 * 日志
 * @param $data
 * @param int $level
 */
function write_log($data,$level = 1)
{
    if (is_object($data) || is_array($data)) {
        $data = json_encode($data);
    }
    switch ($level){
        case 2:
            Logger::getInstance()->notice($data);
            break;
        case 3:
            Logger::getInstance()->waring($data);
            break;
        case 4:
            Logger::getInstance()->error($data);
            break;
        default:
            Logger::getInstance()->info($data);
            break;
    }
}


/**
 * 设置过期时间
 * @param int $time 有效期，单位秒
 * @return int
 */
function expires($time = 0)
{
    return time() + (int)$time;
}

/**
 * json格式化
 * @param $data
 * @return false|string
 */
function json($data)
{
    return json_encode($data);
}


function url_service($path = '')
{
    return trim(trim(config('SERVER_URL'), '/') . '/service/' . trim($path, '/'), '/');
}

function url_custom($path = '')
{
    return trim(trim(config('SERVER_URL'), '/') . '/custom/' . trim($path, '/'), '/');
}

function url_api($path = '')
{
    return trim(trim(config('SERVER_URL'), '/') . '/api/' . trim($path, '/'), '/');
}

function asset($name = '')
{
    return trim(config('SERVER_URL'), '/') . '/' . $name;
}

/**
 * 获取配置
 * @return mixed|null
 * @throws Exception
 */
function settings()
{
    $redis = Redis::defer('redis');
    $value = $redis->get('setting');
    if (!$value) {
        $setting = Configs::create()->getList();
        $redis->set('setting', $setting);
    }
    return $value;
}