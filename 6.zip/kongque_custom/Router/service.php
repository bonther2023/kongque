<?php

use \App\HttpController\Router;

Router::group(['namespace' => 'Service', 'prefix' => 'service'], function () {
    Router::any('login', 'LoginController/index');
    Router::post('logout', 'LoginController/logout');

    Router::get('', 'IndexController/index');

    Router::get('chat', 'IndexController/chat');

    Router::get('ip', 'IndexController/ip');













});