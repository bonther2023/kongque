<?php

use \App\HttpController\Router;

Router::group(['namespace' => 'Api', 'prefix' => 'api'], function () {

    Router::group(['prefix' => 'upload'], function () {
        Router::post('image', 'UploadController/image');//上传图片
        Router::post('img', 'UploadController/img');//上传图片
        Router::post('file', 'UploadController/file');//上传文件
    });
});