<?php

use \App\HttpController\Router;

Router::group(['namespace' => 'Home'], function () {

    Router::get('', 'IndexController/index');
    Router::get('custom', 'IndexController/custom');
    Router::get('custom/chat', 'IndexController/chat');





    Router::post('connect', 'IndexController/connect');








});