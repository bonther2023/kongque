// vue.config.js
module.exports = {
    devServer: {
        proxy: {
            '/canal': {
                target: 'https://rnmkq.koging.com/',//http://www.aftersale.bh
                changeOrigin: true,
                ws: true,
                pathRewrite: {
                    // '^/api': ''
                }
            },
        }
    }
}
