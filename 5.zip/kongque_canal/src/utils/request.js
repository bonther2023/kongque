import Vue from 'vue'
import axios from 'axios';
import VueAxios from 'vue-axios';
import Qs from 'qs';
import cookie from 'vue-cookie';


Vue.use(VueAxios, axios);


// 添加请求拦截器
axios.interceptors.request.use(function (config) {
    config.headers['Accept'] = 'application/json';
    //配置header的token信息
    // const ua = window.navigator.userAgent.toLowerCase();
    const token = cookie.get('token');
    if(token){
        config.headers['Authorization'] = 'Bearer ' + token;
    }
    return config;
}, function (error) {
    return Promise.reject(error);
});

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
    // 对响应数据做点什么
    return response.data;
}, function (error) {
    // 对响应错误做点什么
    return Promise.reject(error);
});


// 定义基础路由
let base = '/canal';

export const Captcha = params => { return axios.get(`${base}/captcha`, {params:params}).then(res => res)};
export const UserLogin = params => { return axios.post(`${base}/login`, Qs.stringify(params)).then(res => res)};
export const UserInfo = params => { return axios.get(`${base}/detail`, {params:params}).then(res => res)};
export const Configs = params => { return axios.get(`${base}/config`, {params:params}).then(res => res)};
export const UserUpdate = params => { return axios.post(`${base}/update`, Qs.stringify(params)).then(res => res)};
export const Password = params => { return axios.post(`${base}/password`, Qs.stringify(params)).then(res => res)};
export const Flow = params => { return axios.get(`${base}/flow`, {params:params}).then(res => res)};
export const Trade = params => { return axios.get(`${base}/trade`, {params:params}).then(res => res)};
export const Sort = params => { return axios.get(`${base}/sort`, {params:params}).then(res => res)};
export const Link = params => { return axios.get(`${base}/link`, {params:params}).then(res => res)};
export const UserReport = params => { return axios.get(`${base}/report`, {params:params}).then(res => res)};
export const UserAuthorize = params => { return axios.post(`${base}/authorize`, Qs.stringify(params)).then(res => res)};
