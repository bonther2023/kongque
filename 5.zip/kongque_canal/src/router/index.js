import Vue from 'vue';
import Router from 'vue-router';

// 按需（懒）加载（vue实现）      @ is an alias to /src
const Layout = () => import('@/views/layouts/layout.vue');// 布局组件
const Authorize = () => import('@/views/auth/authorize.vue');// 授权登录
const Login = () => import('@/views/auth/login.vue');// 登录
const Main = () => import('@/views/index/main.vue');// 我的首页
const Flow = () => import('@/views/index/flow.vue');// 效果报表
const Info = () => import('@/views/index/info.vue');// 基本设置
const Trade = () => import('@/views/index/trade.vue');// 结算信息
const Password = () => import('@/views/index/password.vue');// 修改密码
const Error = () => import('@/views/page/404.vue');//404

Vue.use(Router);

//设置不需要权限的公共页面
export const constantRouterMap = [
    {path: '', name: 'login', component: Login, meta: {title: '登录'}},
    {path: '/authorize', name: 'authorize', component: Authorize, meta: {title: '授权登录'}},
    {
        path: '/', component: Layout,
        children: [
            {path: '/', name: 'main',  component: Main,  meta: {title: '我的主页'}},
            {path: '/flow', name: 'flow',  component: Flow,  meta: {title: '我的报表'}},
            {path: '/info', name: 'info',  component: Info,  meta: {title: '我的资料'}},
            {path: '/trade',name: 'trade', component: Trade, meta: {title: '我的结算'}},
            {path: '/password',name: 'password', component: Password, meta: {title: '修改密码'}},
            {path: '/404',  name: 'error', component: Error, meta: {title: '404'}},
        ],
    },
    {
        path: '*',
        redirect: '/404'
    }
];

//实例化vue的时候只挂载constantRouter
export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: constantRouterMap
});

