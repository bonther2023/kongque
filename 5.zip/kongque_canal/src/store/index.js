import Vue from 'vue';
import Vuex from 'vuex';
import Cookie from 'vue-cookie';
import {asyncRouterMap} from '@/router';

Vue.use(Vuex);

export default new Vuex.Store({
    state: {
        active: '',//菜单选中,主要针对F5刷新后菜单的默认选中
        username: '',
        rebate: '',
        balance: '',
        routers: [],//权限筛选后的路由
    },
    getters: {
        active: (state) => {
            return state.active;
        },
        username: (state) => {
            return state.username;
        },
        rebate: (state) => {
            return state.rebate;
        },
        balance: (state) => {
            return state.balance;
        },
        routers: (state) => {
            return state.routers;
        },
    },
    mutations: {
        SET_ACTIVE(state, param) {
            state.active = param;
        },
        SET_USERNAME(state, param) {
            state.username = param;
        },
        SET_REBATE(state, param) {
            state.rebate = param;
        },
        SET_BALANCE(state, param) {
            state.balance = param;
        },
        SET_ROUTERS(state,param){
            state.routers = param;
        },
        USER_LOGIN(state, param) {
            Cookie.set('token', param.token, { expires: '7d' });
            Cookie.set('username', param.username, { expires: '7d' });
        },
        USER_LOGOUT() {
            Cookie.delete('token');
            Cookie.delete('username');
        },
    },
    actions: {
        //设置菜单选中
        setActive({commit}, param) {
            commit('SET_ACTIVE', param);
        },
        //设置用户名
        setUsername({commit}, param) {
            commit('SET_USERNAME', param);
        },
        //设置分成
        setRebate({commit}, param) {
            commit('SET_REBATE', param);
        },
        //设置余额
        setBalance({commit}, param) {
            commit('SET_BALANCE', param);
        },
        //登陆
        userLogin({commit}, param) {
            return new Promise((resolve) => {
                commit('USER_LOGIN', param);
                resolve();
            });
        },
        //退出登录
        userLogout({commit}){
            return new Promise((resolve) => {
                commit('USER_LOGOUT');
                resolve();
            });
        },
        generateRoutes({commit}){
            //全部执行完再返回
            return new Promise(resolve => {
                const accessedRouters = asyncRouterMap.filter(v => {
                    return true;
                });
                commit('SET_ROUTERS', accessedRouters);
                resolve();
            });
        },
    },
    modules: {}
})
