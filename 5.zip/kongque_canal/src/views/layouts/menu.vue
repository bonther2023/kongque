<template>
    <div class="menu">
        <el-menu
            :default-active="active"
            background-color="#2a3542"
            text-color="#FFF"
            :router="true"
            :unique-opened="true"
            active-text-color="#FFF">
            <el-menu-item index="/">
                <i class="fa fa-sitemap" style="margin-right: 8px"></i>
                <span slot="title">我的主页</span>
            </el-menu-item>
            <el-menu-item index="/flow">
                <i class="fa fa-align-left" style="margin-right: 8px"></i>
                <span slot="title">我的报表</span>
            </el-menu-item>
            <el-menu-item index="/trade">
                <i class="fa fa-usd" style="margin-right: 8px"></i>
                <span slot="title">我的结算</span>
            </el-menu-item>
            <el-menu-item index="/info">
                <i class="fa fa-user" style="margin-right: 8px"></i>
                <span slot="title">我的资料</span>
            </el-menu-item>
            <el-menu-item index="/password">
                <i class="fa fa-unlock-alt" style="margin-right: 8px"></i>
                <span slot="title">修改密码</span>
            </el-menu-item>
        </el-menu>
    </div>

</template>

<script>
    import {mapGetters} from 'vuex';
    export default {
        computed: {
            ...mapGetters(['active','routers']),
        },
        created(){

        },
    }
</script>
<style scoped>
    .fa{
        /*padding-right: 8px;*/
    }
    .el-menu {
         border-right: solid 1px #FFF;box-shadow: 0 1px 1px rgba(0,0,0,.1)
    }
    .el-menu-item.is-active {
        background-color: #34404e !important;
    }
    .el-submenu__title i {
         color: #FFF !important;
    }
    .el-menu-item i {
        color: #FFF !important;
    }
</style>
