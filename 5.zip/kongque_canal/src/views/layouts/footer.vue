<template>
    <div class="footer">
        Copyright © Powered By Canal System 2022
    </div>
</template>
