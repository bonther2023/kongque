<template>
    <div class="panel-content">
        <div class="panel-body panel-list">
            <div class="panel-header">
                <div class="panel-title">
                    效果报表
                </div>
            </div>
            <div class="panel-main">
                <div class="panel-main-header">
                    <div class="panel-btns">
                        <el-button type="primary" icon="fa fa-undo" @click="list()" size="small"> 刷新</el-button>
                    </div>
                    <div class="panel-search">
                        <div class="panel-search-item" style="width: 250px">
                            <el-date-picker style="width: 250px"
                                            size="medium"
                                            v-model="date"
                                            type="daterange"
                                            @change="pickerChange"
                                            :picker-options="pickerOptions2"
                                            range-separator="-"
                                            start-placeholder="开始日期"
                                            end-placeholder="结束日期"
                                            align="right">
                            </el-date-picker>
                        </div>
                    </div>
                </div>
                <el-table v-loading="loading"
                          element-loading-text="数据加载中..."
                          element-loading-spinner="el-icon-loading"
                          tooltip-effect="dark"
                          :data="listData.data" border>
                    <el-table-column prop="date" label="日期" width="150"></el-table-column>
                    <el-table-column prop="s_install"  width="150" label="安装效果"></el-table-column>
                    <el-table-column prop="rebate"  width="150" label="订单佣金"></el-table-column>
                    <el-table-column prop="rebate" label="订单总价">
                        <template slot-scope="scope">
                            {{ (scope.row.rebate/(rebate/100)).toFixed(2) }}
                        </template>
                    </el-table-column>
                </el-table>
                <div class="pagination">
                    <el-pagination v-if="listData.last_page > 1"
                                   background
                                   :page-size="listData.per_page"
                                   layout="prev, pager, next, jumper"
                                   :total="listData.total"
                                   prev-text="<<"
                                   next-text=">>"
                                   :current-page="listData.current_page"
                                   @current-change="changePage">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {Flow,UserInfo} from '@/utils/request';
    export default {
        data() {
            return {
                listData: [],//列表数据
                params: {page: 1, start: '', end: ''},
                loading: false,
                date: '',
                rebate: 0,
                pickerOptions2: {
                    shortcuts: [{
                        text: '今天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '昨天',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            end.setTime(end.getTime() - 3600 * 1000 * 24 * 1);
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 1);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                }
            }
        },
        created(){

        },
        activated(){
            this.user();
            this.rebate = this.$storage.get('user_rebate');
            this.$store.dispatch('setActive', '/flow');
            this.$store.dispatch('setUsername', this.$cookie.get('username'));
            this.$store.dispatch('setRebate', this.$storage.get('user_rebate'));
            this.list();
        },
        methods: {
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
            //列表
            list(){
                this.loading = true;
                Flow({params:this.$crypto.encrypt(this.params)}).then((res) => {
                    if(res.code){
                        this.$notify.error({
                            title: '错误',
                            duration: '2000',
                            message: res.msg
                        });
                    }else{
                        let detail = this.$crypto.decrypt(res.data);
                        this.listData = detail;
                        this.loading = false;
                    }
                });
            },
            //时间筛选
            pickerChange() {
                if (this.date) {
                    this.params.start = this.$moment(this.date[0]).format('YYYY-MM-DD');
                    this.params.end = this.$moment(this.date[1]).format('YYYY-MM-DD');
                } else {
                    this.params.start = '';
                    this.params.end = '';
                }
                this.params.page = 1;
                this.list();
            },
            //分页
            changePage(val) {
                this.params.page = val;
                this.list();
            },
        }
    }
</script>

<style scoped>

</style>
