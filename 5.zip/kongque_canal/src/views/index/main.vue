<template>
    <div class="panel-content">
        <div class="panel-body panel-home">
            <div class="panel-header">
                <div class="panel-title">
                    重要提醒
                </div>
            </div>
            <el-alert :closable="false" class="notice">
                <template slot="title">
                    <p style="font-size: 16px;font-weight: 700;color: red">！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！</p>
                </template>
                <template>
                    <p style="color: red;font-size: 14px">1、为避免不生成结算数据，新账户首次登录请务必在 <em style="font-weight: 700;color:red">我的资料</em> 中添加银行卡信息</p>
                    <p style="color: red;font-size: 14px">2、渠道资金自动结算为 <em style="font-weight: 700;color:red">100</em>  元起结，每天晚上凌晨12点整自动生成结算数据</p>
                    <p style="color: red;font-size: 14px">3、由于行业特殊性，报红、报毒属正常现象，平台会定期更换推广链接、APK链接及APP包</p>
                    <p style="color: red;font-size: 14px">4、由于凌晨银行风控较严，为保障结算安全，结算佣金会在 8:00 - 15:00 下发至您的账户，请注意查收</p>
                    <p style="font-size: 16px;font-weight: 700;color: red">！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！</p>
                </template>
                <template>
                    <p style="color: #001aff;font-size: 14px">5、为了满足部分渠道落地页内容的需求，我们推出多推广页，内容可控，总有合适您的，如果你有更合适的页面，请联系管理员，我们可以为您定制化推广页</p>
                    <p style="font-size: 16px;font-weight: 700;color: red">！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！</p>
                </template>
            </el-alert>
            <div class="panel-header">
                <div class="panel-title">
                    我的推广
                </div>
            </div>
            <div class="panel-main" style="margin: 15px 0">
                <div class="box-message" v-if="apk && apk_name" style="display: flex">
                                        <span class="copy-span">APK 链接：</span>
                    <input class="input" readonly id="foo-apk" :value="apk + apk_name"/>
                    <button @click="copy('.btn-copy-apk')" class="btn-copy btn-copy-apk" data-clipboard-action="copy" data-clipboard-target="#foo-apk">复制APK 链接</button>
                </div>

                <div class="box-message" style="display: flex">
                    <span class="copy-span">推广链接1：</span>
                    <input v-if="!web_show" class="input" readonly value="系统已更换新的推广链接，点击生成按钮获取新链接"/>
                    <input v-if="web_show" class="input" readonly id="foo-tiao1" :value="web_link[0]"/>
                    <button v-if="web_show" @click="copy('.btn-copy-tiao')" class="btn-copy btn-copy-tiao" data-clipboard-action="copy" data-clipboard-target="#foo-tiao1">复制</button>
                </div>
                <div class="box-message" style="display: flex">
                    <span class="copy-span">推广链接2：</span>
                    <input v-if="!web_show" class="input" readonly value="系统已更换新的推广链接，点击生成按钮获取新链接"/>
                    <input v-if="web_show" class="input" readonly id="foo-tiao2" :value="web_link[1]"/>
                    <button v-if="web_show" @click="copy('.btn-copy-tiao')" class="btn-copy btn-copy-tiao" data-clipboard-action="copy" data-clipboard-target="#foo-tiao2">复制</button>
                </div>
                <div class="box-message" style="display: flex">
                    <span class="copy-span">推广链接3：</span>
                    <input v-if="!web_show" class="input" readonly value="系统已更换新的推广链接，点击生成按钮获取新链接"/>
                    <input v-if="web_show" class="input" readonly id="foo-tiao3" :value="web_link[2]"/>
                    <button v-if="web_show" @click="copy('.btn-copy-tiao')" class="btn-copy btn-copy-tiao" data-clipboard-action="copy" data-clipboard-target="#foo-tiao3">复制</button>
                </div>
                <div class="box-message" style="display: flex">
                    <el-button  @click="sortLink()" class="btn-copy" :loading="loading">生成推广链接</el-button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import {UserInfo,Configs,Sort,UserReport,Link} from '@/utils/request';
    import Clipboard from 'clipboard';
    export default {
        data() {
            return {
                userInfo: null,
                web: '',
                loading: false,
                web_cache: '',
                web_link: '',
                web_show: false,
                apk: '',
                apk_name: '',
                username: '',
                reportData: null
            }
        },
        created(){
            this.config();
        },
        activated(){
            let username = this.$cookie.get('username');
            this.$store.dispatch('setActive', '/');
            this.$store.dispatch('setUsername', username);
            this.user();
            // this.report();
            this.username = username;
            this.web_link = this.$storage.get('web_link_' + this.username)
        },
        methods: {
            report(){
                UserReport().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.reportData = detail;
                    }
                });
            },
            sortLink(){
                this.loading =  true;
                Link().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.$storage.set('web_link_' + this.username,detail);
                        this.web_link = detail;
                        this.web_show = true;
                        this.$storage.set('web_cache_' + this.username,this.web);
                        this.loading =  false;
                    }
                });
            },
            user(){
                UserInfo().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.userInfo = detail;
                        this.apk_name = detail.apk_name;
                        this.$storage.set('user_rebate', detail.canal_rebate);
                        this.$store.dispatch('setRebate', detail.canal_rebate);
                        this.$store.dispatch('setBalance', detail.balance);
                    }
                });
            },
            config(){
                Configs().then((res) => {
                    if(res.code == 0){
                        let detail = this.$crypto.decrypt(res.data);
                        this.web = detail.web;
                        this.apk = detail.apk;
                        this.web_cache = this.$storage.get('web_cache_' + this.username);
                        if(this.web_cache == this.web){
                            this.web_show = true;
                        }else{
                            // this.$confirm('系统已更换新的推广链接，点击生成按钮获取新链接', '提示', {
                            //     confirmButtonText: '生成',
                            //     confirmButtonClass: 'yingbtn',
                            //     cancelButtonText: '取消',
                            //     type: 'warning'
                            // }).then(() => {
                            //     this.sortLink();
                            // }).catch(() => {});
                        }
                    }
                });
            },
            copy(selectQuey){
                let clipboard = new Clipboard(selectQuey);
                clipboard.on('success', (e)=> {
                    this.$notify({
                        title: '成功',
                        duration: '2000',
                        message: '复制成功',
                        type: 'success',
                    });
                    clipboard.destroy();
                });
                clipboard.on('error', (e)=> {
                    this.$notify.error({
                        title: '错误',
                        duration: '2000',
                        message: '该浏览器不支持自动复制'
                    });
                    clipboard.destroy();
                });

            }
        }
    }
</script>

<style scoped>
    .box-message{
        margin: 15px 0;
    }
    .input{
        border: 2px solid #2b3a49;
        color: #000;
        height: 35px;
        line-height: 35px;
        padding-left: 15px;
        width: 700px;background: #fff
    }
    .btn-copy{
        background: #2b3a49;cursor: pointer;color: #fff;border-color: #2b3a49 !important;
    }
    .copy-span{
        line-height: 35px;
        width: 90px;
        text-align: right;
    }
    input.input{
        outline: -webkit-focus-ring-color auto 0 !important;
        outline:none !important;
    }
    button.btn-copy{
        outline: -webkit-focus-ring-color auto 0 !important;
        outline:none !important;border: none !important;
        width: 120px !important;height: 35px !important;padding: 0 !important;
    }
    button.btn-copy:hover,button.btn-copy:focus{
        background: #34404e;cursor: pointer;color: #fff;
        border: none !important;
    }
    .box-message .el-button {
        border-radius: 0;
    }
    .notice{
        margin-bottom: 15px;
        border: 1px solid #ede7da;
        background-color: #ede7da;
    }
    .panel-title .el-button{
        float: right
    }

</style>
