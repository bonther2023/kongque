<template>
    <div id="app" v-cloak>
        <router-view/>
    </div>
</template>

<style>
    [v-cloak] {
        display: none
    }

    i {
        font-style: normal;
    }

    #nav {
        padding: 30px;
    }

    #nav a {
        font-weight: bold;
        color: #2c3e50;
    }

    #nav a.router-link-exact-active {
        color: #42b983;
    }
</style>
