import Vue from 'vue';
import App from './App.vue';
// import './registerServiceWorker';
import router from './router';
import store from './store';
import Moment from 'moment';
import VueLazyload from 'vue-lazyload';
import VueCookie from 'vue-cookie';
import ElementUI from 'element-ui';
import Crypto from "@/utils/crypto";
import NProgress from 'nprogress' // Progress 进度条
import Echarts from 'echarts';

import 'element-ui/lib/theme-chalk/index.css';
import 'font-awesome/css/font-awesome.css';
import 'nprogress/nprogress.css'// Progress 进度条样式
import '@/assets/css/main.css';
import Storage from "@/utils/storage";


Vue.use(VueLazyload);
Vue.use(VueCookie);
Vue.use(ElementUI);


Vue.prototype.$moment = Moment;
Vue.prototype.$store = store;
Vue.prototype.$crypto = Crypto;
Vue.prototype.$storage = Storage;
Vue.prototype.$echarts = Echarts;
Vue.config.productionTip = false;

router.beforeEach((to, from, next) => {
    NProgress.start();//开启进度条
    //其他端，管理后台PC端的逻辑
    if (to.meta.title) document.title = to.meta.title + "_渠道中心";//动态化每个页面的标题
    if(to.name == 'authorize'){
        next();
    }else{
        const whiteList = ['login'];
        const token = VueCookie.get('token');
        if (token) {
            //如果令牌存在，不能直接访问登录界面
            if (whiteList.includes(to.name)) {
                next({name: 'main'});
            } else {
                next();
            }
        } else {
            //登录白名单，在执行next({name:'Login'})的时候允许进入该页面
            if (whiteList.includes(to.name)) {
                next();
            } else {
                next({name: 'login'});// token不存在的情况全部重定向到登录页
            }
        }
    }
});

NProgress.configure({showSpinner: false});//取消右上角的进度环
router.afterEach((transition) => {
    NProgress.done();//关闭进度条
});

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app');
